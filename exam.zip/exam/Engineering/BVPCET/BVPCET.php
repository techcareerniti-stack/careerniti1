<?php
// bvpcet.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET [Bharati Vidyapeeth Common Entrance Test]</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- ==================== Add Navbar Placeholder ==================== -->
<?php
// Include your PHP Navbar here if needed
// include 'navbar.php';
?>

<!-- ==================== Sections ==================== -->

<!-- Introduction -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Introduction</h2>
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            BVPCET (Bharati Vidyapeeth Common Entrance Test) is conducted for admission into various undergraduate courses like BTech, LLB, BPharm, BArch, etc. across Bharati Vidyapeeth campuses.
        </p>
    </div>
</div>

<!-- Eligibility -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Eligibility</h2>
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            Candidates must satisfy course-specific eligibility criteria, including minimum marks in qualifying exams and subject requirements as specified by Bharati Vidyapeeth.
        </p>
    </div>
</div>

<!-- Available Courses -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Available Courses</h2>
        <ul class="list-disc pl-6 text-gray-700 text-base md:text-lg leading-relaxed">
            <li>
                BTech, BTech-II, LLB, BBA LLB, BA LLB, BPharm, Pharm D., BPharm II, 
                BArch, BHMCT, BSc(H&HA), BSc Biotechnology, BSc Nursing, PB BSc Nursing, 
                BASLP, BASLP (Lateral), BOptom, BOptom (Lateral)
            </li>
        </ul>
    </div>
</div>

<!-- Campus -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Campus</h2>
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            Bharati Vidyapeeth has campuses in Pune, Navi Mumbai, and other cities where selected candidates can pursue their programs.
        </p>
    </div>
</div>

<!-- Application Fees -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-4xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Application Fees</h2>
        <ul class="list-disc pl-6 text-gray-700 text-base md:text-lg">
            <li>Make application fee payment – <span class="font-semibold">Rs. 1700</span> (Net Banking or Credit / Debit Card)</li>
        </ul>
    </div>
</div>

<!-- Important Dates -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Important Dates</h2>
        <ul class="list-disc pl-6 text-gray-700 text-base md:text-lg leading-relaxed">
            <li>Application Start: 1st January 2025</li>
            <li>Application Deadline: 30th April 2025</li>
            <li>Exam Date: Last Week of May 2025</li>
            <!-- Add more dates as required -->
        </ul>
    </div>
</div>

<!-- Exam Pattern -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Exam Pattern</h2>
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            BVPCET is a computer-based test with multiple-choice questions covering relevant subjects as per course requirements. Correct answers score points while incorrect answers may carry negative marking.
        </p>
    </div>
</div>

<!-- Syllabus -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Syllabus</h2>
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            Syllabus for BVPCET is based on the NCERT curriculum of relevant classes for the chosen courses. Candidates can refer to NCERT textbooks and official sample tests.
        </p>
    </div>
</div>

<!-- Test Centres -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-6xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Test Centres</h2>
        <ul class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-2 list-disc pl-5 text-gray-700 text-base md:text-lg">
            <li>Pune</li>
            <li>Navi Mumbai</li>
            <li>Mumbai</li>
            <li>Nagpur</li>
            <li>Kolhapur</li>
            <li>Other cities...</li>
            <!-- Add all test centres -->
        </ul>
    </div>
</div>

<!-- Required Documents -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Required Documents</h2>
        <ul class="list-disc pl-6 text-gray-700 text-base md:text-lg leading-relaxed">
            <li>Class 10 Mark Statement</li>
            <li>Class 12 Mark Statement</li>
            <li>Passport-size photograph</li>
            <li>Signature</li>
        </ul>
    </div>
</div>

<!-- FAQ -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
        <ul class="list-disc pl-6 text-gray-700 text-base md:text-lg leading-relaxed space-y-3">
            <li>Q: How can I apply for BVPCET? <br> A: Apply online through the official portal before the deadline.</li>
            <li>Q: What is the application fee? <br> A: Rs. 1700 (Net Banking or Credit/Debit Card)</li>
            <li>Q: Are there sample tests available? <br> A: Yes, official sample tests are available online.</li>
            <!-- Add more FAQs -->
        </ul>
    </div>
</div>

</body>
</html>
