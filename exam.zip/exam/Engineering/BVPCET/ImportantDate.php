<?php
// important_dates.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET Important Dates</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Important Dates Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">Important Dates</h2>

        <!-- Dates Table -->
        <table class="w-full border border-gray-200 text-gray-700">
            <thead class="bg-gray-100">
                <tr>
                    <th class="border px-4 py-2 text-left">Event</th>
                    <th class="border px-4 py-2 text-left">Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="border px-4 py-2">Last date to fill BVP CET 2023 application form</td>
                    <td class="border px-4 py-2">June 1, 2023</td>
                </tr>
                <tr class="bg-gray-50">
                    <td class="border px-4 py-2">Release of BVP CET 2023 Admit Card</td>
                    <td class="border px-4 py-2">Not required for Online Proctored Exam</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2">BVP CET 2023 Exam Date</td>
                    <td class="border px-4 py-2">June 11, 2023</td>
                </tr>
                <tr class="bg-gray-50">
                    <td class="border px-4 py-2">Declaration of BVP CET Result</td>
                    <td class="border px-4 py-2">Last week of June 2023</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2">BVP CET 2023 Counselling Date</td>
                    <td class="border px-4 py-2">July 2023</td>
                </tr>
                <tr class="bg-gray-50">
                    <td class="border px-4 py-2">Commencement of Classes</td>
                    <td class="border px-4 py-2">August 2023</td>
                </tr>
            </tbody>
        </table>

    </div>
</div>

</body>
</html>
