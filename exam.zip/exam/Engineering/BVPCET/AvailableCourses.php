<?php
// available_courses.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET Available Courses</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Available Courses Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
            Available Courses
        </h2>

        <!-- Course List -->
        <ul class="list-disc pl-6 text-gray-700 text-base md:text-lg leading-relaxed">
            <li>
                BTech, BTech-II, LLB, BBA LLB, BA LLB, BPharm, Pharm D., 
                BPharm II, BArch, BHMCT, BSc (H&amp;HA), BSc Biotechnology, 
                BSc Nursing, PB BSc Nursing, BASLP, BASLP (Lateral), 
                BOptom, BOptom (Lateral).
            </li>
        </ul>

    </div>
</div>

</body>
</html>
