<?php
// testcities.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET Test Cities</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Test Cities Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Test Cities</h2>

        <ul class="text-gray-700 text-base md:text-lg leading-relaxed list-disc pl-6 space-y-3">
            <li class="font-semibold">Test is conducted in below cities</li>
        </ul>

        <div class="overflow-x-auto mt-4">
            <table class="min-w-full border border-gray-300">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="border px-4 py-2 text-left">State</th>
                        <th class="border px-4 py-2 text-left">City</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td rowspan="2" class="border px-4 py-2">Maharashtra</td><td class="border px-4 py-2">Pune</td></tr>
                    <tr><td class="border px-4 py-2">Navi Mumbai</td></tr>
                    <tr><td class="border px-4 py-2">Delhi</td><td class="border px-4 py-2">New Delhi</td></tr>
                    <tr><td class="border px-4 py-2">Telangana</td><td class="border px-4 py-2">Hyderabad</td></tr>
                    <tr><td class="border px-4 py-2">Gujarat</td><td class="border px-4 py-2">Vadodara</td></tr>
                    <tr><td class="border px-4 py-2">Madhya Pradesh</td><td class="border px-4 py-2">Indore</td></tr>
                    <tr><td rowspan="2" class="border px-4 py-2">Uttar Pradesh</td><td class="border px-4 py-2">Lucknow</td></tr>
                    <tr><td class="border px-4 py-2">Varanasi</td></tr>
                    <tr><td class="border px-4 py-2">Karnataka</td><td class="border px-4 py-2">Bangalore</td></tr>
                    <tr><td class="border px-4 py-2">Rajasthan</td><td class="border px-4 py-2">Jaipur</td></tr>
                    <tr><td class="border px-4 py-2">Chandigarh</td><td class="border px-4 py-2">Chandigarh</td></tr>
                </tbody>
            </table>
        </div>

    </div>
</div>

</body>
</html>
