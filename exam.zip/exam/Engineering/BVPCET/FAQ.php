<?php
// faq.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET FAQ</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- FAQ Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">FAQ Section</h2>

        <!-- FAQ List -->
        <ul class="space-y-6 text-gray-700 text-base md:text-lg leading-relaxed">
            
            <li>
                <p class="font-semibold">Que 1:- Who is eligible for BVP CET?</p>
                <p><b>Ans:-</b> Interested candidates must have completed the 10+2 examination with Physics and Mathematics as main subjects and one of the optional subjects being Biotechnology/Chemistry/Biology/Technical. Candidates from the open category must obtain 45% in their 10+2 examination.</p>
            </li>

            <li>
                <p class="font-semibold">Que 2:- What is the cut off for BVP 2023?</p>
                <p><b>Ans:-</b> BVP CET 2023 Cut off is the minimum score that is needed for admission. Candidates who score higher than the cut off will be included in the merit list. The total marks of the exam will be 200. Since the exam is easy, generally the cut off is around 170-180 marks.</p>
            </li>

            <li>
                <p class="font-semibold">Que 3:-  What is BVP application fee?</p>
                <p><b>Ans:-</b> Applicants are required to pay an application fee of Rs 1700 for BVP CET 2024. 4. What is the BVP CET 2024 application form last date for exam?</p>
            </li>

            <li>
                <p class="font-semibold">Que 4:- How to prepare for BVP entrance exam?</p>
                <p><b>Ans:-</b> Candidates must look for objective-type questions and practice regularly to get hold of the important topics and keep notes on such topics. Make a list of formulas, and frequently apply them to your questions. Devising proper planning is a prerequisite to scoring well in the exam.</p>
            </li>

            <li>
                <p class="font-semibold">Que 5:- Does BVP have negative marking?</p>
                <p><b>Ans:-</b> The pattern consists of 100 questions in total for 1 mark each with no negative marking. The time limit is 120 minutes for the completion of the examination.</p>
            </li>

            <li>
                <p class="font-semibold">Que 6:- How many students appeared in BVP CET?</p>
                <p><b>Ans:-</b> Every year around 10,000 to 15,000 students appear for the entrance exams.</p>
            </li>

            <li>
                <p class="font-semibold">Que 7:- Are BVP fees refundable?</p>
                <p><b>Ans:-</b> Refund will be made only after the candidate has surrendered the ID card, original fee receipt and the dues clearance certificate. Application and Entrance Test fees, wherever applicable, once remitted shall NOT be refunded under any circumstances.</p>
            </li>

            <li>
                <p class="font-semibold">Que 8:- Can I change my choice of exam center after submitting the NEET application form?</p>
                <p><b>Ans:-</b> No, after the closure of the NEET application form submission window, candidates cannot change their choice of exam center. It is essential to carefully select the exam center during the application process.</p>
            </li>

            <li>
                <p class="font-semibold">Que 9:- Is there any relaxation in the NEET eligibility criteria for differently abled or physically challenged candidates?</p>
                <p><b>Ans:-</b> There are guidelines for written exams to help people with disabilities who have a disability of 40% or more. “Disabilities” can be long-term physical, mental, intellectual, or sensory impairments that make it difficult for them to fully participate in society like others. People with disabilities of 40% or more are called “persons with benchmark disabilities.” They can get admission to medical courses under a 5% reserved quota.<br>
                If someone has difficulty writing the exam due to a physical limitation, they can have a helper called a “scribe” who will write the answers on their behalf. The scribe should be certified by a government healthcare institution.<br>
                Also, if an aspiring MBBS graduate has a physical limitation and needs extra time to complete the exam, they will get one hour and five minutes extra, even if they don’t use a scribe. The national testing agency (NTA) can arrange a scribe if requested in the online application form.
                </p>
            </li>

        </ul>

    </div>
</div>

</body>
</html>
