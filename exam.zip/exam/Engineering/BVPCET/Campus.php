<?php
// campuses.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET Campuses</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Campus Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Campus</h2>

        <!-- Campus List -->
        <ul class="text-gray-700 text-base md:text-lg leading-relaxed list-disc pl-6">
            <li class="font-semibold mb-2">Bharati Vidyapeeth has campuses across the country at:</li>
            <ol class="list-decimal list-inside pl-4 space-y-1">
                <li>New Delhi</li>
                <li>Navi Mumbai</li>
                <li>Sangli</li>
                <li>Pune</li>
                <li>Solapur</li>
                <li>Kolhapur</li>
                <li>Karad</li>
                <li>Satara</li>
                <li>Panchgani</li>
            </ol>
        </ul>

    </div>
</div>

</body>
</html>
