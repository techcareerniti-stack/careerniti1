<?php
// required_documents.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET Required Documents</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Required Documents Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Required Documents</h2>

        <!-- Documents List -->
        <ul class="text-gray-700 text-base md:text-lg leading-relaxed list-disc pl-6 space-y-3">
            <li class="font-semibold">Documents required</li>
            <ol class="list-decimal list-inside pl-5 space-y-1 mt-2">
                <li>Active Mobile Number and Email ID</li>
                <li>Scanned Photograph in JPEG format (Maximum upload size is 50 KB only)</li>
                <li>Signature (Maximum upload size is 30 KB only)</li>
                <li>Scanned copies of mark sheet of Class 10 and Class 12</li>
                <li>Aadhaar Card</li>
            </ol>
        </ul>

    </div>
</div>

</body>
</html>
