<?php
// eligibility.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET Eligibility</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Eligibility Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Eligibility</h2>

        <!-- Eligibility Details -->
        <ul class="text-gray-700 text-base md:text-lg leading-relaxed list-disc pl-6 space-y-4">

            <li>
                <span class="font-semibold">Nationality</span><br>
                There are no stated nationality criteria. Candidates from all over the world can apply for the exam.
            </li>

            <li>
                <span class="font-semibold">Educational Qualification</span>
                <ol class="list-decimal list-inside pl-5 mt-2 space-y-1">
                    <li>Candidates must have passed or must be appearing for the 12th standard examination from a recognized board or university.</li>
                    <li>Candidates must obtain a minimum of 50% marks (45% for SC/ST candidates) in 10+2 or any equivalent exam.</li>
                    <li>Candidates who hold a Diploma in Engineering & Technology from AICTE approved institutions with at least 50% marks (45% for SC/ST/PwD) are also eligible.</li>
                    <li>Mathematics and Physics are compulsory subjects in 10+2.</li>
                </ol>
            </li>

            <li>
                <span class="font-semibold">Age Limit</span><br>
                There is no age limit to take the test.
            </li>

        </ul>

    </div>
</div>

</body>
</html>
