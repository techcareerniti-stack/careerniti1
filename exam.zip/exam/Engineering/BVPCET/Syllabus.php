<?php
// syllabus.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET Syllabus</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Syllabus Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Syllabus</h2>

        <p class="text-gray-700 text-base md:text-lg mb-4">
            The BVP CET 2023 exam syllabus will include 10+2 level Mathematics and Physics.
        </p>

        <ul class="text-gray-700 text-base md:text-lg leading-relaxed list-disc pl-6 space-y-3">
            <li class="font-semibold">The table below lists the topics covered by the two subjects:</li>
        </ul>

        <!-- Syllabus Table -->
        <div class="overflow-x-auto mt-4">
            <table class="min-w-full border border-gray-300">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="border px-4 py-2 text-left">Mathematics</th>
                        <th class="border px-4 py-2 text-left">Physics</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td class="border px-4 py-2">Trigonometry</td><td class="border px-4 py-2">Physical World and Measurement</td></tr>
                    <tr><td class="border px-4 py-2">Determinant</td><td class="border px-4 py-2">Kinematics and Kinetic Theory</td></tr>
                    <tr><td class="border px-4 py-2">Set, Relation and Functions</td><td class="border px-4 py-2">Laws of Motion</td></tr>
                    <tr><td class="border px-4 py-2">Logarithm</td><td class="border px-4 py-2">Work, Energy, and Power</td></tr>
                    <tr><td class="border px-4 py-2">Complex Numbers</td><td class="border px-4 py-2">Motions of System of Particles and Rigid body</td></tr>
                    <tr><td class="border px-4 py-2">Quadratic Roots</td><td class="border px-4 py-2">Gravitation and Properties of Bulk Matter</td></tr>
                    <tr><td class="border px-4 py-2">Sequences and Series</td><td class="border px-4 py-2">Thermodynamics</td></tr>
                    <tr><td class="border px-4 py-2">Permutations and Combinations</td><td class="border px-4 py-2">Oscillations and Waves</td></tr>
                    <tr><td class="border px-4 py-2">Mathematical Induction and Binomial Theorem</td><td class="border px-4 py-2">Electrostatics and Electricity</td></tr>
                    <tr><td class="border px-4 py-2">Limits & Continuity</td><td class="border px-4 py-2">Magnetic Effects of Current and Magnetism</td></tr>
                    <tr><td class="border px-4 py-2">Calculus</td><td class="border px-4 py-2">Electromagnetic Induction and Alternating Current</td></tr>
                    <tr><td class="border px-4 py-2">Matrices</td><td class="border px-4 py-2">Electromagnetic Waves and Optics</td></tr>
                    <tr><td class="border px-4 py-2">Geometry & Coordinate Geometry</td><td class="border px-4 py-2">Dual Nature of Matter and Radiation</td></tr>
                    <tr><td class="border px-4 py-2">Statistics</td><td class="border px-4 py-2">Atoms and Nuclei</td></tr>
                </tbody>
            </table>
        </div>

    </div>
</div>

</body>
</html>
