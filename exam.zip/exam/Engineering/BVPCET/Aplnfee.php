<?php
// application_fee.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BVPCET Application Fees</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Application Fee Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-4xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Heading -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
            Application Fees
        </h2>

        <!-- Fee Details -->
        <ul class="list-disc pl-6 text-gray-700 text-base md:text-lg">
            <li>
                Make application fee payment – 
                <span class="font-semibold text-gray-900">Rs. 1700</span>
                (Net Banking or Credit / Debit Card).
            </li>
        </ul>

    </div>
</div>

</body>
</html>
