<?php
// eligibility.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Eligibility</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top (React useEffect equivalent) -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Eligibility Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
            Eligibility
        </h2>

        <!-- Description -->
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            Candidates should have passed the 12th examination from a recognized
            Central or State board with Physics, Chemistry, and Mathematics as
            core subjects. A minimum aggregate percentage in PCM is required.
        </p>

    </div>
</div>

</body>
</html>
