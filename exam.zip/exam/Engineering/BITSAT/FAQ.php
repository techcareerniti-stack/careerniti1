<?php
// faq.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BITSAT FAQs</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- FAQ Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">
            Frequently Asked Questions (FAQs)
        </h2>

        <!-- FAQ Items -->
        <div class="space-y-4">

            <!-- FAQ 1 -->
            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 1. What is a Dual Degree? How is it assigned?
                </summary>
                <p class="mt-3 text-gray-700 leading-relaxed">
                    <b>Ans:-</b> BITS Pilani allows students admitted to M.Sc.
                    programs to pursue a dual degree with a B.E. program.
                    The allotment is based on first-year academic performance
                    and seat availability. Dual degree students pay separate
                    admission fees and typically complete both degrees in five years.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 2. Are B.Pharm students eligible for a dual degree?
                </summary>
                <p class="mt-3 text-gray-700 leading-relaxed">
                    <b>Ans:-</b> No. Dual degree or transfer is not allowed
                    for B.Pharm students with PCB input, as PCM is mandatory.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 3. Is there any 2-year M.Sc. program at BITS?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> No. BITS does not offer a 2-year M.Sc. program.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 4. How can students join M.Sc. after 12th without B.Sc.?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> M.Sc. programs at BITS are 4-year integrated
                    courses after 12th. No intermediate B.Sc. degree is awarded.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 5. Can PCB students apply for M.Sc. Biology?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> No. PCM is mandatory since dual degree options
                    require Mathematics.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 6. Are NIOS board students eligible?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> Yes, if all components of the NIOS 12th exam
                    have been completed.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 7. Does BITS consider JEE Main score?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> No. Admissions are based only on BITSAT score.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 8. What is the procedure for NRIs?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> NRIs can apply under the International Students
                    Admission Scheme.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 9. What about candidates with foreign qualifications?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> They must apply like Indian students and
                    provide an AIU equivalence certificate later.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 10. Can NRI students apply through BITS ISA?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> Yes, if the candidate holds foreign citizenship.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 11. What is Direct Admission to Board Topper Scheme?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> This scheme is open only to state or central
                    board toppers.
                </p>
            </details>

            <details class="group border rounded-lg p-4">
                <summary class="cursor-pointer font-semibold text-gray-800">
                    Que 12. Can current BITS students apply for BITSAT?
                </summary>
                <p class="mt-3 text-gray-700">
                    <b>Ans:-</b> No. Current BITS students are not eligible.
                </p>
            </details>

        </div>

    </div>
</div>

</body>
</html>
