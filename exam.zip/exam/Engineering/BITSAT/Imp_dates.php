<?php
// imp_dates.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BITSAT Important Dates</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Important Dates Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-6xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">
            Important Dates
        </h2>

        <!-- Table Wrapper (Mobile Scroll) -->
        <div class="overflow-x-auto">
            <table class="w-full border border-gray-300 text-sm md:text-base">

                <!-- Table Head -->
                <thead class="bg-gray-100">
                    <tr>
                        <th class="border px-4 py-3 text-left font-semibold">
                            Description
                        </th>
                        <th class="border px-4 py-3 text-left font-semibold">
                            Dates
                        </th>
                    </tr>
                </thead>

                <!-- Table Body -->
                <tbody class="divide-y">

                    <tr>
                        <td class="border px-4 py-3">Start of BITSAT-2024 Application</td>
                        <td class="border px-4 py-3">14th January, 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Deadline to apply online for BITSAT-2024 for one Session or Both the Sessions
                        </td>
                        <td class="border px-4 py-3">11th April 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Revision/editing (online) in the application form by candidates
                        </td>
                        <td class="border px-4 py-3">15th to 19th April 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Test centre allotment and announcement to candidates
                        </td>
                        <td class="border px-4 py-3">1st May 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">Candidates to reserve Test date and slot</td>
                        <td class="border px-4 py-3">06th to 10th May 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Candidates to download Hall tickets (Session I)
                        </td>
                        <td class="border px-4 py-3">
                            15th May 2024 to till the exam date
                        </td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">BITSAT-2024 Online Test Session-I</td>
                        <td class="border px-4 py-3">Last Week of May 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Application window for BITSAT-2024 Session-II only
                        </td>
                        <td class="border px-4 py-3">
                            Last Week of May 2024 to Second Week of June 2024
                        </td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Revision/editing (online) in the application form
                        </td>
                        <td class="border px-4 py-3">Second Week of June 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Test centre allotment and announcement
                        </td>
                        <td class="border px-4 py-3">Second Week of June 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Candidates to reserve Test date and slot
                        </td>
                        <td class="border px-4 py-3">Third Week of June 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Download Hall tickets (Session II)
                        </td>
                        <td class="border px-4 py-3">
                            Third Week of June to till the exam date
                        </td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            BITSAT-2024 Online Test Session-II
                        </td>
                        <td class="border px-4 py-3">Third Week of June 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Apply for admission with 12th Marks & Preferences
                        </td>
                        <td class="border px-4 py-3">
                            First Week of June to Last Week of June 2024
                        </td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Editing of Marks / Preferences
                        </td>
                        <td class="border px-4 py-3">Last Week of June 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            Admit list & Waitlist after Iteration I
                        </td>
                        <td class="border px-4 py-3">First Week of July 2024</td>
                    </tr>

                    <tr>
                        <td class="border px-4 py-3">
                            BITSAT HD-2024 Online Test Session-I
                        </td>
                        <td class="border px-4 py-3">
                            Third Week of May & Last Week of May 2024
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>

    </div>
</div>

</body>
</html>
