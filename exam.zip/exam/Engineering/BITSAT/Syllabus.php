import { useEffect } from "react";
import "./Syllabus.css";
function Syllabus() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Syllabus-section-bitsat ">
        <div className="Syllabus-content-bitsat poppins-regular">
          <h2 className="bitsat-title">Syllabus</h2>
          <ul>
            <li>
              <div>
                The BITSAT-2024 test will be conducted on the basis of NCERT syllabus for the 11th and 12th class. The
                a detailed syllabus is given in the Annexure. Candidates may refer to the NCERT textbooks for the contents. A sample test demonstrating the features of BITSAT-2024 will be made available to the registered candidates at the BITS admission website on which he/she can practice as many times as desired.
              </div>
            </li>
          </ul>

        </div>
      </div><?php
// syllabus.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BITSAT Syllabus</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Syllabus Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">
            Syllabus
        </h2>

        <!-- Content -->
        <ul class="list-disc pl-6 text-gray-700 text-base md:text-lg leading-relaxed space-y-3">
            <li>
                The BITSAT examination is conducted based on the
                <span class="font-semibold">NCERT syllabus of Class 11 and Class 12</span>.
            </li>
            <li>
                Candidates are advised to thoroughly study the NCERT textbooks for
                <span class="font-semibold">Physics, Chemistry, and Mathematics</span>.
            </li>
            <li>
                The detailed syllabus is provided in the official
                <span class="font-semibold">Annexure</span> released by BITS Pilani.
            </li>
            <li>
                A sample test demonstrating the features of BITSAT is made available
                on the official BITS admission website.
            </li>
            <li>
                Registered candidates can attempt the sample test multiple times
                for better exam familiarity.
            </li>
        </ul>

    </div>
</div>

</body>
</html>

    </>
  );
}

export default Syllabus;
