<?php
// test_centres.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BITSAT Test Centres</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Test Centres Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-6xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">
            Test Centres
        </h2>

        <!-- Test Centre List -->
        <ul class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 
                   gap-x-6 gap-y-2 text-gray-700 text-base md:text-lg list-disc pl-5">

            <li>Agartala</li>
            <li>Agra</li>
            <li>Ahmedabad</li>
            <li>Aizawl</li>
            <li>Ajmer</li>
            <li>Allahabad</li>
            <li>Aurangabad (Maharashtra)</li>
            <li>Bangalore (Bengaluru)</li>
            <li>Bareilly</li>
            <li>Bhopal</li>
            <li>Bhubaneswar</li>
            <li>Chandigarh</li>
            <li>Chennai</li>
            <li>Coimbatore</li>
            <li>Delhi</li>
            <li>Dibrugarh</li>
            <li>Gurgaon (Gurugram)</li>
            <li>Guwahati</li>
            <li>Gwalior</li>
            <li>Hyderabad Campus of BITS</li>
            <li>Hyderabad City</li>
            <li>Indore</li>
            <li>Jabalpur</li>
            <li>Jaipur</li>
            <li>Jalandhar</li>
            <li>Jammu</li>
            <li>Jamshedpur</li>
            <li>Jodhpur</li>
            <li>Kanpur</li>
            <li>Kathmandu (Nepal)</li>
            <li>Kochi</li>
            <li>Kolhapur</li>
            <li>Kolkata</li>
            <li>Kota</li>
            <li>Lucknow</li>
            <li>Madurai</li>
            <li>Mangalore</li>
            <li>Mohali</li>
            <li>Mumbai</li>
            <li>Nagpur</li>
            <li>Nasik</li>
            <li>Noida</li>
            <li>Patna</li>
            <li>Pilani Campus of BITS</li>
            <li>Pune</li>
            <li>Raipur</li>
            <li>Rajahmundry</li>
            <li>Rajkot</li>
            <li>Ranchi</li>
            <li>Roorkee</li>
            <li>Shimla</li>
            <li>Siliguri</li>
            <li>Surat</li>
            <li>Thiruvananthapuram</li>
            <li>Tirupati</li>
            <li>Udaipur</li>
            <li>Vadodara</li>
            <li>Vijayawada</li>
            <li>Visakhapatnam</li>

        </ul>

    </div>
</div>

</body>
</html>
