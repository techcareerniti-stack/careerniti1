<?php
// application_fees.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Application Fees</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top (same as useEffect) -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Fee Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">
            Application Fees
        </h2>

        <!-- Table Wrapper -->
        <div class="overflow-x-auto">
            <table class="w-full border border-gray-300 text-sm md:text-base">
                
                <!-- Table Head -->
                <thead class="bg-gray-100">
                    <tr>
                        <th class="border px-4 py-3 text-left font-semibold">
                            Description
                        </th>
                        <th class="border px-4 py-3 text-center font-semibold">
                            Male Candidate
                        </th>
                        <th class="border px-4 py-3 text-center font-semibold">
                            Female Candidate
                        </th>
                    </tr>
                </thead>

                <!-- Table Body -->
                <tbody>
                    <tr class="hover:bg-gray-50">
                        <td class="border px-4 py-3">
                            Appear Twice (Session 1 & Session 2)
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 5400
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 4400
                        </td>
                    </tr>

                    <tr class="hover:bg-gray-50">
                        <td class="border px-4 py-3">
                            Appear Once (Session 1 or Session 2)
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 3400
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 2900
                        </td>
                    </tr>

                    <tr class="hover:bg-gray-50">
                        <td class="border px-4 py-3">
                            Add Second Session (Session 2) after Session 1
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 2000
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 1500
                        </td>
                    </tr>

                    <tr class="hover:bg-gray-50">
                        <td class="border px-4 py-3">
                            Dubai Test Centre – Appear Once (Session 1 or Session 2)
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 7000
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 7000
                        </td>
                    </tr>

                    <tr class="hover:bg-gray-50">
                        <td class="border px-4 py-3">
                            Dubai Test Centre – Appear Both Sessions
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 9000
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 9000
                        </td>
                    </tr>

                    <tr class="hover:bg-gray-50">
                        <td class="border px-4 py-3">
                            Dubai Test Centre – Add Second Session after Session 1
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 2000
                        </td>
                        <td class="border px-4 py-3 text-center font-medium">
                            ₹ 2000
                        </td>
                    </tr>
                </tbody>

            </table>
        </div>
    </div>
</div>

</body>
</html>
