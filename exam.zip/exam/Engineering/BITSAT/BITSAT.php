<?php
$path = $_SERVER['REQUEST_URI'];
$loc  = $path;

// formatLocation function (React → PHP)
function formatLocation($location) {
    $parts = array_filter(explode("/", $location));
    $formatted = [];

    foreach ($parts as $part) {
        if (strtolower($part) === "bitsat") {
            $formatted[] = "BITSAT";
        } else {
            $formatted[] = ucfirst($part);
        }
    }
    return implode(" > ", $formatted);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BITSAT</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to Top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Navbar -->
<?php include "navbar.php"; ?>

<!-- Breadcrumb -->
<div class="max-w-7xl mx-auto px-4 py-4 text-sm text-gray-600">
    <?= formatLocation($loc); ?>
</div>

<!-- Page Heading -->
<div class="max-w-7xl mx-auto px-4">
    <h1 class="text-3xl font-bold text-gray-800">BITSAT</h1>
    <p class="text-gray-600 mt-1">
        Birla Institute of Technology and Science Admission Test
    </p>
</div>

<!-- Sections -->
<div class="max-w-7xl mx-auto px-4 space-y-10 py-8">

    <?php include "introduction.php"; ?>
    <?php include "eligibility.php"; ?>
    <?php include "available_courses.php"; ?>
    <?php include "campuses.php"; ?>
    <?php include "application_fees.php"; ?>
    <?php include "imp_dates.php"; ?>
    <?php include "exam_pattern.php"; ?>
    <?php include "syllabus.php"; ?>
    <?php include "test_centres.php"; ?>
    <?php include "required_docs.php"; ?>
    <?php include "faq.php"; ?>

</div>

<br><br>

</body>
</html>
