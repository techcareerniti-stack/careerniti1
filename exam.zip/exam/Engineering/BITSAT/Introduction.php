<?php
// introduction.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BITSAT Introduction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top (React useEffect equivalent) -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Introduction Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
            Introduction
        </h2>

        <!-- Content -->
        <ul class="list-disc pl-5">
            <li class="text-gray-700 text-base md:text-lg leading-relaxed">
                BITSAT (Birla Institute of Technology and Science Admission Test)
                is a computer-based entrance exam conducted by BITS Pilani for
                admissions to its integrated first-degree programs across its
                campuses. The exam evaluates candidates’ knowledge in Physics,
                Chemistry, Mathematics, English, and Logical Reasoning.
            </li>
        </ul>

    </div>
</div>

</body>
</html>
