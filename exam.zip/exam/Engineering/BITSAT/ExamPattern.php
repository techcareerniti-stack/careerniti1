<?php
// exam_pattern.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Exam Pattern</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top (React useEffect equivalent) -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>

<body class="bg-gray-50 font-sans">

<!-- Exam Pattern Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
            Exam Pattern
        </h2>

        <!-- Description -->
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            BITSAT is a computer-based test with multiple-choice questions
            (MCQs). The exam includes sections on Physics, Chemistry,
            Mathematics, English Proficiency, and Logical Reasoning. Correct
            answers earn marks, and incorrect answers result in negative
            marking.
        </p>

    </div>
</div>

</body>
</html>
