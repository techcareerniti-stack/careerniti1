<?php
// comedk.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Navbar placeholder -->
<div class="w-full bg-orange-600 text-white p-4 text-xl font-bold text-center">
    COMEDK [Consortium of Medical, Engineering, and Dental Colleges of Karnataka]
</div>

<!-- Introduction -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Introduction</h2>
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            COMEDK provides the opportunity to pursue both B.Tech and B.Arch programs. By participating in COMEDK's admission process, aspiring students can choose either the B.Tech (Engineering) or B.Arch (Architecture) pathway.
        </p>
    </div>
</div>

<!-- Eligibility -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Eligibility</h2>
        <ul class="text-gray-700 text-base md:text-lg leading-relaxed list-disc pl-6 space-y-4">
            <li>
                <span class="font-semibold">Nationality</span><br>
                Candidates from all over the world can apply.
            </li>
            <li>
                <span class="font-semibold">Educational Qualification</span>
                <ol class="list-decimal list-inside pl-5 mt-2 space-y-1">
                    <li>Candidates must have passed or appearing for 12th standard with Physics, Mathematics and one optional subject.</li>
                    <li>Candidates must meet minimum marks requirements as per the guidelines.</li>
                </ol>
            </li>
            <li>
                <span class="font-semibold">Age Limit</span><br>
                There is no age limit.
            </li>
        </ul>
    </div>
</div>

<!-- Available Courses -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Available Courses</h2>
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            COMEDK offers B.Tech (Engineering) and B.Arch (Architecture) programs through its admission process.
        </p>
    </div>
</div>

<!-- Campuses -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Campuses</h2>
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            After clearing COMEDK, students can seek admission in ~150 private colleges in Karnataka offering B.Tech and B.Arch. COMEDK centralized counseling allows selection based on rank.
        </p>
    </div>
</div>

<!-- Application Fees -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Application Fees</h2>
        <table class="w-full table-auto border border-gray-300 text-gray-700">
            <thead class="bg-gray-100">
                <tr>
                    <th class="border px-4 py-2">Stream</th>
                    <th class="border px-4 py-2">Fees (IN RS.)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="border px-4 py-2">COMEDK UGET (PCM)</td>
                    <td class="border px-4 py-2">Rs 1800 + Convenience charge</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2">BOTH COMEDK AND UNIGAUGE (PCM)</td>
                    <td class="border px-4 py-2">Rs 2950 + Convenience charge</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Important Dates -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Important Dates</h2>
        <table class="w-full table-auto border border-gray-300 text-gray-700">
            <thead class="bg-gray-100">
                <tr>
                    <th class="border px-4 py-2">Event</th>
                    <th class="border px-4 py-2">Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="border px-4 py-2">Last date to fill COMEDK application</td>
                    <td class="border px-4 py-2">May 2024</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2">Exam Date</td>
                    <td class="border px-4 py-2">May 2024</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2">Result Declaration</td>
                    <td class="border px-4 py-2">May 2024</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Exam Pattern -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Exam Pattern</h2>
        <table class="w-full table-auto border border-gray-300 text-gray-700">
            <tbody>
                <tr>
                    <td class="border px-4 py-2 font-semibold">Mode of Exam</td>
                    <td class="border px-4 py-2">Computer based</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2 font-semibold">Types of Questions</td>
                    <td class="border px-4 py-2">MCQs</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2 font-semibold">Negative Marking</td>
                    <td class="border px-4 py-2">None</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2 font-semibold">Duration</td>
                    <td class="border px-4 py-2">180 minutes</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2 font-semibold">Total Questions</td>
                    <td class="border px-4 py-2">200</td>
                </tr>
                <tr>
                    <td class="border px-4 py-2 font-semibold">Medium of Exam</td>
                    <td class="border px-4 py-2">English</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Syllabus -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Syllabus</h2>
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">10+2 level Mathematics and Physics.</p>
        <table class="w-full table-auto border border-gray-300 text-gray-700 mt-4">
            <thead class="bg-gray-100">
                <tr>
                    <th class="border px-4 py-2">Mathematics</th>
                    <th class="border px-4 py-2">Physics</th>
                </tr>
            </thead>
            <tbody>
                <tr><td class="border px-4 py-2">Trigonometry</td><td class="border px-4 py-2">Physical World and Measurement</td></tr>
                <tr><td class="border px-4 py-2">Determinant</td><td class="border px-4 py-2">Kinematics and Kinetic Theory</td></tr>
                <tr><td class="border px-4 py-2">Set, Relation & Functions</td><td class="border px-4 py-2">Laws of Motion</td></tr>
                <tr><td class="border px-4 py-2">Logarithm</td><td class="border px-4 py-2">Work, Energy, and Power</td></tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Test Centres -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Test Centres</h2>
        <table class="w-full table-auto border border-gray-300 text-gray-700">
            <thead class="bg-gray-100">
                <tr>
                    <th class="border px-4 py-2">State</th>
                    <th class="border px-4 py-2">City</th>
                </tr>
            </thead>
            <tbody>
                <tr><td class="border px-4 py-2">Maharashtra</td><td class="border px-4 py-2">Pune</td></tr>
                <tr><td class="border px-4 py-2"></td><td class="border px-4 py-2">Navi Mumbai</td></tr>
                <tr><td class="border px-4 py-2">Delhi</td><td class="border px-4 py-2">New Delhi</td></tr>
                <tr><td class="border px-4 py-2">Telangana</td><td class="border px-4 py-2">Hyderabad</td></tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Required Documents -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Required Documents</h2>
        <ol class="text-gray-700 text-base md:text-lg leading-relaxed list-decimal pl-6 space-y-2">
            <li>Active Mobile Number and Email ID</li>
            <li>Scanned Photograph (JPEG, max 50 KB)</li>
            <li>Signature (max 30 KB)</li>
            <li>Class 10 & 12 Mark Sheets</li>
            <li>Aadhaar Card</li>
        </ol>
    </div>
</div>

<!-- FAQ -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">FAQ</h2>
        <ul class="text-gray-700 text-base md:text-lg leading-relaxed list-disc pl-6 space-y-4">
            <li>
                <b>Who is eligible for COMEDK?</b><br>
                Students must have completed 10+2 with Physics, Mathematics and one optional subject.
            </li>
            <li>
                <b>What is COMEDK application fee?</b><br>
                Rs 1800 for COMEDK UGET, Rs 2950 for both COMEDK & UniGAUGE + convenience charges.
            </li>
            <li>
                <b>Does COMEDK have negative marking?</b><br>
                No negative marking in the exam.
            </li>
        </ul>
    </div>
</div>

</body>
</html>
