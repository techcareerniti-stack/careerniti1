<?php
// required_docs_comedk.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK Required Documents</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8 poppins-regular">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Required Documents</h2>
        <p class="text-gray-700 leading-relaxed">
            Photograph of Candidate, Signature of Candidate, Signature of Parent/Guardian, Unique ID Proof of Candidate/Parent, SSLC/10th Marks Card of Candidate.
        </p>
    </div>
</div>

</body>
</html>
