<?php
// faq_comedk.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK FAQ</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Frequently Asked Questions (FAQs)</h2>

        <ul class="text-gray-700 text-base md:text-lg leading-relaxed space-y-6 list-disc pl-6">
            <li>
                <b>Que 1: What computer knowledge is required to appear for Computer Based Test mode?</b>
                <div><b>Ans:</b> The candidate needs to know how to operate the computer mouse.</div>
            </li>

            <li>
                <b>Que 2: What will be the medium of UGET 2023 Online Computer Based Test?</b>
                <div><b>Ans:</b> Medium of Examination will be English Language only.</div>
            </li>

            <li>
                <b>Que 3: What will happen in case there is some problem in computer during the examination?</b>
                <div><b>Ans:</b> There will be enough buffer systems available in the examination center to take care of such problems, and time lost in change of system will be duly taken care as each and every second will be recorded by the server.</div>
            </li>

            <li>
                <b>Que 4: Will there be a question booklet like in offline examination?</b>
                <div><b>Ans:</b> In Online Computer based test, the questions will appear on computer screen along with the answer options. Instruction page will also be displayed before the actual test begins. The time of reading of instructions will not be part of examination duration.</div>
            </li>

            <li>
                <b>Que 5: How will I answer a question in UGET 2023 computer-based test?</b>
                <div><b>Ans:</b> There will be four options for each question. You have to click one of the options using your computer mouse which can be reviewed or re-answered any time during the duration of the examination.</div>
            </li>

            <li>
                <b>Que 6: Can I change my answer during the exam?</b>
                <div><b>Ans:</b> You can change your answer any number of times before completing the session for the exam online.</div>
            </li>

            <li>
                <b>Que 7: Is the Entrance Test open only to Karnataka students?</b>
                <div><b>Ans:</b> No, this test is open to all the eligible students in the country.</div>
            </li>

            <li>
                <b>Que 8: Are candidates applying from outside the State of Karnataka eligible to get the benefit of lower eligibility qualifying marks?</b>
                <div><b>Ans:</b> SC/ST and OBC candidates belonging to Karnataka are only eligible to get the benefit of lower eligible qualifying marks.</div>
            </li>

            <li>
                <b>Que 9: I have finished my 2nd PUC /12th STD a few years ago. Am I eligible for these courses?</b>
                <div><b>Ans:</b> For B.Tech stream you would be eligible as per the norms of AICTE/VTU.</div>
            </li>

            <li>
                <b>Que 10: Is there an age limit for the course?</b>
                <div><b>Ans:</b> For B.Tech stream you would be eligible as per the norms of AICTE/VTU.</div>
            </li>
        </ul>
    </div>
</div>

</body>
</html>
