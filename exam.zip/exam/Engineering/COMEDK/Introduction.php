<?php
// introduction_comedk.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK Introduction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8 poppins-regular">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Introduction</h2>
        
        <p class="text-gray-700 leading-relaxed mb-4">
            COMEDK is the “Consortium of Medical, Engineering and Dental Colleges of Karnataka” – an autonomous merit determination authority consisting of senior academicians and reputed administrative officers who have been associated with the educational eco system. This autonomous COMEDK was entrusted the responsibility to organize testing procedures to determine the merit of aspiring students in an effective, fair, transparent and non-exploitative procedure by KPCF (Karnataka Professional Colleges Foundation –Medical & Dental) and KUPECA (Karnataka Unaided Private Engineering Colleges Association). By this, COMEDK has been serving 16 Medical, 24 Dental and around 150 Engineering Colleges. COMEDK since its inception in 2004-05 has been conducting the annual entrance exam for Undergraduate and Postgraduate courses in the participating institutions and has also been organizing single window centralized counseling process over the last 18 years. In all these years, the efforts of COMEDK have been appreciated by all the Government appointed Admission Overseeing Committees and also been mentioned by the Hon’ble Supreme Court as a model examination.
        </p>

        <p class="text-gray-700 leading-relaxed mb-4">
            Subsequent to the National Eligibility-cum-Entrance Test (NEET) being mandated as the only acceptable entrance exam for admission to Medical and Dental courses in the country, COMEDK continues the evaluation process for the members of KUPECA i.e., around 150 Engineering colleges. For the current academic year 2024-25, COMEDK would conduct an online examination all over India on Sunday, 12 May 2024, across 200+ cities, in 400+ centers for Engineering programs, which offer around 20,000+ seats and will be followed by online counseling.
        </p>

        <p class="text-gray-700 leading-relaxed mb-4">
            Karnataka having been pioneers in establishing premier professional higher educational institutions, still continues to be the most preferred destination for students who seek quality in established colleges.
        </p>

        <p class="text-gray-700 leading-relaxed mb-4">
            The said test will be held keeping in view the triple test criteria of being fair, transparent and non-exploitative and to ensure merit-based admissions through a single common entrance test followed by centralized Online counseling as envisaged by the Hon’ble Supreme Court in TMA Pai Foundation Vs. the State (2002) 8 SCC 481, Islamic Academy of Education Vs. the State reported in (2003) 6 SCC 697 and PA Inamdar Vs. the State of Maharashtra reported in (2005) 6 SCC 537.
        </p>

        <p class="text-gray-700 leading-relaxed mb-4">
            This Brochure provides a fair idea as to how and what the candidates have to follow as procedure for filling the application, eligibility criteria, test procedures, eligibility to participate in seat selection process, mandatory certificates/documents to be produced, securing the Test Admission Ticket, the malpractices and the measures required to be observed for avoiding the same, consequences of such malpractices, etc.
        </p>

        <p class="text-gray-700 leading-relaxed">
            Applicants are required to read this brochure thoroughly, so as to familiarize themselves and adhere to the rules strictly. Further, COMEDK’s website <a href="https://www.comedk.org" class="text-blue-600 underline" target="_blank">www.comedk.org</a> contains information and current updates/alerts. This site is updated regularly. COMEDK suggests all applicants to visit it frequently for relevant information.
        </p>

    </div>
</div>

</body>
</html>
