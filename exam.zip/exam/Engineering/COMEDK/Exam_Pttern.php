<?php
// exam_pattern_comedk.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK Exam Pattern</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Exam Pattern</h2>

        <ul class="text-gray-700 text-base md:text-lg leading-relaxed list-disc pl-6 space-y-4">

            <li>
                <b>Subjects:</b> Physics, Chemistry, Mathematics
                <ol class="list-decimal list-inside pl-5 space-y-1 mt-2">
                    <li>Physics: 60 MCQ</li>
                    <li>Chemistry: 60 MCQ</li>
                    <li>Mathematics: 60 MCQ</li>
                    <li>Total Questions: 180</li>
                    <li>Medium of Examination: English only</li>
                </ol>
            </li>

            <li>
                <b>Scoring:</b>
                <ol class="list-decimal list-inside pl-5 space-y-1 mt-2">
                    <li>Correct Answer: 1 mark each</li>
                    <li>No negative marking for wrong answers</li>
                    <li>Total Marks: 180</li>
                </ol>
            </li>

            <li>
                <b>Tie-Breaking Rules (in case of ties in total percentile scores):</b>
                <ol class="list-decimal list-inside pl-5 space-y-1 mt-2">
                    <li>Higher Percentile score of Physics and Mathematics marks taken together</li>
                    <li>Higher Percentile score in Mathematics</li>
                    <li>Higher Percentile score in Chemistry</li>
                </ol>
            </li>

            <li>
                <b>Age of the Candidate:</b>
                <ol class="list-decimal list-inside pl-5 space-y-1 mt-2">
                    <li>The elder candidate is ranked higher than the younger candidate. This detailed yet concise presentation provides all the essential information about the B.E. examination, including subject details, scoring, medium of examination, and tie-breaking rules, in an organized and visually appealing manner.</li>
                </ol>
            </li>

        </ul>
    </div>
</div>

</body>
</html>
