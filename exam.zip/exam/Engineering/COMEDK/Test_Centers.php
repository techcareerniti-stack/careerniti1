<?php
// test_centres_comedk.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK Test Centres</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8 poppins-regular">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Test Centres</h2>
        <p class="text-gray-700 mb-4">
            COMEDK offers test centers across various cities in India, providing
            candidates with a wide range of options to take the entrance examination.
        </p>
        <p class="text-gray-700 mb-2">
            In Maharashtra, the test centers include:
        </p>
        <ul class="list-disc pl-6 space-y-1 text-gray-700" id="comedk-testcentreList">
            <li>Aurangabad</li>
            <li>Kolhapur</li>
            <li>Latur</li>
            <li>Mumbai / Navi Mumbai</li>
            <li>Nagpur</li>
            <li>Nanded</li>
            <li>Nashik</li>
            <li>Pune</li>
            <li>Raigad</li>
            <li>Sangli</li>
            <li>Satara</li>
            <li>Solapur</li>
            <li>Thane</li>
        </ul>
    </div>
</div>

</body>
</html>
