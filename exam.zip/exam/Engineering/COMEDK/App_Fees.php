<?php
// app_fees.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK Application Fees</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Application Fees Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Application Fees</h2>

        <!-- Fees Table -->
        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-300">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="border px-4 py-2 text-left">Stream</th>
                        <th class="border px-4 py-2 text-left">Fees (IN RS.)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="border px-4 py-2">COMEDK UGET (PCM)</td>
                        <td class="border px-4 py-2">Rs 1800 + *Convenience charge/fee as applicable</td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2">BOTH COMEDK AND UNIGAUGE (PCM)</td>
                        <td class="border px-4 py-2">Rs 2950 + *Convenience charge/fee as applicable</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Note -->
        <p class="text-gray-700 text-base md:text-lg mt-4">
            *Please note that additional convenience charges/fees may apply. This clear tabular representation provides a concise overview of the fees for different streams in a visually appealing format.
        </p>

    </div>
</div>

</body>
</html>
