<?php
// imp_dates_comedk.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK Important Dates</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Important Dates</h2>

        <table class="w-full text-left border border-gray-300">
            <thead class="bg-gray-100">
                <tr>
                    <th class="border p-2">Event</th>
                    <th class="border p-2">Dates</th>
                </tr>
            </thead>
            <tbody class="text-gray-700">
                <tr>
                    <td class="border p-2">Start date for registration and issue of online Application.</td>
                    <td class="border p-2">1st February 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Mock test made available online.</td>
                    <td class="border p-2">15th February 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Last date for online payments and Submission of completed application online.</td>
                    <td class="border p-2">05th April 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Start date to edit select fields in the application form.</td>
                    <td class="border p-2">12th April 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Last date to edit select fields in the application form.</td>
                    <td class="border p-2">16th April 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Start date for download of Test Admission Ticket on the website.</td>
                    <td class="border p-2">06th May 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Last date for downloading of Online Test Admission Ticket (TAT).</td>
                    <td class="border p-2">12th May 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">COMEDK UGET & Uni-GAUGE E 2024 Engineering Entrance Exam (Morning and Afternoon Sessions).</td>
                    <td class="border p-2">12th May 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Publishing of Provisional Answer Keys and start date for Online submission of objections/challenge of Provisional Answer keys.</td>
                    <td class="border p-2">14th May 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Last date for receiving challenges/objections pertaining to Provisional Answer Keys.</td>
                    <td class="border p-2">16th May 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Publishing of Final Answer keys.</td>
                    <td class="border p-2">21st May 2024</td>
                </tr>
                <tr>
                    <td class="border p-2">Test Score cards made available online to the candidates.</td>
                    <td class="border p-2">24th May 2024</td>
                </tr>
            </tbody>
        </table>

        <p class="mt-4 text-gray-600">This table format presents the schedule clearly and systematically for easy reference.</p>
    </div>
</div>

</body>
</html>
