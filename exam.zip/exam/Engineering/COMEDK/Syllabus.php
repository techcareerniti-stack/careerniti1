<?php
// syllabus_comedk.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK Syllabus</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8 poppins-regular">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Syllabus</h2>
        <ul class="list-disc pl-6 space-y-2 text-gray-700 leading-relaxed">
            <li><b>The Entrance Test is based on the CBSE syllabus as given below:</b>
                <ol class="list-decimal pl-5 mt-2 space-y-1">
                    <li>11th STD - 2022-23 Syllabus</li>
                    <li>12th STD - 2023-24 Syllabus</li>
                </ol>
            </li>
        </ul>
    </div>
</div>

</body>
</html>
