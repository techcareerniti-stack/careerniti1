<?php
// eligibility_comedk.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK Eligibility</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Eligibility</h2>
        
        <!-- UG Engineering Courses Eligibility -->
        <ul class="text-gray-700 text-base md:text-lg leading-relaxed list-disc pl-6 space-y-4">
            <li><b>UG Engineering Courses Eligibility:</b></li>
            <ol class="list-decimal list-inside pl-5 space-y-2">
                <li>Qualifying Exam: 10+2 or equivalent recognized by State/Central Government.</li>
                <li>Subjects: Physics, Chemistry, and Mathematics with English as a compulsory subject.</li>
                <li>General Merit: Minimum 45% aggregate (40% for SC, ST, OBC candidates of Karnataka) in PCM.</li>
                <li>Optional Subjects: Compulsory subjects are Physics and Mathematics, along with Chemistry, Bio Tech, Biology, Comp Science, or Electronics. COMEDK Test Attempt: One attempt is sufficient for rank consideration. Diploma Holders: Not eligible for lateral entry admission.</li>
            </ol>

            <!-- UG Architecture Courses Eligibility -->
            <li><b>UG Architecture Courses Eligibility:</b></li>
            <ol class="list-decimal list-inside pl-5 space-y-2">
                <li>Qualifying Exam: 10+2 with 50% aggregate in PCM (45% for SC, ST, OBC candidates of Karnataka), or 10+3 Diploma with 50% aggregate in Mathematics (45% for SC, ST, OBC candidates of Karnataka).</li>
                <li>NATA: All candidates, including SC, ST, and OBC candidates, must pass the NATA with qualifying marks.</li>
                <li>No COMEDK Entrance Test for B. Arch.</li>
                <li>Separate application for B. Arch counseling required.</li>
                <li>For more details, refer to the COMEDK website.</li>
            </ol>
        </ul>
    </div>
</div>

</body>
</html>
