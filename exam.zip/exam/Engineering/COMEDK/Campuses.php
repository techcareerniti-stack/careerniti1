<?php
// campuses.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COMEDK Campuses</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Scroll to top -->
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<!-- Campuses Section -->
<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">

        <!-- Title -->
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Campuses</h2>

        <!-- Description -->
        <p class="text-gray-700 text-base md:text-lg leading-relaxed">
            After successfully clearing the COMEDK entrance examination, you can seek admission in various engineering and architecture colleges in Karnataka that are affiliated with COMEDK. The participating institutions include a wide range (around 150) of private colleges offering B.Tech (Engineering) and B.Arch (Architecture) programs. Some of these institutions are well-established and renowned for their quality education. COMEDK's centralized counseling process allows you to select from the list of available colleges and programs based on your rank in the entrance exam. The exact list of colleges and programs may vary from year to year, so it's recommended to refer to the official COMEDK website for the most up-to-date information on participating colleges and the admission process.
        </p>

    </div>
</div>

</body>
</html>
