import { useEffect } from "react";
import "../MHTCET/AvailableCourse.css";


function Availablecourse() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="cet-avlcourseSection">
            <div className="cet-avlcourseContent poppins-regular">
                <div>
                    <h2 className="cet-heading">Available Courses</h2>
                </div>
                <div>
                    <ul className="cet-avlblCourseList">
                        <li><b>Hotel Management :-</b> Candidates who have qualified for MHT CET can apply for hotel management courses.</li>
                        <li><b>Bachelor of Architecture (B. Arch) :-</b> Candidates who have qualified for MHT CET can apply for Bachelor of Architecture courses.</li>
                        <li><b>Bachelor of Business Administration (BBA) :-</b> Candidates who have qualified for MHT CET can apply for Bachelor of Business Administration courses.</li>
                        <li><b>Pharmacy (B. Pharm.) :-</b> Candidates who have qualified for MHT CET can apply for Pharmacy courses.</li>
                    </ul>
               
                </div>
            </div>
        </div>
    )
}

export default Availablecourse;