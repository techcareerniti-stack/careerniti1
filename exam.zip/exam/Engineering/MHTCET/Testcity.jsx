import { useEffect } from "react";
import "../MHTCET/Testcity.css";


function Testcity() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="cet-testcitySection">
            <div className="cet-testcityContent poppins-regular">
                <div>
                    <h2 className="cet-heading">Test Center</h2>
                </div>
                <div>
                    <ul className="cet-testcityList">
                        <li><b>MHT CET 2024 Exam Centres List In Maharashtra :-</b></li>
                        <table className="cet-testcityTbl">
                            <thead>
                                <td className="table-heading">Districts</td>
                                <td className="table-heading">Centre</td>
                                <td className="table-heading">Centre Code</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td rowSpan={5}>Mumbai</td>
                                    <td>Mumbai</td>
                                    <td>11</td>
                                </tr>
                                <tr>
                                    <td>Mumbai Sub Urban</td>
                                    <td>12</td>
                                </tr>
                               
                                <tr>
                                    <td>Thane</td>
                                    <td>13</td>
                                </tr>
                                <tr>
                                    <td>Palghar</td>
                                    <td>14</td>
                                </tr>
                                <tr>
                                    <td>Raigad</td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <td rowSpan={4}>Pune</td>
                                    <td>Pune</td>
                                    <td>16</td>
                                </tr>
                                <tr>
                                    <td>Ahmednagar</td>
                                    <td>17</td>
                                </tr>
                                <tr>
                                    <td>Solapur</td>
                                    <td>18</td>
                                </tr>
                                <tr>
                                    <td>Satara</td>
                                    <td>19</td>
                                </tr>
                                <tr>
                                    <td rowSpan={4}>Miraj (Sangli)</td>
                                    <td>Sangli</td>
                                    <td>20</td>
                                </tr>
                                <tr>
                                    <td>Kolhapur</td>
                                    <td>21</td>
                                </tr>
                                <tr>
                                    <td>Ratnagiri</td>
                                    <td>22</td>
                                </tr>
                                <tr>
                                    <td>Sindhudurg</td>
                                    <td>23</td>
                                </tr>
                                <tr>
                                    <td rowSpan={4}>Dhule</td>
                                    <td>Jalgaon</td>
                                    <td>24</td>
                                </tr>
                                <tr>
                                    <td>Dhule</td>
                                    <td>25</td>
                                </tr>
                                <tr>
                                    <td>Nandurbar</td>
                                    <td>26</td>
                                </tr>
                                <tr>
                                    <td>Nashik</td>
                                    <td>27</td>
                                </tr>
                                <tr>
                                    <td rowSpan={4}>Aurangabad</td>
                                    <td>Aurangabad</td>
                                    <td>28</td>
                                </tr>
                                <tr>
                                    <td>Jalna</td>
                                    <td>29</td>
                                </tr>
                                <tr>
                                    <td>Beed</td>
                                    <td>30</td>
                                </tr>
                                <tr>
                                    <td>Osmanabad</td>
                                    <td>31</td>
                                </tr>
                                <tr>
                                    <td rowSpan={4}>Nanded</td>
                                    <td>Nanded</td>
                                    <td>32</td>
                                </tr>
                                <tr>
                                    <td>Parbhani</td>
                                    <td>33</td>
                                </tr>
                                <tr>
                                    <td>Latur</td>
                                    <td>34</td>
                                </tr>
                                <tr>
                                    <td>Hingoli</td>
                                    <td>35</td>
                                </tr>
                                <tr>
                                    <td rowSpan={5}>Akola</td>
                                    <td>Buldhana</td>
                                    <td>36</td>
                                </tr>
                                <tr>
                                    <td>Akola</td>
                                    <td>37</td>
                                </tr>
                                <tr>
                                    <td>Washim</td>
                                    <td>38</td>
                                </tr>
                                <tr>
                                    <td>Amravati</td>
                                    <td>39</td>
                                </tr>
                                <tr>
                                    <td>Yavatmal</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td rowSpan={6}>Nagpur</td>
                                    <td>Wardha</td>
                                    <td>41</td>
                                </tr>
                                <tr>
                                    <td>Nagpur</td>
                                    <td>42</td>
                                </tr>
                                <tr>
                                    <td>Bhandara</td>
                                    <td>43</td>
                                </tr>
                                <tr>
                                    <td>Gondia</td>
                                    <td>44</td>
                                </tr>
                                <tr>
                                    <td>Chandrapur</td>
                                    <td>45</td>
                                </tr>
                                <tr>
                                    <td>Gadchiroli</td>
                                    <td>46</td>
                                </tr>
                            </tbody>
                        </table>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Testcity;