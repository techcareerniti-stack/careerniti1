import { useEffect } from "react";
import "../MHTCET/Campus.css";


function Campus() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="cet-campusSection">
            <div className="cet-campusContent poppins-regular ">
                <div>
                    <h2 className="cet-heading">Campus</h2>
                </div>
                <div>
                    <ul >
                        <li>
                        All Government ,  Private colleges and deemed universities.
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Campus;