import { useEffect } from "react";
import "../MHTCET/Introduction.css";


function Introduction() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="cet-introSection">
            <div className="cet-introContent poppins-regular">
                <div>
                    <h2 className="cet-heading">Introduction</h2>
                </div>
                <div>
                    <ul>
                        <li>
                            <div className="intro-para">

                                The Government of Maharashtra has established "ADMISSIONS REGULATING AUTHORITY AND STATE COMMON ENTRANCE TEST CELL" as per the provisions of the Maharashtra Unaided Private Professional Educational Institutions (Regulation of Admissions & Fees) Act. 2015 (Mah. Act No. XXVIII of 2015), (herein after the Act).
                                <br /><br />
                                The Commissioner of State CET Cell, has been designated as Competent Authority for conducting MHT-CET 2024 and selection of candidates for admission to the first year of Bachelor of Engineering and Technology, Planning, Planning Courses and First Year of Master of Engineering and Technology (Integrated), Pharm. D PG course for the Academic Year 2024-25.
                                <br /><br />
                                In exercise of the powers conferred by section 23 of the Maharashtra Unaided Private Professional Educational Institutions (Regulation of Admissions and Fees) Act, 2015 (Mah. XXVIII of 2015), the Government of Maharashtra has notified the rules to regulate the admissions to the First and Direct Second Year of Full Time Professional Undergraduate Technical Courses (Engineering and Technology, Pharmacy, Pharm D., Architecture, Hotel Management and Catering Technology). These rules are called the Maharashtra Unaided Private Professional Educational Institutions (Regulation of Admissions to the Full Time Professional Undergraduate Technical Courses) Rules, 2017. The admissions shall be carried out as per these Rules and its amendment from time to time. These rules are also
                                applicable for admissions in Government and Government Aided professional educational institutions including ICT, Mumbai as per Government Resolution TEM2016/C.R.473/16/TE-4 dated 25th April, 2017.


                                {/* The MHT-CET or Common Entrance Test is an annual entrance exam conducted by the Government of Maharashtra.] It is conducted by the Directorate of Technical Education. The degree courses of the following streams are mainly accounted for in this entrance exam :-
                            <ul className="cet-introList">
                                <li><a href="https://en.wikipedia.org/wiki/Engineering" target="_blank" rel="noopener noreferrer">Engineering</a></li>
                                <li><a href="https://en.wikipedia.org/wiki/Pharmacy" target="_blank" rel="noopener noreferrer">Pharmacy</a></li>
                            </ul> */}

                            </div>
                        </li>
                    </ul>

                </div>
            </div>
        </div>
    );
}
export default Introduction;