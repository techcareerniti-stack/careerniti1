import { useEffect } from "react";
import "../MHTCET/RequiredDoc.css";


function RequiredDoc() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return ( 
        <div className="cet-requiresdocSection">
            <div className="cet-requireddocContent poppins-regular">
                <div>
                    <h2 className="cet-heading">Required Documents</h2>
                </div>
                <div>
                    <ol>
                        <li>Class 10 mark sheet.</li>
                        <li>Class 12 mark sheet.</li>
                        <li>Date of Birth proof.</li>
                        <li>Address proof.</li>
                        <li>Caste category certificate (if applicable).</li>
                        <li>Domicile certificate.</li>
                        <li>Scanned images of photographs and signatures.</li>
                        <li>Credit/Debit card or Internet banking details for fee payment.</li>
                    </ol>
                </div>
            </div>
        </div>
     );
}

export default RequiredDoc;