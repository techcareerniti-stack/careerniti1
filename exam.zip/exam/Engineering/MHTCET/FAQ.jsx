import { useEffect } from "react";
import "../MHTCET/FAQ.css";


function FAQ() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="cet-faqSection">
            <div className="cet-faqContent poppins-regular">
                <div>
                    <h2 className="cet-heading">FAQ Section</h2>
                </div>
                <div className="cet-faqInfo">
                    <ul className="faq-list">
                        <li>
                            <b>Que 1:- What is the last date of MHT CET 2024?</b>
                            <div>
                                <b>Ans:-</b> The MHT CET application form 2024 last date without late fee was April 15. However, applicants were able to fill the MHT CET 2024 application form till May 11 with an additional fee of Rs 500.
                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 2:- Can I apply for the MHT CET exam in offline mode?</b>
                            <div>
                                <b>Ans:-</b> No, the MHT CET 202 registration form was available in online mode only.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 3:- What is the MHT CET 2024 official website?</b>
                            <div>
                                <b>Ans:-</b>The official website of MHT CET 2022 is  <a href="https://cetcell.mahacet.org/" target="_blank" rel="noopener noreferrer">mhtcet2024.mahacet.org</a>
                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 4:- What is the expected date of MHT CET 2024
                            </b>
                            <div>
                                <b>Ans:-</b>The State Cet Cell, Maharashtra has announced the MHT CET exam dates 2024. The MHT CET for the PCM group are April 26 to 30 and for PCB group, the exam will be held from April 26, 2024.

                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 5:- Is MHT CET 2024 online or offline?
                            </b>
                            <div>
                                <b>Ans:-</b> The MHT CET 2024 will be conducted as a computer based test (online).

                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 6:- What will be the pattern of the Maharashtra CET 2024 examination?</b>
                            <div>
                                <b>Ans:-</b> As per the Maharashtra CET exam pattern, the MHT CET exam will be conducted in online mode having three sections in the exam- Physics, Chemistry and Mathematics of 100 marks each.    

                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 7:- What is the MHT CET 2024 syllabus based on?
</b>
                            <div>
                                <b>Ans:-</b>The MHT CET 2024 questions will be prepared on the basis of Class 11th and 12th syllabus of Maharashtra State Board of Secondary and Higher Secondary Education.

                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 8:- When and how can I download MHT CET admit card 2024?
</b>
                            <div>
                                <b>Ans:-</b>The authorities have not yet announced the MHT CET 2024 admit card date. When released, students will be able to download the hall tickets from the official website using their application number and password.



                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 9:-  Can I change my choice of examination centre?
</b>
                            <div>
                                <b>Ans:-</b> No, students will not be allowed to request change in the exam centre. The authorities will release the details on the MHT CET allotted exam centre in the admit card.

                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 10:-  How to download the MHT CET results 2024?
</b>
                            <div>
                                <b>Ans:-</b> To download the MHT CET 2024 results, students will have to visit the official website and login to the result link using their application number and password.
                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 11:-  Who is eligible for MHT CET counselling registration?</b>
                            <div>
                                <b>Ans:-</b> Only those aspirants who will qualify the entrance exam will be eligible to participate in the MHT CET 2024 counselling and seat allotment.



                            </div>
                        </li>

                       
                    </ul>

                </div>
            </div>
        </div>
    );
}

export default FAQ;