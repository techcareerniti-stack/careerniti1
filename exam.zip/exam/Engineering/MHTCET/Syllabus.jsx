import { useEffect } from "react";
import "../MHTCET/Syllabus.css";


function Syllabus() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="cet-syllabusSection">
            <div className="cet-syllabusContent poppins-regular">
                <div>
                    <h2 className="cet-heading">Syllabus</h2>
                </div>
                <div>
                    <ul>
                        <b>MHT CET Syllabus 2024 for Physics :-</b>
                        <table className="cet-syllabusTbl">
                            <thead>
                                <td  className="table-heading">Subject</td>
                                <td  className="table-heading">11th Standard Topics</td>
                                <td  className="table-heading">12th Standard Topics</td>
                                <td  className="table-heading">MHT CET Physics <br /> syllabus PDF</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Physics</td>
                                    <td>
                                        <ul className="cet-syllabusList">
                                            <li>Measurements</li>
                                            <li>Scalars and Vectors</li>
                                            <li>Force</li>
                                            <li>Friction in solids <br /> and liquids</li>
                                            <li>Refraction of Light</li>
                                            <li>Ray optics</li>
                                            <li>Magnetic effect of <br /> electric current</li>
                                            <li>Magnetism</li>
                                        </ul>
                                    </td>
                                    <td>
                                        <ul className="cet-syllabusList">
                                            <li>Circular motion</li>
                                            <li>Gravitation</li>
                                            <li>Rotational motion</li>
                                            <li>Oscillations</li>
                                            <li>Elasticity</li>
                                            <li>Surface tension</li>
                                            <li>Wave motion</li>
                                            <li>Stationary waves</li>
                                            <li>Wave theory of light</li>
                                            <li>Interference and diffraction</li>
                                            <li>Electrostatics</li>
                                            <li>Current electricity</li>
                                            <li>Magnetism</li>
                                            <li>Electromagnetic inductions</li>
                                            <li>Electrons and photons</li>
                                            <li>Atoms Molecules and Nuclei</li>
                                            <li>Semiconductors</li>
                                            <li>Communication systems</li>
                                        </ul>
                                    </td>
                                    <td className="table-content">
                                        <a href="https://cetcell.mahacet.org/wp-content/uploads/2023/08/Technical_Education_CET_syllabus2024-25.pdf" target="_blank" rel="noopener noreferrer">Detailed Syllabus</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <br />

                        <b>MHT CET Syllabus 2024 for Chemistry :-</b>
                        <table className="cet-syllabusTbl">
                            <thead>
                                <td  className="table-heading">Subject</td>
                                <td  className="table-heading">11th Standard Topics</td>
                                <td  className="table-heading">12th Standard Topics</td>
                                <td  className="table-heading">MHT CET Chemistry <br /> syllabus PDF</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Chemistry</td>
                                    <td>
                                        <ul className="cet-syllabusList">
                                            <li>Some basic concepts <br /> of chemistry</li>
                                            <li>States of matter: Gases <br /> and liquids</li>
                                            <li>Redox reaction</li>
                                            <li>Surface chemistry</li>
                                            <li>Nature of chemical bond</li>
                                            <li>Hydrogen</li>
                                            <li>s-Block elements (Alkali <br /> and alkaline earth metals)</li>
                                            <li>Basic principles and <br /> techniques in <br />organic chemistry Alkanes</li>
                                        </ul>
                                    </td>
                                    <td>
                                        <ul className="cet-syllabusList">
                                            <li>Solid State</li>
                                            <li>Solutions and colligative</li>
                                            <li>Chemical thermodynamics <br />  and Electrochemistry</li>
                                            <li>Chemical kinetics- <br />General principles and <br /> processes</li>
                                            <li>p-Block elements</li>
                                            <li>d and f Block Elements</li>
                                            <li>Co-ordination compounds</li>
                                            <li>Halogen derivatives of alkanes, <br /> Alcohols, phenols, and ethers,</li>
                                            <li>Aldehydes, ketones, and <br /> Organic compounds</li>
                                            <li>Biomolecules</li>
                                            <li>Polymers</li>
                                            <li>Chemistry in everyday life</li>
                                            
                                        </ul>
                                    </td>
                                    <td className="table-content">
                                        <a href="https://cetcell.mahacet.org/wp-content/uploads/2023/08/Technical_Education_CET_syllabus2024-25.pdf" target="_blank" rel="noopener noreferrer">Detailed Syllabus</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <br />

                        <b>MHT CET 2024 Syllabus for Mathematics :-</b>
                        <table className="cet-syllabusTbl">
                            <thead>
                                <td className="table-heading">Subject</td>
                                <td  className="table-heading">11th Standard Topics</td>
                                <td  className="table-heading">12th Standard Topics</td>
                                <td  className="table-heading">MHT CET Mathematics <br /> syllabus PDF</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Mathematics</td>
                                    <td>
                                        <ul className="cet-syllabusList">
                                            <li>Trigonometric functions</li>
                                            <li>Trigonometric functions of <br /> Compound  Angles</li>
                                            <li>Factorization Formulae</li>
                                            <li>Straight Line</li>
                                            <li>Circle and Conics</li>
                                            <li>Sets Relations <br /> and Functions</li>
                                            <li>Probability</li>
                                            <li>Sequences and series</li>
                                        </ul>
                                    </td>
                                    <td>
                                        <ul className="cet-syllabusList">
                                            <li>Mathematical Logic</li>
                                            <li>Matrices</li>
                                            <li>Trigonometric functions</li>
                                            <li>Pair of straight lines</li>
                                            <li>Circle</li>
                                            <li>Conics</li>
                                            <li>Vectors</li>
                                            <li>Three-dimensional geometry</li>
                                            <li>Line</li>
                                            <li>Plane</li>
                                            <li>Linear programming problems</li>
                                            <li>Continuity</li>
                                            <li>Differentiation</li>
                                            <li>Applications of derivative</li>
                                            <li>Integration</li>
                                            <li>Applications of definite integral</li>
                                            <li>Statistics</li>
                                            <li>Probability distribution</li>
                                            <li>Bernoulli trials and <br /> Binomial distribution</li>
                                        </ul>
                                    </td>
                                    <td className="table-content">
                                        <a href="https://cetcell.mahacet.org/wp-content/uploads/2023/08/Technical_Education_CET_syllabus2024-25.pdf" target="_blank" rel="noopener noreferrer">Detailed Syllabus</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                       

                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Syllabus;