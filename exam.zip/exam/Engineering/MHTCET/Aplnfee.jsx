import { useEffect } from "react";
import "../MHTCET/Aplnfee.css";


function Aplnfee() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="jee-feeSection">
            <div className="jee-feeContent">
                <div>
                    <h2 className="jee-heading">Application Fee</h2>
                </div>
                <div>
                    <ul>
                        <table className="cet-feeTable">
                            <thead>
                                <td className="table-heading">MHT-CET 2024 Groups</td>
                                <td className="table-heading">General</td>
                                <td className="table-heading">Reserved Category <br /> (Maharashtra Candidates only)</td>
                                <td className="table-heading">PwD</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>PCM</td>
                                    <td className="numerical-data">INR 800</td>
                                    <td className="numerical-data">INR 600</td>
                                    <td className="numerical-data">INR 600</td>
                                </tr>
                                <tr>
                                    <td>PCB</td>
                                    <td className="numerical-data">INR 800</td>
                                    <td className="numerical-data">INR 600</td>
                                    <td className="numerical-data">INR 600</td>
                                </tr>
                            </tbody>
                        </table>

                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Aplnfee;