import { useEffect } from "react";
import "../MHTCET/Eligibility.css";


function Eligibility() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="cet-elgbltySection">
            <div className="cet-elgbltyContent poppins-regular">
                <div>
                    <h2 className="cet-heading">Eligibility</h2>
                </div>
                <div>
                    <ul>
                        All the candidates passed/ appearing at the qualifying examination i.e. HSC/12th Standard examination or its equivalent examination and having Indian Nationality are eligible for appearing for MHT-CET 2024. There is no age limit for admission and appearing to MHT-CET 2024.
                        <br /><br />
                    </ul>
                    <ol className="cet-elgbltyList">
                        <b>Candidate Type</b>
                        <li><b>Maharashtra State Candidate :- </b>A Candidate can claim only one type of Maharashtra State Candidature Type i.e. from Type A to E.
                        </li>
                        <br />
                        <table className="cet-elgbltTbl">
                            <thead>
                                <td className="table-heading">Type</td>
                                <td className="table-heading">Eligibility Criterion</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Type-A</td>
                                    <td>(i) Candidates passing SSC and also HSC from a recognized institution in Maharashtra State.
                                        <br />
                                        (ii) Candidate who is either Domicile of Maharashtra and/or is born in Maharashtra.
                                    </td>
                                </tr>
                                <tr>
                                    <td>Type-B</td>
                                    <td>A Candidate who does not fall in Type-A above, but who or whose Father or Mother <br /> is domiciled in the State of Maharashtra and possess Domicile Certificate.</td>
                                </tr>
                                <tr>
                                    <td>Type-C</td>
                                    <td>A Candidate who does not fall in either Type-A or Type-B but whose Father or Mother <br /> is an employee of the Government of India or Government of India Undertaking and <br /> who has been  posted and reported to duty in Maharashtra State before <br /> the last date for submission of Application Form for CAP.</td>
                                </tr>
                                <tr>
                                    <td>Type-D</td>
                                    <td>A Candidate who does not fall in any of the above Type-A, Type B and Type-C but whose Father <br /> or Mother is an employee or retired employee of the Government of Maharashtra <br /> or Government of Maharashtra Undertaking.</td>
                                </tr>
                                <tr>
                                    <td>Type-E</td>
                                    <td>Candidates passing SSC and/or HSC Examination from a recognized institution located in <br /> a Maharashtra Karnataka Border Area and whose Mother tongue is Marathi. <br /> The 865 village of Maharashtra Karnataka Border area notified by the <br /> State Government for this purpose shall be considered</td>
                                </tr>

                            </tbody>
                        </table>
                        <br />
                        <li><b>All India Candidature :- </b>The Candidates having Indian Nationality are eligible under this Category.
                        </li>
                        <br />
                        <li><b>Minority Candidature :-</b> The Candidate belonging to a particular Linguistic or Religious Minority Community from State of Maharashtra and as notified by the Government are eligible under this Category.
                        </li>
                        <br />
                        <li><b>Children of NRI / OCI / PIO, Children of Indian workers in the Gulf countries, Foreign National :-</b> These types of Candidature Candidates are exempted from appearing for MHT-CET 2024.</li>
                        To Know More <br />
                        <a href="https://cetcell.mahacet.org/wp-content/uploads/2023/12/Final_IB_MHT-CET-2024.pdf
" target="_blank" rel="noopener noreferrer">Refer This Link</a>
                    </ol>






                </div>
            </div>
        </div>
    );
}

export default Eligibility;