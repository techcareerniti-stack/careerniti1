import { useEffect } from "react";
import "../MHTCET/ExamPattern.css";


function ExamPattern() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="cet-examptrnSection">
            <div className="cet-examptrnContent poppins-regular">
                <div>
                    <h2 className="cet-heading">Exam Pattern</h2>
                </div>
                <div>
                    <ul className="cet-examptrnList">
                        <li><b>MHT CET marks distribution for PCM :-</b></li>
                        <table className="cet-examptrnTble">
                            <thead>
                                <tr>
                                    <td rowSpan={2} className="table-heading">Subject</td>
                                    <td colSpan={2} className="table-heading">Approximate number of questions</td>
                                    <td rowSpan={2} className="table-heading">Marks per question</td>
                                    <td rowSpan={2} className="table-heading">Total marks</td>
                                    <td rowSpan={2} className="table-heading">Duration in minutes</td>
                                </tr>
                                <tr>
                                    <td className="table-heading">Class XI</td>
                                    <td className="table-heading">Class XII</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Physics</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">40</td>
                                    <td className="numerical-data" rowSpan={2}>1 mark</td>
                                    <td className="numerical-data" rowSpan={2}>100</td>
                                    <td className="numerical-data" rowSpan={2}>90 minutes</td>
                                </tr>
                                <tr>
                                    <td>Chemistry</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">40</td>
                                </tr>
                                <tr>
                                    <td>Mathematics</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">40</td>
                                    <td className="numerical-data">2 marks</td>
                                    <td className="numerical-data">100</td>
                                    <td className="numerical-data">90 minutes</td>
                                </tr>

                            </tbody>
                        </table>

                        <br />

                        <li><b>MHT CET Exam Pattern for PCB :-</b></li>
                        <table className="cet-examptrnTble">
                            <thead>
                                <tr>
                                    <td rowSpan={2} className="table-heading">Subject</td>
                                    <td colSpan={2} className="table-heading">Approximate number of questions</td>
                                    <td rowSpan={2} className="table-heading">Marks per question</td>
                                    <td rowSpan={2} className="table-heading">Total marks</td>
                                    <td rowSpan={2} className="table-heading">Duration in minutes</td>
                                </tr>
                                <tr>
                                    <td className="table-heading">Class XI</td>
                                    <td className="table-heading">Class XII</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Physics</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">40</td>
                                    <td className="numerical-data" rowSpan={2}>1 mark</td>
                                    <td className="numerical-data" rowSpan={2}>100</td>
                                    <td className="numerical-data" rowSpan={2}>90 minutes</td>
                                </tr>
                                <tr>
                                    <td>Chemistry</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">40</td>
                                </tr>
                                <tr>
                                    <td>Biology</td>
                                    <td className="numerical-data">
                                        10 -(Botany) <br />
                                        10-(Zoology)
                                    </td>
                                    <td className="numerical-data">
                                        40 - (Botany) <br />
                                        40 - (Zoology)
                                    </td>
                                    <td className="numerical-data">2 marks</td>
                                    <td className="numerical-data">100</td>
                                    <td className="numerical-data">90 minutes</td>
                                </tr>

                            </tbody>
                        </table>




                    </ul>
                </div>
            </div>
        </div>
    );
}

export default ExamPattern;