import { useEffect } from "react";
import "../MHTCET/ImportantDate.css";


function Importantdate() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return ( 
        <div className="cet-impdateSection">
            <div className="cet-impdateContent">
                <div>
                    <h2 className="cet-heading">Important Dates</h2>
                </div>
                <div>
                    <ul className="cet-impdtList">
                        <li><b> MHT-CET 2024 :-</b></li>
                        <table className="cet-ImpdateTbl">
                            <thead>
                                <td className="table-heading">Particulars</td>
                                <td className="table-heading">Details</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Online registration & Confirmation of Application Form on website</td>
                                    <td>16th January 2024 (Tuesday) to 01 March, 2024 (Friday)</td>
                                </tr>
                                <tr>
                                    <td>Online registration & Confirmation of Application Form on website <br /> (with additional Late Fee of Rs. 500/- for all categories)</td>
                                    <td>02nd March 2024 (Saturday) to 08th March, 2024 (Friday)</td>
                                </tr>
                                <tr>
                                    <td>Payment Only through Online mode</td>
                                    <td>Upto 01 March, 2024 (Friday)</td>
                                </tr>
                                <tr>
                                    <td>Issue of Admit Card (through candidate login)</td>
                                    <td>To be notified later</td>
                                </tr>
                                <tr>
                                    <td>Date of the Examination (Tentative Dates) <br /> (Group wise shifts will be announced later on.)</td>
                                    <td>16 April 2024 (Tuesday) to 30 April 2024 (Tuesday)</td>
                                </tr>
                                <tr>
                                    <td>Centre of the Examination</td>
                                    <td>As indicated in the Admit Card</td>
                                </tr>
                               
                            </tbody>
                        </table>

                       

                        
                    </ul>
                </div>
            </div>
        </div>
     );
}

export default Importantdate;