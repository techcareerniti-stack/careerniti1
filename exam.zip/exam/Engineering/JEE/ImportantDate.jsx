import { useEffect } from "react";
import "../JEE/ImportantDate.css";


function Importantdate() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return ( 
        <div className="jee-impdateSection">
            <div className="jee-impdateContent">
                <div>
                    <h2 className="jee-heading">Important Dates</h2>
                </div>
                <div>
                    <ul className="jee-impdtList">
                        <li><b> Session-1: JEE (Main) - January 2024 :-</b></li>
                        <table className="jee-ImpdateTbl">
                            <thead>
                                <td className="table-heading">Activity</td>
                                <td className="table-heading">Day, Date and Time (IST)</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Online Registration for JEE (Main) 2024</td>
                                    <td>01 November 2023 to 30 November 2023 (up to 09:00 P.M.)</td>
                                </tr>
                                <tr>
                                    <td>Last date for fee payment of registered candidates</td>
                                    <td>30 November 2023 (up to 11:50 P.M.)</td>
                                </tr>
                                <tr>
                                    <td>Admit Card available for downloading</td>
                                    <td>03 days before the actual date of the Examination</td>
                                </tr>
                                <tr>
                                    <td>JEE (Main) 2024 Examination Date</td>
                                    <td>Between 24 January and 01 February 2024</td>
                                </tr>
                                <tr>
                                    <td>Declaration of results</td>
                                    <td>12 February 2024 </td>
                                </tr>
                            </tbody>
                        </table>

                        <br />

                        <li><b>Session-2: JEE (Main) - April 2024 :-</b></li>
                        <table className="jee-ImpdateTbl">
                            <thead>
                                <td className="table-heading">Event</td>
                                <td className="table-heading">Day, Date and Time (IST)</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Online Registration for JEE (Main) 2024</td>
                                    <td> 02 February 2024 to 02 March 2024 (up to 09:00 P.M.)</td>
                                </tr>
                                <tr>
                                    <td>Last date for fee payment of registered candidates</td>
                                    <td>02 March 2024 (up to 11:50 P.M.)</td>
                                </tr>
                                <tr>
                                    <td>Admit Card available for downloading</td>
                                    <td>03 days before the actual date of the Examination</td>
                                </tr>
                                <tr>
                                    <td>JEE (Main) 2024 Examination Date</td>
                                    <td>Between 01 April and 15 April 2024 </td>
                                </tr>
                                <tr>
                                    <td>Declaration of results</td>
                                    <td>25 April 2024</td>
                                </tr>
                            </tbody>
                        </table>

                        <br />

                    </ul>
                </div>
            </div>
        </div>
     );
}

export default Importantdate;