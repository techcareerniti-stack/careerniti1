<?php
function getAplnFee() {
    $fees = [
        "India" => [
            "Paper 1" => [
                ["category" => "General/Gen-EWS/OBC (NCL)", "male" => "₹1000", "female" => "₹800", "third" => "₹500"],
                ["category" => "SC/ST/PwD", "male" => "₹1000", "female" => "₹1000", "third" => "₹500"]
            ],
            "Combined Papers" => [
                ["category" => "General/Gen-EWS/OBC (NCL)", "male" => "₹2000", "female" => "₹1600", "third" => "₹1000"],
                ["category" => "SC/ST/PwD", "male" => "₹1000", "female" => "₹1000", "third" => "₹1000"]
            ]
        ],
        "Outside India" => [
            "Paper 1" => [
                ["category" => "General/Gen-EWS/OBC (NCL)", "male" => "₹5000", "female" => "₹4000", "third" => "₹3000"],
                ["category" => "SC/ST/PwD", "male" => "₹2500", "female" => "₹2500", "third" => "₹3000"]
            ],
            "Combined Papers" => [
                ["category" => "General/Gen-EWS/OBC (NCL)", "male" => "₹10000", "female" => "₹8000", "third" => "₹5000"],
                ["category" => "SC/ST/PwD", "male" => "₹5000", "female" => "₹5000", "third" => "₹5000"]
            ]
        ]
    ];

    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">Application Fee</h2>
        <?php foreach ($fees as $region => $papers): ?>
            <div class="mb-6">
                <h3 class="text-xl font-semibold mb-2">For Candidates <?= $region ?>:</h3>
                <?php foreach ($papers as $paper => $rows): ?>
                    <p class="mb-2 font-medium"><?= $paper ?>:</p>
                    <div class="overflow-x-auto">
                        <table class="min-w-full table-auto border border-gray-300 mb-4">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="border px-4 py-2">Category</th>
                                    <th class="border px-4 py-2">Male</th>
                                    <th class="border px-4 py-2">Female</th>
                                    <th class="border px-4 py-2">Third Gender</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows as $row): ?>
                                    <tr>
                                        <td class="border px-4 py-2"><?= $row['category'] ?></td>
                                        <td class="border px-4 py-2"><?= $row['male'] ?></td>
                                        <td class="border px-4 py-2"><?= $row['female'] ?></td>
                                        <td class="border px-4 py-2"><?= $row['third'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
?>
