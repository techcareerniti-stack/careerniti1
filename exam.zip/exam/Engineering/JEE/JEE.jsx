import "../BITSAT/BITSAT.css"
import Add_Navbar from "../../Add_Navbar";
import Introduction from "./Introduction";
import Eligibility from "./Eligibility";
import Availablecourse from "./AvailableCourse";
import Aplnfee from "./Aplnfee";
import ExamPattern from "./ExamPattern";
import Campus from "./Campus";
import ImportantDate from "./ImportantDate";

// import Syllabus from "./Syllabus";
// import Test_Centres from "./Test_Centers";
// import Required_Docs from "./Required_Docs";
// import FAQ from "./FAQ";


function JEE({path,setLoc,loc,setSelectedNotify}) {
  const formatLocation = (location) => {
    const parts = location.split("/").filter((part) => part !== "");
    const capitalizedParts = parts.map((part) => {
      if (part.toLowerCase() === "jeemains") {
        return "JEE MAINS";
      } else {
        return part.charAt(0).toUpperCase() + part.slice(1);
      }
    });

    return capitalizedParts.join(" > ");
  };

  return (
    <>
      <Add_Navbar
       introduction={<Introduction />}
       eligibility={<Eligibility />}
       available_courses={<Availablecourse />}
       campuses={<Campus />}
       application_fees={<Aplnfee />}
       imp_dates={<ImportantDate />}
       exam_pattern={<ExamPattern />}
    //    syllabus={}
    //    test_centres={}
    //    required_documents={}
    //    faq={}
       setLoc={setLoc} 
       path={path} 
       formatLocation={formatLocation}
       loc={window.location.pathname +loc}
       setSelectedNotify={setSelectedNotify}
       name="JEE MAINS"
       longform="[Joint Entrance Examination Mains]"/>

       <br/> 
    </>
  );
}

export default JEE;
