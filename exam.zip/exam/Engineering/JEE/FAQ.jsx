import { useEffect } from "react";
import "../JEE/FAQ.css";


function FAQ() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="jee-faqSection">
            <div className="jee-faqContent poppins-regular">
                <div>
                    <h2 className="jee-heading">FAQ Section</h2>
                </div>
                <div className="jee-faqInfo">
                    <ul className="faq-list">
                        <li>
                            <b>Que 1:- What is JEE Main?</b>
                            <div>
                                <b>Ans:-</b>JEE Main is a national-level entrance examination for admission to various engineering, architecture, and planning programs in India.
                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 2:- What are the different papers in JEE Main?</b>
                            <div>
                                <b>Ans:-</b> JEE Main has three papers: Paper 1 for B.E./B.Tech, Paper 2 for B.Arch, and Paper 3 for B.Planning.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 3:- Who can appear for JEE Main?</b>
                            <div>
                                <b>Ans:-</b>Candidates who have passed or are appearing for their 10+2 or equivalent examination can appear. There's no age limit for most candidates.
                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 4:-  How is JEE Main score used for admissions?</b>
                            <div>
                                <b>Ans:-</b>JEE Main score is used to apply for NITs, IIITs, other CFTIs, and some state colleges. It's also a qualifying exam for JEE Advanced.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 5:- How many times can I appear for JEE Main?</b>
                            <div>
                                <b>Ans:-</b> You can attempt JEE Main for a maximum of three consecutive years.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 6:-  Is Aadhaar card mandatory for JEE Main?</b>
                            <div>
                                <b>Ans:-</b>While Aadhaar is one valid form of identification, other government-issued IDs can also be used.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 7:- What is the marking scheme for JEE Main?</b>
                            <div>
                                <b>Ans:-</b>In Paper 1, MCQs have +4 for correct, -1 for incorrect; numerical questions have +4 for correct, no negative marking. Paper 2 and 3 have similar schemes.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 8:- Can I apply for both Paper 1 and 2?</b>
                            <div>
                                <b>Ans:-</b>Yes, candidates interested in both engineering and architecture can apply for both papers.

                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 9:- How can I prepare for JEE Main?</b>
                            <div>
                                <b>Ans:-</b>Focused self-study, coaching classes, mock tests, and solving previous years' papers can aid in preparation.

                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 10:- What's the syllabus for JEE Main?</b>
                            <div>
                                <b>Ans:-</b>The syllabus covers Physics, Chemistry, and Mathematics for Paper 1. Paper 2 focuses on Mathematics, Aptitude, and Drawing.
                            </div>
                        </li>

                        <br />
                        <li>
                            <b>Que 11:- What's the significance of JEE Advanced?</b>
                            <div>
                                <b>Ans:-</b>JEE Advanced is the gateway to the prestigious Indian Institutes of Technology (IITs) and some other top engineering institutions.
                            </div>
                        </li>

                        <br />
                        <li>
                            <b>Que 12:-Can I use a calculator during the exam?</b>
                            <div>
                                <b>Ans:-</b>No, electronic devices including calculators are generally not allowed inside the exam hall.

                            </div>
                        </li>

                        <br />
                        <li>
                            <b>Que 13:- When is JEE Main usually conducted?
                            </b>
                            <div>
                                <b>Ans:-</b>JEE Main is conducted twice a year, typically in January and April.

                            </div>
                        </li>

                        <br />
                        <li>
                            <b>Que 14:-  Can foreign nationals apply for JEE Main?
                            </b>
                            <div>
                                <b>Ans:-</b> Yes, foreign nationals can apply for JEE Main.

                            </div>
                        </li>

                        <br />
                        <li>
                            <b>Que 15:- What's the validity of JEE Main scores?
                            </b>
                            <div>
                                <b>Ans:-</b>JEE Main scores are valid for that particular academic year's admissions.

                            </div>
                        </li>

                        <br />
                        <li>
                            <b>Que 16:-  Can I make corrections in the application form after submission?</b>
                            <div>
                                <b>Ans:-</b>Yes, a correction window is usually provided for making corrections in the application form.

                            </div>
                        </li>

                    </ul>

                </div>
            </div>
        </div>
    );
}

export default FAQ;