import { useEffect } from "react";
import "../JEE/Testcity.css";


function Testcity() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="jee-testcitySection">
            <div className="jee-testcityContent poppins-regular">
                <div>
                    <h2 className="jee-heading">Test Center</h2>
                </div>
                <div>
                    <ul className="jee-testcityList">
                        <li>Exam centers are available across all over India.</li>
                        <br />
                        <li><b>Centres available in Maharashtra are :</b></li> 
                        <ol>
                            <li>Ahmednagar</li>
                            <li>Akola</li>
                            <li>Amravati</li>
                            <li>Aurangabad</li>
                            <li>Beed</li>
                            <li>Bhandara</li>
                            <li>Buldhana</li>
                            <li>Chandrapur</li>
                            <li>Dhule</li>
                            <li>Gondia</li>
                            <li>Jalgaon</li>
                            <li>Kolhapur</li>
                            <li>Latur</li>
                            <li>Mumbai City</li>
                            <li>Nagpur</li>
                            <li>Nanded</li>
                            <li>Nandurbar</li>
                            <li> Nashik</li>
                            <li>Osmanabad</li>
                            <li>Palghar</li>
                            <li>Parbhani</li>
                            <li>Pune</li>
                            <li> Raigad,</li>
                            <li>Ratnagiri</li>
                            <li> Sangli</li>
                            <li>Satara</li>
                            <li>Sindhudurg</li>
                            <li>Solapur</li>
                            <li>Thane</li>
                            <li>Wardha</li>
                            <li> Yavatmal</li>
                        </ol>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Testcity;