<?php
function getAvailableCourse() {
    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">Available Courses</h2>
        <ul>
            <li class="text-gray-700 leading-relaxed">
                The Joint Entrance Examination (JEE) opens doors to diverse educational pathways, offering students the chance to pursue B.E./B.Tech, B.Arch, and B.Planning degrees. This nationally recognized exam serves as a gateway to esteemed technical and architectural institutions. Aspiring minds can explore a range of engineering disciplines, architectural creativity, and urban planning expertise through this single platform, shaping their academic journey in innovative directions. JEE stands as a vital key to unlocking a world of possibilities in the realms of technology, design, and urban development.
            </li>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}
?>
