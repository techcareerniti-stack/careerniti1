<?php
function getCampus() {
    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">Campus</h2>
        <ul>
            <li class="text-gray-700 leading-relaxed">
                After the JEE Main exam, students have the opportunity to seek admission in various esteemed institutions across India. Depending on their JEE Main scores and ranks, they can apply for admission to National Institutes of Technology (NITs), Indian Institutes of Information Technology (IIITs), and other centrally funded technical institutions. Additionally, some state-level engineering colleges also consider JEE Main scores for admission. For those aspiring to pursue architecture, JEE Main Paper 2 is designated for B.Arch programs. Students can apply for admission to National Institutes of Technology (NITs), School of Planning and Architecture (SPAs), and other architecture colleges that accept JEE Main scores. Similarly, JEE Main Paper 3 is for B.Planning programs, allowing students to apply for admission in various planning institutes. In essence, the JEE Main exam paves the way for admission to a wide range of prestigious institutions offering B.E./B.Tech, B.Arch, and B.Planning programs, shaping students' academic and professional futures.
            </li>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}
?>
