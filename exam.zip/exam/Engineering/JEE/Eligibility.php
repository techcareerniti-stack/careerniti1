<?php
function getEligibility() {
    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">Eligibility</h2>
        <ul class="list-disc pl-5 space-y-4 text-gray-700">
            <li>
                <b>Age Criteria :-</b> For appearing in the JEE (Main) - 2024, there is no age limit for the candidates. The candidates who have passed the class 12/equivalent examination in 2022, 2023, or appearing in 2024 irrespective of their age can appear in JEE (Main) - 2024 examination. However, the candidates may be required to fulfill the age criteria of the Institute(s) to which they are desirous of taking admission.
            </li>
            
            <li>
                <b>Qualifying Examinations :-</b>
                <ol class="list-decimal pl-5 space-y-2">
                    <li>The final examination of the 10+2 system, conducted by any recognized Central/ State Board, such as the Central Board of Secondary Education, New Delhi; Council for the Indian School Certificate Examinations, New Delhi; etc.</li>
                    <li>Intermediate or two-year Pre-University examination conducted by a recognized Board/ University.</li>
                    <li>Final examination of the two-year course of the Joint Services Wing of the National Defense Academy.</li>
                    <li>Senior Secondary School Examination conducted by the National Institute of Open Schooling with a minimum of five subjects.</li>
                    <li>Any Public School/ Board/ University examination in India or any foreign country recognized as equivalent to the 10+2 system by the Association of Indian Universities (AIU).</li>
                    <li>Higher Secondary Certificate Vocational Examination.</li>
                    <li>A Diploma recognized by AICTE or a State board of technical education of at least 3 years duration.</li>
                    <li>General Certificate Education (GCE) examination (London/Cambridge/Sri Lanka) at the Advanced (A) level.</li>
                    <li>High School Certificate Examination of the Cambridge University or International Baccalaureate Diploma of the International Baccalaureate Office, Geneva.</li>
                    <li>Candidates who have completed the Class 12 (or equivalent) examination outside India or from a Board not specified above should produce a certificate from AIU to show equivalence.</li>
                    <li>If Class 12 Examination is not a public examination, the candidate must have passed at least one public (Board or Pre-University) examination earlier.</li>
                </ol>
            </li>

            <li>
                <b>Year of Appearance :-</b> Only those candidates who have passed the Class 12/equivalent examination in 2022, 2023, or appearing in 2024 are eligible. Others are not eligible to appear in JEE (Main) - 2024.
            </li>

            <li>
                <b>State of Eligibility :-</b> Determined by where 12th exam is passed, not residence. OCI and foreign nationals have specific criteria.
            </li>

            <li>
                <b>Improvement :-</b> State code based on first passing, not improvement attempts. NIOS candidates follow study center location.
            </li>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}
?>
