import { useEffect } from "react";
import "../JEE/Syllabus.css";


function Syllabus() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="jee-syllabusSection">
            <div className="jee-syllabusContent poppins-regular">
                <div>
                    <h2 className="jee-heading">Syllabus</h2>
                </div>
                <div>
                    <ul className="jee-syllabusList">
                        <li><b>Physics :-</b></li>
                        <ol>
                            <li>Mechanics</li>
                            <li>Thermodynamics</li>
                            <li>Electromagnetism</li>
                            <li> Optics</li>
                            <li> Modern Physics</li>
                        </ol>
                        <br />
                        <li><b>Chemistry :-</b></li>
                        <ol>
                            <li>Physical Chemistry</li>
                            <li>Inorganic Chemistry</li>
                            <li>Organic Chemistry</li>
                        </ol>

                        <br />

                        <li><b>Mathematics :-</b></li>
                        <ol>
                            <li>Algebra</li>
                            <li> Trigonometry</li>
                            <li>Coordinate Geometry</li>
                            <li>Calculus</li>
                            <li>Vector Algebra</li>
                        </ol>

                        <br />
                        This is a condensed version of the JEE Main syllabus. For detailed topics within each category, please refer to the official JEE Main website or materials provided by the exam conducting authority.

                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Syllabus;