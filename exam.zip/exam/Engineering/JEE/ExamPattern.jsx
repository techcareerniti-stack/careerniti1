import { useEffect } from "react";
import "../JEE/ExamPattern.css";


function ExamPattern() { 
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="jee-examptrnSection">
            <div className="jee-examptrnContent poppins-regular">
                <div>
                    <h2 className="jee-heading">Exam Pattern</h2>
                </div>
                <div>
                    <ul className="jee-examptrnList">
                        <li><b>Paper 1: B.E/B.Tech :-</b></li>
                        <table className="jee-examptrnTble">
                            <thead>
                                <td className="table-heading">Subject</td>
                                <td className="table-heading">Section</td>
                                <td className="table-heading">Question Type</td>
                                <td className="table-heading">Marking Scheme</td>
                                <td className="table-heading">Number of <br /> Questions</td>
                                <td className="table-heading">Questions Can <br /> Be Attempted</td>
                                <td className="table-heading">Marks</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td rowSpan={2}>Physics</td>
                                    <td>Section A</td>
                                    <td>MCQs</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td>Section B</td>
                                    <td>Numerical Value</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">5</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td rowSpan={2}>Chemistry</td>
                                    <td>Section A</td>
                                    <td>MCQs</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td>Section B</td>
                                    <td>Numerical Value</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">5</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td rowSpan={2}>Maths</td>
                                    <td>Section A</td>
                                    <td>MCQs</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td>Section B</td>
                                    <td>Numerical Value</td>
                                    <td>Correct: +4 <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">5</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td className="table-heading" colSpan={4}>Total</td>
                                    <td className="numerical-data">90</td>
                                    <td className="numerical-data">75</td>
                                    <td className="numerical-data">300</td>
                                </tr>
                            </tbody>
                        </table>

                        <br />

                        <li><b>Paper 2A: B.Arch</b></li>
                        <table className="jee-examptrnTble">
                            <thead>
                                <td className="table-heading">Subject</td>
                                <td className="table-heading">Section</td>
                                <td className="table-heading">Question Type</td>
                                <td className="table-heading">Marking Scheme</td>
                                <td className="table-heading">Number of <br /> Questions</td>
                                <td className="table-heading">Questions Can <br /> Be Attempted</td>
                                <td className="table-heading">Marks</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td rowSpan={2}>Maths</td>
                                    <td>Section A</td>
                                    <td>MCQs</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">30</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td>Section B</td>
                                    <td>Numerical Value</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">5</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td>Aptitude</td>
                                    <td>Section A</td>
                                    <td>MCQs</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">50</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">200</td>
                                </tr>

                                <tr>
                                    <td>Drawing</td>
                                    <td>Section A</td>
                                    <td>Drawing</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">2</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">100</td>
                                </tr>

                                <tr>
                                    <td className="table-heading" colSpan={4}>Total</td>
                                    <td className="numerical-data">82</td>
                                    <td className="numerical-data">77</td>
                                    <td className="numerical-data">400</td>
                                </tr>
                            </tbody>
                        </table>

                        <br />

                        <li><b>Paper 2B: B.Planning</b></li>
                        <table className="jee-examptrnTble">
                            <thead>
                                <td className="table-heading">Subject</td>
                                <td className="table-heading">Section</td>
                                <td className="table-heading">Question Type</td>
                                <td className="table-heading">Marking Scheme</td>
                                <td className="table-heading">Number of <br /> Questions</td>
                                <td className="table-heading">Questions Can <br /> Be Attempted</td>
                                <td className="table-heading">Marks</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td rowSpan={2}>Maths</td>
                                    <td>Section A</td>
                                    <td>MCQs</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">30</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td>Section B</td>
                                    <td>Numerical Value</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">10</td>
                                    <td className="numerical-data">5</td>
                                    <td className="numerical-data">100</td>
                                </tr>
                                <tr>
                                    <td>Aptitude</td>
                                    <td>Section A</td>
                                    <td>MCQs</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">50</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">200</td>
                                </tr>

                                <tr>
                                    <td>Planning Based</td>
                                    <td>Section A</td>
                                    <td>MCQs</td>
                                    <td>Correct: +4, <br /> Incorrect: -1, Unanswered: 0</td>
                                    <td className="numerical-data">25</td>
                                    <td className="numerical-data">20</td>
                                    <td className="numerical-data">100</td>
                                </tr>

                                <tr>
                                    <td className="table-heading" colSpan={4}>Total</td>
                                    <td className="numerical-data">105</td>
                                    <td className="numerical-data">100</td>
                                    <td className="numerical-data">400</td>
                                </tr>
                            </tbody>
                        </table>



                    </ul>
                </div>
            </div>
        </div>
    );
}

export default ExamPattern;