import { useEffect } from "react";
import "../JEE/Introduction.css";


function Introduction() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="jee-introSection">
            <div className="jee-introContent poppins-regular">
                <div>
                    <h2 className="jee-heading">Introduction</h2>
                </div>
                <div>
                    <ul>
                        <li>
                            <div className="intro-para">
                                The Joint Entrance Examination, JEE (Main) comprises two papers. Paper 1 is conducted for admission to Undergraduate Engineering Programs (B.E/B.Tech.) at NITs, IIITs, other
                                Centrally Funded Technical Institutions (CFTIs), and Institutions/Universities
                                funded/recognized by participating State Governments. JEE (Main) is also an eligibility test for JEE (Advanced), which is conducted for admission to IITs. Paper 2 is conducted for admission to B. Arch and B. Planning courses in the country.
                                <br /><br />
                                The JEE (Main) - 2024 is being conducted in 02 (two) sessions for admissions in the next
                                academic session. The candidates will thus benefit in the following ways:
                                <br /><br />
                                <ul className="jee-introList">
                                    <li>This will give the candidates two opportunities to improve their scores in the examination if they are not able to give their best in the first attempt. </li>
                                    <br />
                                    <li>In the first attempt, the students will get a first-hand experience of taking an examination and will know their mistakes which they can improve while attempting for the second time.
                                    </li>
                                    <br />
                                    <li>This will reduce the chances of dropping a year and droppers would not have to waste an entire year.
                                    </li>
                                    <br />
                                    <li>If anyone misses the examination due to reasons beyond control (such as the Board examination), then he/she will not have to wait for one entire year.</li>
                                    <br />
                                    <li>A candidate need not appear in both Sessions. However, if a candidate appears in more than one Session then his/her best of the JEE (Main) - 2024 NTA Scores will be considered for preparation of the Merit List/ Ranking.
                                    </li>
                                </ul>


                            </div>
                        </li>
                    </ul>

                </div>
            </div>
        </div>
    );
}
export default Introduction;