import "../BITSAT/BITSAT.css"
import Add_Navbar from "../../Add_Navbar";
import Introduction from "./Introduction";
import Eligibility from "./Eligibility";
import Available_Courses from "./Available_Courses";
import Application_Fees from "./Application_Fees";
import Imp_Dates from "./Imp_Dates";
import ExamPattern from "./ExamPattern";
import Required_Docs from "./Required_Docs";
import FAQ from "./FAQ";
import TestCity from "./TestCity";

// import FAQ from "./FAQ";
function VITEEE({ path, setLoc, loc,setSelectedNotify}) {
  const formatLocation = (location) => {
    const parts = location.split("/").filter((part) => part !== "");
    const capitalizedParts = parts.map((part) => {
      if (part.toLowerCase() === "viteee") {
        return "VITEEE";
      } else {
        return part.charAt(0).toUpperCase() + part.slice(1);
      }
    });

    return capitalizedParts.join(" > ");
  };
  return (
    <>
      <Add_Navbar
        introduction={<Introduction />}
        eligibility={<Eligibility />}
        available_courses={<Available_Courses />}
        //    campuses={<Campuses />}
        application_fees={<Application_Fees />}
        imp_dates={<Imp_Dates />}
        exam_pattern={<ExamPattern />}
        //    syllabus={<Syllabus />}
        test_centres={<TestCity />}
        required_documents={<Required_Docs />}
        faq={<FAQ />}
        setLoc={setLoc}
        path={path}
        formatLocation={formatLocation}
        loc={window.location.pathname +loc}
        setSelectedNotify={setSelectedNotify}
        name="VITEEE"
        longform="[Vellore Institute of Technology Engineering Entrance Examination]"
      />
      <br />

    </>
  );
}

export default VITEEE;