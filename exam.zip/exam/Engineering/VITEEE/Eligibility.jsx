import { useEffect } from "react";
import "./Eligibility.css";

function Eligibility() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ele-section-viteee ">
        <div className="ele-content-viteee poppins-regular">
          <h2 className="viteee-title">Eligibility</h2>
          <ul className="viteeeUL">
            <li><b>Nationality:</b>
            <div>The applicant should be a Resident / Non-Resident Indian National / PIO / OCI.</div>
            </li><br/>

            <li><b>Age Limit: </b>
            <div>Applicants whose date of birth falls on or after 1st July 2002 are eligible to apply for Engineering admission 2024.</div>
            </li><br/>

            <li><b>Qualifying Examination: </b>
            <div>The final examination of the 10+2 system of Higher Secondary Examination conducted by the State Board; Central Board of Secondary Education (CBSE, New Delhi), The Council for Indian School Certificate Examination (ISCE),New Delhi.</div>
            </li><br/>

            
            <li><b>Qualifying Examination Performance:</b>
            <div>Candidates should have secured a minimum aggregate of 60% in Physics, Chemistry, and Mathematics/Biology in the qualifying examination (+2/Intermediate) for Applicants hailing from Jammu and Kashmir/ Ladakh and the Northeastern states of Arunachal Pradesh, Assam, Manipur, Meghalaya, Mizoram, Nagaland, Sikkim and Tripura</div>
            </li><br/>

          </ul>
           
        </div>
      </div>
    </>
  );
}

export default Eligibility;
