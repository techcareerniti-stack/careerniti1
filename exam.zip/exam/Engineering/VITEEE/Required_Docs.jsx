import { useEffect } from "react";
import "./Required_Docs.css";

function Required_Docs() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Rd-section-viteee ">
        <div className="Rd-content-viteee poppins-regular">
          <h2 className="viteee-title">Required Documents</h2>
          <p>
          For VITEEE registration, you need a scanned photograph, scanned signature, Class X Board Certificate, Class XII Hall Ticket, and Aadhar Card (if available).

          </p>
        </div>
      </div>
    </>
  );
}

export default Required_Docs;
