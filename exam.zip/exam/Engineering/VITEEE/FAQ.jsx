import { useEffect } from "react";
import "./FAQ.css";

function FAQ() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Fq-section-viteee ">
        <div className="Fq-content-viteee poppins-regular">
          <h2 className="viteee-title"> Frequently Asked Questions (FAQs) </h2>

          <ul className="faq-all">
            <li>
              <b>Que 1 What is VITEEE?</b>
              <div>
                <b>Ans:-</b>VITEEE (VIT Engineering Entrance Examination) is an
                entrance test conducted by VIT University for admission to its
                various undergraduate engineering programs.
              </div>
            </li>

            <li>
              <b>Que 2 Who is eligible to apply for VITEEE?</b>
              <div>
                <b>Ans:-</b>Candidates born on or after July 1, 2002, and those
                who have completed or are appearing in the 10+2 or equivalent
                examination in 2024 with Physics, Chemistry, and
                Mathematics/Biology as subjects are eligible.
              </div>
            </li>

            <li>
              <b>Que 3 How can I apply for VITEEE?</b>
              <div>
                <b>Ans:-</b>You can apply online through the official VITEEE
                website during the application period. Fill in the required
                details, upload necessary documents, and pay the application
                fee.
              </div>
            </li>

            <li>
              <b>Que 4 Is there negative marking in VITEEE?</b>
              <div>
                <b>Ans:-</b>No, there is no negative marking in VITEEE. You are
                encouraged to attempt all questions.
              </div>
            </li>

            <li>
              <b>Que 5 What is the exam pattern for VITEEE?</b>
              <div>
                <b>Ans:-</b>VITEEE is a computer-based test. It consists of
                multiple-choice questions from Physics, Chemistry,
                Mathematics/Biology, English, and Aptitude. The number of
                questions varies for different subjects.
              </div>
            </li>

            <li>
              <b>Que 6 What are the documents required for registration?</b>
              <div>
                <b>Ans:-</b>You need a scanned photograph, scanned signature,
                Class X Board Certificate, Class XII Hall Ticket, and Aadhar
                Card (if available).
              </div>
            </li>

            <li>
              <b>Que 7 Can I choose specific test centers?</b>
              <div>
                <b>Ans:-</b>Yes, you can choose your preferred test centers from
                the available options during the registration process.
              </div>
            </li>

            <li>
              <b>Que 8 When will VITEEE be conducted?</b>
              <div>
                <b>Ans:-</b>The exam is usually held in April every year. The
                exact dates can be checked on the official VITEEE website.
              </div>
            </li>

            <li>
              <b>Que 9 What is the syllabus for VITEEE?</b>
              <div>
                <b>Ans:-</b>The syllabus includes topics from Physics,
                Chemistry, Mathematics/Biology, English, and Aptitude. It's
                based on the 10+2 level of education.
              </div>
            </li>

            <li>
              <b>Que 10 How are candidates selected?</b>
              <div>
                <b>Ans:-</b>Candidates are selected based on their ranks in the
                VITEEE exam. Those with higher ranks get preference during the
                counseling and seat allotment process.
              </div>
            </li>

            <li>
              <b>
                Que 11 Which branch in Engineering would have the best scope?
              </b>
              <div>
                <b>Ans:-</b>All engineering programmes have an equally good
                scope. Much depends on your passion for the program and your
                endeavor to excel.
              </div>
            </li>

            <li>
              <b>
                Que 12 Are candidates appearing for Improvement/Privately also
                eligible to apply for VITEEE?
              </b>
              <div>
                <b>Ans:-</b> 'Yes'. They are eligible to apply for VITEEE and
                should produce their marks sheet at the time of counseling/
                admission.
              </div>
            </li>

            <li>
              <b>Que 13 What is the cost of the VITEEE Application form?</b>
              <div>
                <b>Ans:-</b>Application Cost - Rs.1350/-
              </div>
            </li>

            <li>
              <b>
                Que 14 Where can I find the fee structure for various
                programmes?
              </b>
              <div>
                <b>Ans:-</b> Please follow the link
               <a href=" https://vit.ac.in/admission/ug/fee-structure" target="_blank"> https://vit.ac.in/admission/ug/fee-structure</a>
              </div>
            </li>

            <li>
              <b>Que 15 How many campuses does VIT have?</b>
              <div>
                <b>Ans:-</b> Under VIT Group there are: VIT Vellore, VIT
                Chennai, VIT AP and VIT Bhopal. The first two come under Deemed
                to be University and VIT-AP and VIT-Bhopal are state private
                Universities.
              </div>
            </li>

            <li>
              <b>
                Que 16 Will I be offered the option of choosing campus and
                program while filling application?
              </b>
              <div>
                <b>Ans:-</b> 'No'. Only at the time of counseling you will be
                offered the option of choosing campus and programme. This would
                depend on the availability of the programme and campus as per
                your rank in the order of merit.
              </div>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
}

export default FAQ;
