import { useEffect } from "react";
import "./Imp_dates.css";

function Imp_Dates() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ImpDates-section-viteee ">
        <div className="ImpDates-content-viteee poppins-regular">
          <h2 className="viteee-title">Important Dates </h2>

          <table className=" viteee-ImpDate-Table">
            <thead>
              <td className="tablehead-imp">Particulars</td>
              <td className="tablehead-imp">Details</td>
            </thead>
            <tbody>
              <tr>
                <td>Last Date of Online Application </td>
                <td className="right-con-imp">30th March 2024</td>
              </tr>
              <tr>
                <td>VITEEE Exam</td>
                <td className="right-con-imp">
                  April 19th- 30th, 2024 (Tentatively) (The number of days for
                  each city will vary)
                </td>
              </tr>
              <tr>
                <td>VITEEE Result</td>
                <td className="right-con-imp">03rd - May - 2024 (Tentatively)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default Imp_Dates;
