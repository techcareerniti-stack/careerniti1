import { useEffect } from "react";
import "./ExamPattern.css";

function ExamPattern() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ExamP-section-viteee ">
        <div className="ExamP-content-viteee poppins-regular">
          <h2 className="viteee-title">Exam Pattern</h2>

          <table className="viteee-ExamP-Table">
            <thead>
              <td colSpan={2} className="tablehead-imp">
                MPCEA
              </td>
              <td colSpan={2} className="tablehead-imp">
                BPCEA
              </td>
            </thead>
            <tbody>
              <tr>
                <td>Mathematics</td>
                <td>40</td>
                <td>Biology </td>
                <td>40</td>
              </tr>

              <tr>
                <td>Physics</td>
                <td>35</td>
                <td> Physics</td>
                <td>35</td>
              </tr>

              <tr>
                <td>Chemistry</td>
                <td>35</td>
                <td>Chemistry </td>
                <td>35</td>
              </tr>
              <tr>
                <td>English</td>
                <td>5</td>
                <td> English</td>
                <td>5</td>
              </tr>
              <tr>
                <td>Aptitude </td>
                <td>10</td>
                <td>Aptitude</td>
                <td>10</td>
              </tr>
            </tbody>
          </table>

          <ul className="exampUl">
            <li>
              <b>Exam Duration: </b>2 Hours and 30 Minutes
            </li>
            <li>
              <b>Marking Scheme: </b>
              Total Marks: 125
              <ol>
                <li>
                  Correct Answer: You are awarded one mark for each correct
                  answer.
                </li>
                <li>
                  Incorrect Answer: There is no negative marking for incorrect
                  answers. So, if you answer a question incorrectly, you do not
                  lose any marks.
                </li>
              </ol>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
}

export default ExamPattern;
