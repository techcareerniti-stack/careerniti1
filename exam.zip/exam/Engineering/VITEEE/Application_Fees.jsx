import { useEffect } from "react";
import "./Application_Fees.css";

function Application_Fees() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="fee-section-viteee ">
        <div className="fee-content-viteee poppins-regular">
          <h2 className="viteee-title">Application Fees</h2>
          <ul className="feeul">
            <li>Candidate need to pay 1350 Rupees Online</li>
            <li>Payment Mode: Credit Card / Debit Card / UPI / Net Banking </li>
          </ul>
        </div>
      </div>
    </>
  );
}

export default Application_Fees;
