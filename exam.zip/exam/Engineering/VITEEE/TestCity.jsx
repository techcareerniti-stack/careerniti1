import { useEffect } from "react";
import "./TestCity.css";

function TestCity() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="vitee-testcitySection">
            <div className="vitee-testcityContent poppins-regular">
                <div>
                    <h2 className="testcity-head">Test City</h2>
                </div>
                <div>
                    <ul className="testcity-list">
                        <li><b>Test is conducted in below cities</b></li>
                        <table className="vitee-testcityTbl">
                            <thead>
                                <td className="vitee-testcityhead">State</td>
                                <td className="vitee-testcityhead">Exam Centres</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Andaman & Nicobar Islands</td>
                                    <td>Port Blair</td>
                                </tr>
                                <tr>
                                    <td>Andra Pradesh</td>
                                    <td>Anantapur, Eluru, Guntur, Kurnool, Nellore, Rajahmundry, Tirupati, Tanuku, Vijayawada, Vishakapatnam</td>
                                </tr>
                                <tr>
                                    <td>Arunachal Pradesh</td>
                                    <td>Ita Nagar</td>
                                </tr>
                                <tr>
                                    <td>Assam</td>
                                    <td>Dibrugarh, Guwahati, Silchar</td>
                                </tr>
                                <tr>
                                    <td>Bihar</td>
                                    <td>Bhagalpur, Gaya, Muzaffarpur, Patna</td>
                                </tr>
                                <tr>
                                    <td>Chhattisgarh</td>
                                    <td>Bhilai, Bilaspur, Raipur</td>
                                </tr>
                                <tr>
                                    <td>Delhi</td>
                                    <td>Delhi</td>
                                </tr>
                                <tr>
                                    <td>Goa</td>
                                    <td>Goa</td>
                                </tr>
                                <tr>
                                    <td>Gujarat</td>
                                    <td>Ahmedabad, Rajkot, Surat, Vadodara</td>
                                </tr>
                                <tr>
                                    <td>Haryana</td>
                                    <td>Faridabad, Gurgaon, Hissar, Kurukshetra</td>
                                </tr>
                                <tr>
                                    <td>Himachal Pradesh</td>
                                    <td>Dharamshala, Shimla</td>
                                </tr>
                                <tr>
                                    <td>Jammu & Kashmir</td>
                                    <td>Jammu, Srinagar</td>
                                </tr>
                                <tr>
                                    <td>Jharkhand</td>
                                    <td>Bokaro, Dhanbad, Jamshedpur, Ranchi</td>
                                </tr>
                                <tr>
                                    <td>Karnataka</td>
                                    <td>Bangalore, Hubli, Mangalore</td>
                                </tr>
                                <tr>
                                    <td>Kerala</td>
                                    <td>Kochi, Kozhikode, Thiruvananthapuram, Thrissur</td>
                                </tr>
                                <tr>
                                    <td>Madhya Pradesh</td>
                                    <td>Bhopal, Gwalior, Indore, Jabalpur, Ujjain</td>
                                </tr>
                                <tr>
                                    <td>Maharashtra</td>
                                    <td>Amravati, Aurangabad, Latur, Mumbai, Nagpur, Nashik, Pune, Thane</td>
                                </tr>
                                <tr>
                                    <td>Manipur</td>
                                    <td>Imphal</td>
                                </tr>
                                <tr>
                                    <td>Meghalaya</td>
                                    <td>Shillong</td>
                                </tr>
                                <tr>
                                    <td>Mizoram</td>
                                    <td>Aizwal</td>
                                </tr>
                                <tr>
                                    <td>Nagaland</td>
                                    <td>Dimapur</td>
                                </tr>
                                <tr>
                                    <td>Orissa</td>
                                    <td>Berhampur, Bhubaneshwar, Rourkela</td>
                                </tr>
                                <tr>
                                    <td>Pondicherry</td>
                                    <td>Pondicherry</td>
                                </tr>
                                <tr>
                                    <td>Punjab</td>
                                    <td>Amritsar, Bathinda, Jalandhar City, Ludhiana</td>
                                </tr>
                                <tr>
                                    <td>Rajasthan</td>
                                    <td>Ajmer, Bikaner, Jaipur, Jodhpur, Kota, Udaipur</td>
                                </tr>
                                <tr>
                                    <td>Sikkim</td>
                                    <td>Gangtok</td>
                                </tr>
                                <tr>
                                    <td>Tamil Nadu</td>
                                    <td>Chennai, Coimbatore, Kumbakonam, Madurai, Salem, Tiruchirapalli, Tirunelveli, Vellore</td>
                                </tr>
                                <tr>
                                    <td>Telangana</td>
                                    <td>Hyderabad, Karim Nagar, Khammam, Nalgonda, Warangal</td>
                                </tr>
                                <tr>
                                    <td>Tripura</td>
                                    <td>Agartala</td>
                                </tr>
                                <tr>
                                    <td>Uttar Pradesh</td>
                                    <td>Agra, Aligarh, Allahabad, Bareilly, Gorakhpur, Jhansi, Kanpur, Lucknow, Mathura, Meerut, Moradabad, Noida, Rae Bareli, Saharanpur, Varanasi</td>
                                </tr>
                                <tr>
                                    <td>Uttarakhand</td>
                                    <td>Dehradun, Pant Nagar, Roorkee</td>
                                </tr>
                                <tr>
                                    <td>West Bengal</td>
                                    <td>Asansol, Durgapur, Kolkata, Siliguri</td>
                                </tr>
                            </tbody>
                        </table>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default TestCity;