import { useEffect } from "react";
import "./Introduction.css";

function Introduction() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="intro-section-viteee ">
        <div className="intro-content-viteee poppins-regular">
          <h2 className="viteee-title">Introduction</h2>
          <p>
            The VIT Engineering Entrance Examination (VITEEE) is a highly
            competitive and renowned engineering entrance test conducted by VIT
            (Vellore Institute of Technology) University in India. This
            examination is designed to select the most talented and qualified
            students for admission into VIT's various B.Tech programs. VITEEE is
            known for its rigorous testing of students' knowledge in subjects
            like Mathematics, Physics, Chemistry, and English, as well as their
            problem-solving and critical thinking abilities.
          </p>
          <p>
          One of the distinctive features of VITEEE is its computer-based format, where students answer multiple-choice questions on a computer, making it an efficient and fair evaluation method. The examination typically covers a wide range of topics to assess candidates' preparedness for the field of engineering. Scoring well in VITEEE opens the door to a world-class engineering education at VIT University, which is recognized for its state-of-the-art infrastructure, world-class faculty, and a strong focus on research and innovation.

          </p>
          <ul className="vitee_Ul">
            <li><b>Vellore Institute of Technology is Available in:</b>
            <ol>
                <li>Vellore - Tamil nadu </li>
                <li>Chennai - Tamil nadu</li>           
                <li>Bhopal - Madhya Pradesh</li>
                <li>Amaravati - Andhra Pradesh (Near Vijaywada) </li> </ol>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
}

export default Introduction;
