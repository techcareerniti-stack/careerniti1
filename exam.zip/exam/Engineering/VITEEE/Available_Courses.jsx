import { useEffect } from "react";
import "./Available_Courses";

function Available_Courses() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ele-section-viteee ">
        <div className="ele-content-viteee poppins-regular">
          <h2 className="viteee-title">Available Courses</h2>
          <ul className="viteeeUL">
            <li>
              <b>VIT Vellore</b>
              <ol>
                <li>B.Tech - Biotechnology</li>
                <li>B.Tech - Chemical Engineering</li>
                <li>B.Tech - Civil Engineering</li>
                <li>B.Tech - Computer Science and Engineering</li>
                <li>
                  B.Tech - Computer Science and Engineering (Artificial
                  Intelligence and Machine Learning)
                </li>
                <li>
                  B.Tech - Computer Science and Engineering (Bioinformatics)
                </li>
                <li>
                  B.Tech - Computer Science and Engineering (Information
                  Security)
                </li>
                <li>
                  B.Tech - Computer Science and Engineering and Business
                  Systems(in collaboration with TCS)
                </li>
                <li>
                  B.Tech - Computer Science and Engineering (Data Science)
                </li>
                <li>
                  B.Tech - Computer Science and Engineering (BlockChain
                  Technology)
                </li>
                <li>B.Tech - Electrical and Electronics Engineering</li>
                <li>B.Tech - Electrical and Computer Science Engineering</li>
                <li>B.Tech - Electronics and Communication Engineering</li>
                <li>B.Tech - Electronics and Instrumentation Engineering</li>
                <li>
                  B.Tech - Electronics and Communication Engineering (Biomedical
                  Engineering)
                </li>
                <li>
                  B.Tech - Electronics Engineering (VLSI Design and Technology)
                </li>
                <li>B.Tech - Information Technology</li>
                <li>B.Tech - Mechanical Engineering</li>
                <li>B.Tech - Mechanical Engineering (Electric Vehicles)</li>
                <li>
                  B.Tech - Mechanical Engineering (Manufacturing Engineering)
                </li>
              </ol>
            </li>
            <br />
            <li>
              <b>VIT - Chennai</b>
              <ol>
                <li>B.Tech - Civil Engineering</li>
                <li>B.Tech - Computer Science and Engineering</li>
                <li>
                  B.Tech - Computer Science and Engineering (Artificial
                  Intelligence and Machine Learning)
                </li>
                <li>
                  B.Tech - Computer Science and Engineering (Artificial
                  Intelligence and Robotics)
                </li>
                <li>
                  B.Tech - Computer Science and Engineering (Cyber Physical
                  Systems)
                </li>
                <li>
                  B.Tech - Computer Science and Engineering (Cyber Security)
                </li>
                <li>
                  B.Tech - Computer Science and Engineering (Data Science)
                </li>
                <li>B.Tech - Electrical and Electronics Engineering</li>
                <li>B.Tech - Electrical and Computer Science Engineering</li>
                <li>B.Tech - Electronics and Communication Engineering</li>
                <li>B.Tech - Electronics and Computer Engineering</li>
                <li>
                  B.Tech - Electronics Engineering (VLSI Design and Technology)
                </li>
                <li>B.Tech - Fashion Technology</li>
                <li>B.Tech - Mechanical Engineering</li>
                <li>B.Tech - Mechatronics and Automation</li>
                <li>B.Tech - Mechanical Engineering (Electric Vehicles)</li>
              </ol>
            </li>
            <br />

            <li>
              <b>VIT-AP</b>
              <ol>
                <li>B.Tech - Computer Science and Engineering</li>
                <li>
                  B.Tech - Computer Science and Business Systems (in
                  collaboration with TCS)
                </li>
                <li>B.Tech - Electronics and Communication Engineering</li>
                <li>B.Tech - Mechanical Engineering</li>
              </ol>
            </li>
            <br />

            <li>
              <b>VIT-Bhopal</b>
              <ol>
                <li>B.Tech - Aerospace Engineering</li>
                <li>B.Tech - Bioengineering</li>
                <li>B.Tech - Computer Science & Engineering</li>
                <li>
                  B.Tech - Computer Science & Engineering (Artificial
                  Intelligence & Machine Learning)
                </li>
                <li>
                  B.Tech - Computer Science & Engineering (Cloud Computing &
                  Automation)
                </li>
                <li>
                  B.Tech - Computer Science & Engineering (Cyber Security &
                  Digital Forensics)
                </li>
                <li>
                  B.Tech - Computer Science & Engineering (E-Commerce
                  Technology)
                </li>
                <li>
                  B.Tech - Computer Science & Engineering (Education Technology)
                </li>
                <li>
                  B.Tech - Computer Science & Engineering (Gaming Technology)
                </li>
                <li>
                  B.Tech - Computer Science & Engineering (Health Informatics)
                </li>
                <li>B.Tech - Electronics & Communication Engineering</li>
                <li>
                  B.Tech - Electronics & Communication Engineering (Artificial
                  Intelligence & Cybernetics)
                </li>
                <li>B.Tech - Mechanical Engineering</li>
                <li>
                  B.Tech - Mechanical Engineering (Artificial Intelligence &
                  Robotics)
                </li>
              </ol>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
}

export default Available_Courses;
