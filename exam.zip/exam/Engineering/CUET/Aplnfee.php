<?php
// aplnfee_cuet.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CUET Application Fee</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-5xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">Application Fee</h2>
        <p class="text-gray-700 mb-2"><b>Fees :-</b></p>
        <table class="w-full border border-gray-300 text-gray-700">
            <thead class="bg-gray-100">
                <tr>
                    <th rowspan="2" class="border px-4 py-2">Category</th>
                    <th class="border px-4 py-2">Payment through online/debit/credit card</th>
                    <th colspan="3" class="border px-4 py-2">Payment through Challan</th>
                </tr>
                <tr>
                    <th class="border px-4 py-2">Application Fees*</th>
                    <th class="border px-4 py-2">Application Fee</th>
                    <th class="border px-4 py-2">Bank Commission</th>
                    <th class="border px-4 py-2">Total Fee to be paid</th>
                </tr>
            </thead>
            <tbody>
                <tr class="even:bg-gray-50">
                    <td class="border px-4 py-2">General/OBC</td>
                    <td class="border px-4 py-2">INR 800 for three PUs</td>
                    <td class="border px-4 py-2">Rs. 800</td>
                    <td class="border px-4 py-2">Rs. 50</td>
                    <td class="border px-4 py-2">Rs. 850</td>
                </tr>
                <tr class="even:bg-gray-50">
                    <td class="border px-4 py-2">SC/ST</td>
                    <td class="border px-4 py-2">INR 350 for three PUs</td>
                    <td class="border px-4 py-2">Rs. 350</td>
                    <td class="border px-4 py-2">Rs. 50</td>
                    <td class="border px-4 py-2">Rs. 400</td>
                </tr>
                <tr class="even:bg-gray-50">
                    <td class="border px-4 py-2">PWD</td>
                    <td class="border px-4 py-2 text-center" colspan="4">Exempted from Application Fee</td>
                </tr>
            </tbody>
        </table>
        <p class="text-gray-600 mt-4">*Fees are indicative and may vary as per official CUET notifications.</p>
    </div>
</div>

</body>
</html>
