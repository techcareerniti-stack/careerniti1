<?php
function getTestCity() {
    $cities = [
        "Gujarat" => ["Ahmedabad", "Gandhinagar", "Godhra", "Mehsana", "Rajkot", "Surat", "Vadodara", "Vapi"],
        "Uttar Pradesh" => ["Allahabad", "Lucknow", "Varanasi", "Agra", "Gorakhpur", "Meerut", "Prayagraj"],
        "Punjab" => ["Amritsar", "Bathinda", "Chandigarh", "Ludhiana", "Patiala", "Jalandhar"],
        "West Bengal" => ["Asansol", "Kolkata", "Siliguri"],
        "Karnataka" => ["Bengaluru", "Bidar", "Davanagere", "Hubli", "Kalaburagi", "Mangalore", "Mysore", "Raichur", "Yadgir", "Belagavi", "Bellary"],
        "Rajasthan" => ["Ajmer", "Bikaner", "Jaipur", "Jodhpur", "Kota", "Sikar", "Udaipur", "Jaisalmer", "Barmer"],
        "Bihar" => ["Begusarai", "Bhagalpur", "Gaya", "Muzaffarpur", "Patna", "Purnia", "Siwan", "Motihari"],
        "Madhya Pradesh" => ["Bhopal", "Indore", "Jabalpur"],
        "Odisha" => ["Bhubaneshwar", "Brahmapur", "Sambalpur"],
        "Kerala" => ["Calicut", "Kalpetta", "Kannur", "Kasaragod", "Kochi", "Kottayam", "Palakkad", "Thiruvananthapuram", "Thrissur"],
        "Tamil Nadu" => ["Chennai", "Coimbatore", "Madurai", "Thiruvarur", "Tiruchirappalli"],
        "Uttarakhand" => ["Dehradun"],
        "Jharkhand" => ["Dhanbad", "Jamshedpur", "Ranchi"],
        "Assam" => ["Guwahati"],
        "Haryana" => ["Hisar", "Mahendragarh"],
        "Telangana" => ["Hyderabad"],
        "Jammu and Kashmir" => ["Jammu", "Kargil", "Kathua", "Leh", "Srinagar", "Udhampur"],
        "Maharashtra" => ["Mumbai", "Nagpur", "Pune", "Solapur"],
        "Delhi" => ["New Delhi"],
        "Chhattisgarh" => ["Raipur"],
        "Himachal Pradesh" => ["Shimla"],
        "Andhra Pradesh" => ["Vijayawada", "Visakhapatnam"],
    ];

    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">Test City</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto border border-gray-300">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="border px-4 py-2">State</th>
                        <th class="border px-4 py-2">City</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cities as $state => $cityList): ?>
                        <?php $rowSpan = count($cityList); ?>
                        <?php foreach ($cityList as $index => $city): ?>
                            <tr>
                                <?php if ($index === 0): ?>
                                    <td class="border px-4 py-2" rowspan="<?= $rowSpan ?>"><?= $state ?></td>
                                <?php endif; ?>
                                <td class="border px-4 py-2"><?= $city ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
?>
