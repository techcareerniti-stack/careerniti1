<?php
function getExampatternSection() {
    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">Exam Pattern</h2>

        <p class="mb-4">
            NTA will also conduct the CUET Exam in 13 languages (Tamil, Telugu, Kannada, Malayalam, Marathi, Gujarati, Odiya, Bengali, Assamese, Punjabi, English, Hindi, and Urdu). 
            Check the revised CUET Exam Pattern 2024 from here.
        </p>

        <ol class="list-decimal list-inside mb-4 space-y-2">
            <li>CUET 2024 will be conducted in online mode this year; earlier, the exam was offline.</li>
            <li>
                CUET (UG) – 2024 will consist of the following 4 sections namely:
                <ol class="list-decimal list-inside ml-5 mt-1 space-y-1">
                    <li>Section IA - 13 Languages</li>
                    <li>Section IB – 20 Languages</li>
                    <li>Section II – 27 Domain-specific Subjects</li>
                    <li>Section III – General Test</li>
                </ol>
            </li>
            <li>The question paper will be MCQ type only and there will be a total of 175 questions out of which 140 questions are to be attempted.</li>
            <li>A Candidate can choose a maximum of any 3 languages from Section IA and Section IB together.</li>
            <li>Section II consists of 27 Subjects, out of which a candidate may choose a maximum of 6 Subjects.</li>
        </ol>

        <table class="min-w-full border border-gray-300 mb-6 text-sm">
            <thead class="bg-gray-200 text-left">
                <tr>
                    <th colspan="5" class="px-3 py-2 font-semibold text-center">CUET Exam Pattern 2024</th>
                </tr>
                <tr>
                    <th class="px-3 py-2 border">Sections</th>
                    <th class="px-3 py-2 border">Subjects/Tests</th>
                    <th class="px-3 py-2 border">No. of Questions</th>
                    <th class="px-3 py-2 border">To be Attempted</th>
                    <th class="px-3 py-2 border">Duration</th>
                </tr>
            </thead>
            <tbody class="text-gray-700">
                <tr>
                    <td class="px-3 py-2 border">Section IA</td>
                    <td class="px-3 py-2 border">13 Languages</td>
                    <td class="px-3 py-2 border" rowspan="2">50</td>
                    <td class="px-3 py-2 border" rowspan="2">40</td>
                    <td class="px-3 py-2 border" rowspan="2">45 minutes for each language</td>
                </tr>
                <tr>
                    <td class="px-3 py-2 border">Section IB</td>
                    <td class="px-3 py-2 border">20 Languages</td>
                </tr>
                <tr>
                    <td class="px-3 py-2 border">Section II</td>
                    <td class="px-3 py-2 border">27 Domain-specific Subjects</td>
                    <td class="px-3 py-2 border">45/50</td>
                    <td class="px-3 py-2 border">35/40</td>
                    <td class="px-3 py-2 border">45 minutes for each subject</td>
                </tr>
                <tr>
                    <td class="px-3 py-2 border">Section III</td>
                    <td class="px-3 py-2 border">General Test</td>
                    <td class="px-3 py-2 border">60</td>
                    <td class="px-3 py-2 border">50</td>
                    <td class="px-3 py-2 border">60 minutes</td>
                </tr>
            </tbody>
        </table>

        <ul class="list-disc list-inside mb-4 space-y-2">
            <li><b>Section IA Languages (13):-</b> Tamil, Telugu, Kannada, Malayalam, Marathi, Gujarati, Odiya, Bengali, Assamese, Punjabi, English, Hindi and Urdu</li>
            <li><b>Section IB Languages (20):-</b> French, Spanish, German, Nepali, Persian, Italian, Arabic, Sindhi, Kashmiri, Konkani, Bodo, Dogri, Maithili, Manipuri, Santhali, Tibetan, Japanese, Russian, Chinese, Sanskrit</li>
        </ul>

        <p class="mb-4"><b>Syllabus:</b> CUET UG/Integrated Courses Syllabus</p>

        <table class="min-w-full border border-gray-300 text-sm">
            <thead class="bg-gray-200">
                <tr>
                    <th class="px-3 py-2 border">Subject</th>
                    <th class="px-3 py-2 border">CUET Syllabus</th>
                </tr>
            </thead>
            <tbody class="text-gray-700">
                <tr>
                    <td class="px-3 py-2 border">English Language</td>
                    <td class="px-3 py-2 border">
                        <ol class="list-decimal list-inside ml-4 space-y-1">
                            <li>Comprehension Passages - Test understanding of passage, central theme, and meanings of words.</li>
                            <li>Fundamentals of grammar - incorrect sentences, filling blanks appropriately.</li>
                            <li>Vocabulary - synonyms, antonyms</li>
                        </ol>
                    </td>
                </tr>
                <tr>
                    <td class="px-3 py-2 border">Numerical Ability</td>
                    <td class="px-3 py-2 border">
                        <ol class="list-decimal list-inside ml-4 space-y-1">
                            <li>Arithmetic</li>
                            <li>Number system</li>
                            <li>Basics of algebra</li>
                            <li>Modern maths</li>
                        </ol>
                    </td>
                </tr>
                <tr>
                    <td class="px-3 py-2 border">General Awareness and Current Affairs</td>
                    <td class="px-3 py-2 border">
                        <ol class="list-decimal list-inside ml-4 space-y-1">
                            <li>Static general knowledge</li>
                            <li>Current Affairs (national & international)</li>
                        </ol>
                    </td>
                </tr>
                <tr>
                    <td class="px-3 py-2 border">Logical & Analytical Reasoning</td>
                    <td class="px-3 py-2 border">
                        <ol class="list-decimal list-inside ml-4 space-y-1">
                            <li>Syllogisms</li>
                            <li>Logical sequences</li>
                            <li>Analogies</li>
                            <li>Series</li>
                            <li>Directions</li>
                            <li>Cocks & calendars</li>
                            <li>Seating Arrangements</li>
                            <li>Puzzles</li>
                        </ol>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php
    return ob_get_clean();
}
?>
