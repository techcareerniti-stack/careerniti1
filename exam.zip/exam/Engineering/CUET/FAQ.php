<?php
function getFAQSection() {
    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">FAQ Section</h2>

        <ul class="space-y-4">
            <li>
                <p class="font-semibold">Que 1:- What is CUET 2024?</p>
                <p><span class="font-bold">Ans:-</span> NTA has been assigned the responsibility of conducting Central Universities Entrance Test (CUET) 2024 for admission to Integrated/UnderGraduate (UI) Programmes and Post-graduation (PG) Programmes of 14 Central Universities for the Academic Session 2022-23. This all-India test is being organized by 14 Central Universities for admission to UI and PG in these Universities/Institute(s). It provides a single window opportunity to the students to seek admission in these Participating Universities (PU) across the country.</p>
            </li>

            <li>
                <p class="font-semibold">Que 2:- Is CUET 2024 Exam Date Out?</p>
                <p><span class="font-bold">Ans:-</span> Yes, National Testing Agency (NTA) has announced CUET 2024 exam to be held between 15th to 31st May 2024.</p>
            </li>

            <li>
                <p class="font-semibold">Que 3:- What is the total number of participating universities in the CUET 2024?</p>
                <p><span class="font-bold">Ans:-</span> 44 Universities are participating for the Academic Session 2024.</p>
            </li>

            <li>
                <p class="font-semibold">Que 4:- What is the full form of CUET?</p>
                <p><span class="font-bold">Ans:-</span> The full form of CUET is Central University Entrance Test.</p>
            </li>

            <li>
                <p class="font-semibold">Que 5:- What is the medium of CUET 2024?</p>
                <p><span class="font-bold">Ans:-</span> CUET Exam will be conducted in 13 languages including English, Hindi, Assamese, Bengali, Gujarati, Kannada, Malayalam, Marathi, Odia, Tamil, Telugu, Urdu, and Punjabi.</p>
            </li>

            <li>
                <p class="font-semibold">Que 6:- Can I submit two application forms for two courses at a time?</p>
                <p><span class="font-bold">Ans:-</span> Applicants and interested candidates as per eligibility can apply for multiple courses. However, a candidate shall not apply for duplicate or multiple Forms for the same course, which may lead to cancellation of all his/her Application Forms.</p>
            </li>

            <li>
                <p class="font-semibold">Que 7:- What is the mode of CUET exam?</p>
                <p><span class="font-bold">Ans:-</span> CUET 2024 exam will be conducted in online mode. It is a Computer Based Test (CBT).</p>
            </li>

            <li>
                <p class="font-semibold">Que 8:- What is CUET Eligibility for UG Courses?</p>
                <p><span class="font-bold">Ans:-</span> The Minimum Eligibility for CUET UG Courses is 12th pass with 50% for General category and 45% marks for SC/ST. To apply for CUET PG Courses, graduation in the preferred subject is mandatory.</p>
            </li>

            <li>
                <p class="font-semibold">Que 9:- Is CUET a tough exam?</p>
                <p><span class="font-bold">Ans:-</span> If you prepare well with a proper strategy and clear the basics of the subjects, then you can easily crack the CUET exam with a good rank.</p>
            </li>

            <li>
                <p class="font-semibold">Que 10:- What is the official website to fill CUET application form 2024?</p>
                <p><span class="font-bold">Ans:-</span> All candidates can fill CUET application form 2024 by visiting <a href="https://cuet.samarth.ac.in" class="text-blue-600 underline">https://cuet.samarth.ac.in</a>.</p>
            </li>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}
?>
