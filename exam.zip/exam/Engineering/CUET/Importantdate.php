<?php
function getImportantDates() {
    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">Important Dates</h2>
        <ul class="mb-4">
            <li class="font-semibold mb-2">CUET 2024- Important Dates</li>
        </ul>

        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-300 divide-y divide-gray-200">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left font-semibold border-b border-gray-300">Events</th>
                        <th class="px-4 py-2 text-left font-semibold border-b border-gray-300">CUET 2024 Dates</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <tr>
                        <td class="px-4 py-2">CUET 2024 Notification release</td>
                        <td class="px-4 py-2">January 2024</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2">CUET Application Form 2024 Starts</td>
                        <td class="px-4 py-2">27 February</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2">CUET Application Form Ends</td>
                        <td class="px-4 py-2">26 March 2024</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2">Last date of successful transaction of fee</td>
                        <td class="px-4 py-2">26 March 2024</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2">Correction Window</td>
                        <td class="px-4 py-2">28 March to 29 March 2024</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2">CUET City Intimation 2024</td>
                        <td class="px-4 py-2">30 April 2024 onwards</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2">Release of CUET Admit Card 2024</td>
                        <td class="px-4 py-2">The second week of May 2024</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2">Date of Examination</td>
                        <td class="px-4 py-2">Between 15 May 2024 and 31 May 2024</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2">Declaration of Result on the NTA website</td>
                        <td class="px-4 py-2">30 June 2024</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
?>
