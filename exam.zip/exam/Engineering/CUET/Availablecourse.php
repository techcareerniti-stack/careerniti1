<?php
// available_courses_cuet.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CUET Available Courses</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.onload = function () {
            window.scrollTo(0, 0);
        };
    </script>
</head>
<body class="bg-gray-50 font-sans">

<div class="w-full flex justify-center px-4 py-10">
    <div class="w-full max-w-6xl bg-white rounded-xl shadow-md p-6 md:p-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">Available Courses</h2>
        <p class="text-gray-700 mb-4"><b>Courses :-</b></p>
        <div class="overflow-x-auto">
            <table class="w-full border border-gray-300 text-gray-700 table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="border px-4 py-2">Degrees</th>
                        <th class="border px-4 py-2">Courses</th>
                        <th class="border px-4 py-2">Codes</th>
                        <th class="border px-4 py-2">Universities</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <tr>
                        <td class="border px-4 py-2">Integrated MCA</td>
                        <td class="border px-4 py-2">Computer Science</td>
                        <td class="border px-4 py-2">UI001</td>
                        <td class="border px-4 py-2">Baba Ghulam Shah Badshah University</td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2">Integrated B.Sc. Hons MSc</td>
                        <td class="border px-4 py-2">Chemistry</td>
                        <td class="border px-4 py-2">UI010</td>
                        <td class="border px-4 py-2">Central University of Jammu</td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2">Integrated B.Sc. Hons. MSc</td>
                        <td class="border px-4 py-2">Physics</td>
                        <td class="border px-4 py-2">UI011</td>
                        <td class="border px-4 py-2">Central University of Jammu</td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2">B. Tech.</td>
                        <td class="border px-4 py-2">Computer Science and Engineering</td>
                        <td class="border px-4 py-2">UI004</td>
                        <td class="border px-4 py-2">Central University of Haryana</td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2">B. Tech.</td>
                        <td class="border px-4 py-2">Electrical Engineering</td>
                        <td class="border px-4 py-2">UI005</td>
                        <td class="border px-4 py-2">Central University of Haryana</td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2">BSc</td>
                        <td class="border px-4 py-2">Physics, Chemistry and Mathematics</td>
                        <td class="border px-4 py-2">UI018</td>
                        <td class="border px-4 py-2">Central University of Karnataka</td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2">BCA</td>
                        <td class="border px-4 py-2">Computer Applications</td>
                        <td class="border px-4 py-2">UI019</td>
                        <td class="border px-4 py-2">Central University of Odisha</td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2">Integrated B.Sc. Hons. MSc</td>
                        <td class="border px-4 py-2">Botany</td>
                        <td class="border px-4 py-2">UI008</td>
                        <td class="border px-4 py-2">Central University of Jammu</td>
                    </tr>
                    <tr>
                        <td class="border px-4 py-2">Integrated B.Sc. Hons. MSc</td>
                        <td class="border px-4 py-2">Zoology</td>
                        <td class="border px-4 py-2">UI009</td>
                        <td class="border px-4 py-2">Central University of Jammu</td>
                    </tr>
                    <!-- Continue adding remaining rows similarly -->
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
