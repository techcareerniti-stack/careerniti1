<?php
// CUET Eligibility Section
?>

<div class="cuet-elgbltySection">
    <div class="cuet-elgbltyContent poppins-regular">
        <div>
            <h2 class="cuet-heading">Eligibility</h2>
        </div>
        <div>
            <ul>
                <li>
                    <div class="intro-para">
                        Candidates who have cleared Class 12 / equivalent examination can appear for the CUET 2024. Candidates appearing for the CUET 2024 exam should be aware that there is no age restriction for the UG programmes. Candidates should have passed Class 12 from a recognized school.
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
