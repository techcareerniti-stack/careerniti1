<?php
function getIntroduction() {
    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">Introduction</h2>
        <ul>
            <li class="mb-2">
                <div class="text-gray-700">
                    The Common University Entrance Test (CUET), earlier known as Central Universities Common Entrance Test (CUCET) is an all-India test being organized by the National Testing Agency for admission to various doctorate, Postgraduate, Undergraduate, Integrated Postgraduate, Diploma, Certification courses and Research Programmes in 45 Central Universities of India. It is also accepted by a number of other State Universities and Deemed Universities in India.
                </div>
            </li>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}
?>
