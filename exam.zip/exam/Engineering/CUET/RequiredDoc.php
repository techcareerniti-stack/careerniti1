<?php
function getRequiredDoc() {
    ob_start();
    ?>
    <div class="px-4 py-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold mb-4">Required Documents</h2>
        <ol class="list-decimal list-inside space-y-2 text-gray-700">
            <li>Scanned copy of the photo.</li>
            <li>Scanned copy of a signature.</li>
            <li>Scanned copy of the 10th mark sheet.</li>
            <li>Scanned copy of the 12th mark sheet.</li>
            <li>Scanned copy of the caste certificate.</li>
            <li>Scanned copy of the income certificate.</li>
            <li>Photo identity proof, such as an Aadhaar card, identity card, bank passbook, etc.</li>
        </ol>
    </div>
    <?php
    return ob_get_clean();
}
?>
