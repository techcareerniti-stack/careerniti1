import { useEffect } from "react";
import "./Application_Fees.css";

function Application_Fees() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="fee-section-met ">
        <div className="fee-content-met poppins-regular">
          <h2 className="met-title">Application Fees</h2>
          <table className="met-fee-Table">
            <thead>
              <td className="tablehead">Category of Candidate</td>
              <td className="tablehead">In India (Fee in ₹)</td>
            </thead>
            <tbody>
              <tr>
                <td>General</td>
                <td className="right-con">₹ 600/-</td>
              </tr>
              <tr>
                <td>Foreign/NRI/NRI Sponsored category</td>
                <td className="right-con">₹ 2500/-</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default Application_Fees;
