import { useEffect } from "react";
import "./Required_Docs.css";

function Required_Docs() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Rd-section-met">
        <div className="Rd-content-met poppins-regular">
          <h2 className="met-title">Required Documents</h2>
          <ul className="Rq-ul">
            <li>Class 10 & 12 mark sheet</li>
            <li>UG mark sheet (if applicable)</li>
            <li>PG mark sheet (if applicable)</li>
            <li>Date of birth certificate</li>
            <li>Passport-size photograph</li>
            <li>Transfer certificate</li>
            <li>Character certificate</li>
          </ul>
        
        </div>
      </div>
    </>
  );
}

export default Required_Docs;
