import { useEffect } from "react";
import "./FAQ.css";

function FAQ() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Fq-section-met ">
        <div className="Fq-content-met poppins-regular">
          <h2 className="met-title"> Frequently Asked Questions (FAQs) </h2>

          <ul className="faq-all">
            <li>
              <b>Que 1 What documents are required for admission in Manipal University?</b>
              <div>
                <b>Ans:-</b>The documents required for the MIT Manipal admission procedure are passport size photographs, class 10th and 12th mark sheets and certificates, bachelor's degree certificate (for PG admission), caste certificate (if applicable), migration certificate, transfer certificate and MET scorecard.
              </div>
            </li>

            <li>
              <b>Que 2 What are the requirements for MIT Manipal?</b>
              <div>
                <b>Ans:-</b>The total course fee for the BTech course ranges between INR 8.1 lakh and INR 13.5 lakh. In order to be eligible for the BTech course at Manipal Institute of Technology, candidates must have scored at least 45-50% aggregate in Class 12. Q: Does MIT Manipal require an entrance exam for MCA admission?

              </div>
            </li>

            <li>
              <b>Que 3 What are the requirements for Manipal Boards?
</b>
              <div>
                <b>Ans:-</b>Minimum 60% marks in 10+2 from recognized board or equivalent qualification as recognized by Association of Indian Universities (AIU) or other competent body in commerce and allied disciplines.

              </div>
            </li>

            <li>
              <b>Que 4 Is Manipal entrance exam online from home?
</b>
              <div>
                <b>Ans:-</b>This year, the Manipal entrance exam is happening online at home.

              </div>
            </li>

            <li>
              <b>Que 5 Can I join Manipal without entrance?
</b>
              <div>
                <b>Ans:-</b>Manipal University admissions are completely entrance-based. Except for a few courses, where candidates are selected through the merit obtained in their last qualifying exam or by qualifying for Department specific tets for the respective courses. Apart from that, for courses like BBA, MA, BTech, BPharm, etc.

              </div>
            </li>

           
          </ul>
        </div>
      </div>
    </>
  );
}

export default FAQ;
