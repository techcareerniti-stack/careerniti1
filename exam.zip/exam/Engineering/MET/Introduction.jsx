import React from "react";
import { useEffect } from "react";
import "./Introduction.css"

function Introduction() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="intro-section-met ">
        <div className="intro-content-met poppins-regular">
          <h2 className="met-title">Introduction</h2>
          <p>
          Manipal University conducts the MET exam to provide admission to undergraduate courses. The candidates have to apply for the MET 2024 registration process on the official website. After the registration process, login id and password will be sent to their registered email IDs.

          </p>
        </div>
      </div>
    </>
  );
}

export default Introduction;
