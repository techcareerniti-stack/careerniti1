import { useEffect } from "react";
import "./Imp_dates.css";

function Imp_Dates() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ImpDates-section-met ">
        <div className="ImpDates-content-met poppins-regular">
          <h2 className="met-title">Important Dates </h2>

          <ul className="impdt-ul">
            <li>
              <b>Manipal MET Exam Date 2024 Session 1</b>
            </li>

            <table className=" met-ImpDate-Table">
              <thead>
                <td className="tablehead-imp">Events</td>
                <td className="tablehead-imp">
                  MET Important Dates 2024 (Tentative)
                </td>
              </thead>
              <tbody>
                <tr>
                  <td>MET 2024 registration date</td>
                  <td>October 2023</td>
                </tr>
                <tr>
                  <td>Last date for Manipal MET 2024 application</td>
                  <td>April 2024</td>
                </tr>

                <tr>
                  <td>MET phase 1 slot booking date 2024</td>
                  <td>April 2024</td>
                </tr>

                <tr>
                  <td>MET admit card release date phase 1</td>
                  <td>April 2024</td>
                </tr>

                <tr>
                  <td>Manipal examination date</td>
                  <td>May 2024</td>
                </tr>
                <tr>
                  <td>MET merit list</td>
                  <td>To be notified</td>
                </tr>
              </tbody>
            </table>
<br/>
            <li>
              <b>MET Exam Date 2024 Session 2</b>
            </li>

            <table className=" met-ImpDate-Table">
              <thead>
                <td className="tablehead-imp">Events</td>
                <td className="tablehead-imp">
                  Manipal Exam Date 2024 (Tentative)
                </td>
              </thead>
              <tbody>
                <tr>
                  <td>MET registration date 2024</td>
                  <td>April 2024</td>
                </tr>

                <tr>
                  <td>Last date to submit Manipal phase 2 BTech form</td>
                  <td>May 2024</td>
                </tr>

                <tr>
                  <td>MET phase 2 slot booking date 2024</td>
                  <td>May 2024</td>
                </tr>

                <tr>
                  <td>MET admit card release date phase 2</td>
                  <td>May 2024</td>
                </tr>

                <tr>
                  <td>MET examination date 2024 session 2</td>
                  <td>May 2024</td>
                </tr>

                <tr>
                  <td>MET merit list</td>
                  <td>To be notified</td>
                </tr>
              </tbody>
            </table>
          </ul>
        </div>
      </div>
    </>
  );
}

export default Imp_Dates;
