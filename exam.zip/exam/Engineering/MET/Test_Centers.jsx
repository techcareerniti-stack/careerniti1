import { useEffect } from "react";
import "./Test_Centers.css";

function Test_Centres() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Tc-section-met">
        <div className="Tc-content-met poppins-regular">
          <h2 className="met-title"> Test Centres </h2>
          
          <table className=" met-Tc-Table">
              <thead>
                <td className="tablehead-imp">State</td>
                <td className="tablehead-imp">
                Cities
                </td>
              </thead>
              <tbody>
                <tr>
                  <td className="tc-td" rowSpan={9}>Andhra Pradesh</td>
                <td>Guntur</td></tr>
                 <tr> <td>Kadapa</td></tr>
                  <tr><td>Kakinada</td></tr>
                  <tr><td>Kurnool</td></tr>
                  <tr><td>Nellore</td></tr>
                 <tr> <td>Rajahmundry</td></tr>
                  <tr><td>Tirupathi </td></tr>
                  <tr><td>Vijayawada</td></tr>
                 <tr><td>Visakhapatnam</td></tr> 
            

                <tr >
                  <td className="tc-td">Assam</td>
                  <td>Guwahati </td>
                </tr>

                <tr>
                  <td className="tc-td" rowSpan={3}>Bihar</td>
                  <td>Bhagalpur</td>
          
                </tr>
                <tr>        <td>Muzaffarpur</td></tr>
                <tr><td>Patna</td></tr>


                <tr>
                  <td className="tc-td">Chandigarh

</td><td>Chandigarh

</td>
                </tr>
                <tr>
                  <td className="tc-td">Chhattisgarh</td>
                  <td>Bhilai

</td>
                </tr>
                <tr><td className="tc-td">Delhi</td>
                <td>Delhi</td></tr>

                <tr><td className="tc-td">Goa</td>
                <td>Margao</td></tr>


                <tr>
                  <td className="tc-td" rowSpan={5}>Gujarat</td>
                  <td>Ahmedabad</td>
                </tr>
                <tr>
                  <td>Baroda</td>
                </tr>
                <tr>
                  <td>Jamnagar

</td>
                </tr>
                <tr>
                  <td>Rajkot</td>
                </tr>
                <tr>
                  <td>Surat</td>
                </tr>

                <tr>
                  <td className="tc-td" rowSpan={2}>Haryana</td>
                  <td>Faridabad</td>
                </tr>
                <tr><td>Gurgaon</td></tr>


                <tr>
                  <td  className="tc-td">Himachal Pradesh</td>
                  <td>Shimla</td>
                </tr>

                <tr>
                  <td className="tc-td">International</td>
                  <td>Dubai</td>
                </tr>

                <tr>
                  <td  className="tc-td">Jammu and Kashmir</td>
                  <td>Jammu</td>
                </tr>

                <tr>
                  <td className="tc-td" rowSpan={4}>Jharkhand</td>
                  <td>Bokaro</td>
                </tr>
                <tr><td>Dhanbad</td></tr>
                <tr><td>Jamshedpur</td></tr>
                <tr><td>Ranchi</td></tr>

                <tr>
                  <td className="tc-td" rowSpan={5}>Karnataka</td>
                  <td>Belgaum</td>
                </tr>
                <tr><td>Mangalore</td></tr>
                <tr><td>Manipal</td></tr>
                <tr><td>Mysuru</td></tr>
                <tr><td>Shivamogga</td></tr>

                <tr>
                  <td className="tc-td" rowSpan={6}>Kerala</td>
                  <td>Ernakulam</td>
                </tr>
                <tr><td>Kannur</td></tr>
                <tr><td>Kollam</td></tr>
                <tr><td>Kottayam</td></tr>
                <tr>
                  <td>Kozhikode</td>
                </tr>
                <tr><td>Thiruvananthapuram</td></tr>

                <tr>
                  <td className="tc-td" rowSpan={4}>Madhya Pradesh</td>
                  <td>Bhopal</td>
                </tr>
                <tr>
                  <td>Gwalior</td>
                </tr>
                <tr>  <td>Indore</td></tr>
                <tr>
                  <td>Jabalpur</td></tr>

                <tr>
                  <td className="tc-td" rowSpan={6}>Maharashtra</td>
                  <td>Aurangabad</td>
                  </tr>
                  <tr><td>Mumbai</td></tr>
                <tr>  <td>Nagpur</td></tr>
               <tr>   <td>Nashik</td></tr>
                  <tr><td>Pune</td></tr>
                  <tr><td>Thane</td></tr>
               

               <tr>
                <td className="tc-td">Orissa</td>
                <td>Bhubneshwar</td>
               </tr>
              
              <tr>
                <td className="tc-td" rowSpan={2}>Punjab</td>
                <td>Amritsar</td>
              </tr>
              <tr>
                <td>Ludhiana</td>
              </tr>

              <tr>
                <td className="tc-td" rowSpan={4}>Rajasthan</td>
                <td>Jaipur</td>
              </tr>
              <tr><td>Jodhpur</td></tr>
            <tr><td>Kota</td></tr>
              <tr><td>Udaipur</td></tr>


              <tr>
                <td className="tc-td">Sikkim</td>
                <td>Gangtok</td>
              </tr>

              <tr>
                <td className="tc-td" rowSpan={4}>Tamil Nadu</td>
                <td>Chennai</td>
              </tr>
              <tr>
                <td>Coimbatore</td>
              </tr>
              <tr>
                <td>Erode</td>
              </tr>
              <tr>
                <td>Trichy</td>
              </tr>

              <tr>
                <td className="tc-td" rowSpan={3}>Telangana</td>
                <td>Hyderabad</td>
              </tr>
              <tr>
                <td>Khammam</td>
              </tr>
              <tr>
                <td>Warangal</td>
              </tr>

              <tr>
                <td className="tc-td" rowSpan={10}>Uttar Pradesh</td>
                <td>Agra</td>
              </tr>
              <tr>
             <td> Allahabad</td>
              </tr>

              <tr>
                <td>Bareilly</td>
              </tr>

              <tr>
                <td>Ghaziabad</td>
              </tr>

              <tr>
                <td>Gorakhpur</td>
              </tr>

              <tr>
                <td>Kanpur</td>
              </tr>

              <tr>
                <td>Lucknow</td>
              </tr>

              <tr>
                <td>Meerut</td>
              </tr>

              <tr>
                <td>Noida</td>
              </tr>

              <tr>
                <td>Varanasi</td>
              </tr>


              <tr>
                <td className="tc-td">Uttarakhand</td>
                <td>Dehradun</td>
              </tr>

              <tr>
                <td className="tc-td" rowSpan={3}>West Bengal</td>
                <td>Asansol</td>
              </tr>
              <tr>
                <td>Kolkata</td>
              </tr>
              <tr><td>Siliguri

</td></tr>
              </tbody>
            </table>

        </div>
      </div>
    </>
  );
}

export default Test_Centres;
