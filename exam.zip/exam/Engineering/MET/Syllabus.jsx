import React from "react";
import { useEffect } from "react";
import "./Syllabus.css";

function ExamPattern() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Syllabus-section-met ">
        <div className="Syllabus-content-met poppins-regular">
          <h2 className="met-title">Syllabus</h2>

          <table className="met-Syllabus-Table">
            <thead>
              <td className="tablehead-imp">Subject</td>
              <td className="tablehead-imp">Topics</td>
            </thead>
            <tbody>
              <tr>
                <td className="Syllabus-td">Physics</td>
                <td>
                  <ul className="sy-ul">
                    <li>
                      Physical World and Measurement - Physical World, Units and
                      Measurements.
                    </li>
                    <li>
                      Kinematics - Motion in a Straight Line, Motion in a Plane.
                    </li>
                    <li>Laws of Motion</li>
                    <li>Work, Energy, and Power</li>
                    <li>
                      Motion of System of Particles and Rigid Body - System of
                      Particles and Rotational Motion
                    </li>
                    <li>Gravitation</li>
                    <li>
                      Mechanical Properties of Solids - Mechanical Properties of
                      Fluids, Thermal Properties of Matter.
                    </li>
                    <li>Thermodynamics</li>
                    <li>
                      The behavior of Perfect Gases and Kinetic Theory of Gases
                      - Kinetic Theory
                    </li>
                    <li>Oscillations, Waves</li>
                    <li>Electrostatics</li>
                    <li>Current Electricity</li>
                    <li>Magnetic Effects of Current and Magnetism</li>
                    <li>Electromagnetic Induction and Alternating Currents</li>
                    <li>Electromagnetic Waves</li>
                    <li>Optics</li>
                    <li>Dual Nature of Radiation and Matter</li>
                    <li>Atoms - Nuclei Composition and size of the nucleus</li>
                    <li>Electronic Devices</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td className="Syllabus-td">Chemistry</td>
                <td>
                  <ul className="sy-ul">
                    <li>Structure of atom</li>
                    <li>Some Basic Concepts of Chemistry</li>
                    <li>
                      Classification of Elements and Periodicity in Properties
                    </li>
                    <li>Chemical Bonding and Molecular structure</li>
                    <li>States of Matter: Gases and Liquids</li>
                    <li>Chemical Thermodynamics</li>
                    <li>Equilibrium</li>
                    <li>Redox Reactions</li>
                    <li>Hydrogen</li>
                    <li>s-Block Elements (Alkali and Alkaline Earth Metals)</li>
                    <li>p-Block Elements</li>
                    <li>
                      Organic Chemistry - Some Basic Principles and Techniques
                    </li>
                    <li>Hydrocarbons</li>
                    <li>Environmental Chemistry</li>
                    <li>Solutions</li>
                    <li>Electrochemistry</li>
                    <li>Chemical Kinetics</li>
                    <li>Surface Chemistry</li>
                    <li>
                      General Principles and Processes of Isolation of Elements
                    </li>
                    <li>p-Block Elements</li>
                    <li>‘d’ and ‘f’ Block Elements</li>
                    <li>Coordination Compounds</li>
                    <li>Haloalkanes and Haloarenes</li>
                    <li>Alcohols, Phenols and Ethers: Alcohols</li>
                    <li>Aldehydes, Ketones and Carboxylic Acids</li>
                    <li>Organic compounds containing Nitrogen</li>
                    <li>Biomolecules</li>
                    <li>Polymers</li>
                    <li>Chemistry in Everyday life</li>
                  </ul>
                </td>
              </tr>

              <tr>
                <td className="Syllabus-td">Mathematics</td>
                <td>
                  <ul className="sy-ul">
                    <li>
                      Sets and Functions - Sets, Relations and Functions,
                      Trigonometric Functions.
                    </li>
                    <li>
                      Algebra - Mathematical Induction, Numbers & Quadratic
                      Equations, Linear Inequalities, Permutations and
                      Combinations, Binomial Theorem, Sequence and Series,
                      Matrices, Determinants.
                    </li>
                    <li>
                      Coordinate Geometry - Straight Lines, Conic Sections,
                      Introduction to Three-dimensional Geometry.
                    </li>
                    <li>
                      Calculus - Limits and Derivatives, Continuity and
                      Differentiability, Applications of Derivatives, Integrals
                      and their Application, Differential equations.
                    </li>
                    <li>
                      Mathematical Reasoning - Statistics and Probability,
                      Relations and Functions, Inverse Trigonometric Functions,
                      Vector algebra, Three-Dimensional Geometry, Linear
                      programming.
                    </li>
                  </ul>
                </td>
              </tr>

              <tr>
                <td className="Syllabus-td">English</td>
                <td>
                  <ul className="sy-ul">
                    <li>Tense – Use of proper tense and sequence of tense</li>
                    <li>Subject – Verb concord</li>
                    <li>
                      Pronouns and Determiners / Use of proper articles /
                      Prepositions
                    </li>
                    <li>
                      Linkers: Appropriate use of linkers and conjunctions in a
                      sentence
                    </li>
                    <li>
                      Sentence structure: Clauses of condition and time,
                      Relative clauses, Fragments
                    </li>
                    <li>
                      Usages in English: standard usages / Idioms and phrases
                    </li>
                    <li>Synonyms / Question tags</li>
                    <li>One-word substitutions</li>
                    <li>Commonly confused pair of words</li>
                    <li>Sentence completion</li>
                  </ul>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default ExamPattern;
