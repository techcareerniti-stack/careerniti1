import React from "react";
import { useEffect } from "react";
import "./ExamPattern.css";
function ExamPattern() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ExamP-section-met ">
        <div className="ExamP-content-met poppins-regular">
          <h2 className="met-title">Exam Pattern</h2>

          <table className="met-ExamP-Table">
            <thead>
              <td className="tablehead-imp">Particulars</td>
              <td className="tablehead-imp">Details</td>
            </thead>
            <tbody>
              <tr>
                <td className="ExamP-td">Exam Mode</td>
                <td>Computer Based Test (Online)</td>
              </tr>

              <tr>
                <td className="ExamP-td">Medium of Language</td>
                <td>English</td>
              </tr>

              <tr>
                <td className="ExamP-td">Test Duration</td>
                <td>Two hours</td>
              </tr>

              <tr>
                <td className="ExamP-td">Questions Type</td>
                <td>
                  Multiple Choice Questions (MCQs) & Numerical Answer Type (NAT)
                </td>
              </tr>

              <tr>
                <td className="ExamP-td">Sections</td>
                <td>
                  <ul className="ep-ul">
                    <li>Physics - 10 MCQs & 5 NAT</li>
                    <li>Chemistry - 10 MCQs & 5 NAT</li>
                    <li>Mathematics - 15 MCQs & 5 NAT</li>
                    <li>English - 10 MCQs only</li>
                  </ul>
                </td>
              </tr>

              <tr>
                <td className="ExamP-td">MET total Marks</td>
                <td>240 Marks</td>
              </tr>

              <tr>
                <td className="ExamP-td">Total Questions</td>
                <td>30 Questions</td>
              </tr>

              <tr>
                <td className="ExamP-td">Marking Scheme</td>
                <td>
                  For MCQs & NAT, for every correct answer, four marks will be
                  awarded
                </td>
              </tr>

              <tr>
                <td className="ExamP-td">Negative Marking</td>
                <td>
                  For MCQs every wrong answer, one mark will be deducted, and no
                  negative marking for NAT.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default ExamPattern;
