import React from "react";
import { useEffect } from "react";
import "./Campuses.css";
function Campuses() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="cam-section-met ">
        <div className="cam-content-met poppins-regular">
          <h2 className="met-title">Campuses</h2>

          <table className="met-Campuses-Table">
            <thead>
              <td className="tablehead-imp">Campus</td>
              <td className="tablehead-imp">Streams</td>
            </thead>
            <tbody>
              <tr>
                <td className="campus-td">Manipal</td>
                <td>
                  Science, Health Science, Technology, Management, Commerce,
                  Humanities, Liberal Arts and Social Sciences
                </td>
              </tr>
              <tr>
                <td  className="campus-td"> Mangalore</td>
                <td>Medicine, Dentistry and Nursing</td>
              </tr>
              <tr>
                <td  className="campus-td">Bangalore</td>
                <td>Allied Health Sciences, Regenerative Medicine</td>
              </tr>

              <tr>
                <td  className="campus-td">Dubai</td>
                <td>
                  Architecture & Design, Arts & Humanities, Engineering,
                  Information Sciences, Management, Media & Communication and
                  Life Sciences
                </td>
              </tr>
              <tr>
                <td  className="campus-td"> Melaka</td>
                <td>Medicine and Dentistry</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default Campuses;
