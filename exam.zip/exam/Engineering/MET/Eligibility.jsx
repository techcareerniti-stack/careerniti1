import React from "react";
import "./Eligibility.css";
import { useEffect } from "react";
function Eligibility() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ele-section-met ">
        <div className="ele-content-met poppins-regular">
          <h2 className="met-title">Eligibility</h2>
          <p>
          They must have obtained 50% aggregate in the last qualifying exam of Class 12 with Physics, Chemistry and any other optional subject in combinations. This is a mandatory step to qualify for all the General Category Indian aspirants for MIT Manipal BTech admissions.
          </p>
        </div>
      </div>
    </>
  );
}

export default Eligibility;
