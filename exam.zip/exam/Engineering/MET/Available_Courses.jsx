import { useEffect } from "react";
import React from "react";

function Available_Courses() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ele-section-met ">
        <div className="ele-content-met poppins-regular">
          <h2 className="met-title">Available Courses</h2>
          <p>
          BTech, ME, BBA, BA, MA, BDes, MSc, BPharm, M Pharm, PharmD, PharmD Post Baccalaureate, Master of Physiotherapy.
          </p>
        </div>
      </div>
    </>
  );
}

export default Available_Courses;
