import { useEffect } from "react";
import "./AvailableCourse.css";


function AvailableCourse() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return ( 
        <div className="jeead-avlblCoursesSection">
            <div className="jeead-avlblCoursesContent">
                <div>
                    <h2 className="avlbl-head">Available Courses</h2>
                </div>
                <div className="jeead-avlblInfo">
                    <ul className="avlbl-list">
                        <li>Candidates can avail admission into programmes such as Bachelor's, Integrated Master's or Bachelor-Master Dual Degree in Engineering, Science, Architecture, Design or Pharmaceutics.
                        </li>
                    </ul>
                </div>
            </div>
        </div>
     );
}

export default AvailableCourse;