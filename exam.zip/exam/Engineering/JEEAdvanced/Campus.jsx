import { useEffect } from "react";
import "../JEEAdvanced/Campus.css";


function Campus() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (  
        <div className="jeead-campusSection">
            <div className="jeead-campusContent poppins-regular ">
                <div>
                    <h2 className="jeead-heading">Campus</h2>
                </div>
                <div>
                    <ul className="jeead-campusList">
                        <li><b>Indian Institute of Technology (IIT)</b></li>
                        <ol>
                            <li>Indian Institute of Petroleum & Energy (IIPE), <b>Visakhapatnam.</b></li>
                            <li>.Indian Institute of Science Education and Research (IISERs) located in <b>Berhampur, Bhopal, Kolkata, Mohali, Pune, Thiruvananthapuram, and Tirupati.</b></li>
                            <li>Indian Institute of Science,<b> Bengaluru.</b></li>
                            <li>Indian Institute of Space Science and Technology (IIST), <b>Thiruvananthapuram.</b></li>
                            <li>Rajiv Gandhi Institute of Petroleum Technology (RGIPT), 
                                <b>Rae Bareli.</b>
                            </li>
                        </ol>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Campus;