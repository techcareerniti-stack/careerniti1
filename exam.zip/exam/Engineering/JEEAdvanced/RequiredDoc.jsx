import { useEffect } from "react";
import "../JEEAdvanced/RequiredDoc.css";


function RequiredDoc() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return ( 
        <div className="jeead-requiresdocSection">
            <div className="jeead-requireddocContent poppins-regular">
                <div>
                    <h2 className="jeead-heading">Required Documents</h2>
                </div>
                <div>
                    <ol>
                        <li>Aadhaar card.</li>
                        <li>Class X/XII-mark sheets.</li>
                        <li>Passport-size photo.</li>
                        <li>Signature.</li>
                        <li>Category/PwD certificate (if applicable).</li>
                        <li>Email.</li>
                        <li>Mobile number</li>
                    </ol>
                </div>
            </div>
        </div>
     );
}

export default RequiredDoc;