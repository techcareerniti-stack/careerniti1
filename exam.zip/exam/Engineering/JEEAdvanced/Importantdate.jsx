import { useEffect } from "react";
import "../JEEAdvanced/Importantdate.css";


function Importantdate() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return ( 
        <div className="jeead-impdateSection">
            <div className="jeead-impdateContent">
                <div>
                    <h2 className="jeead-heading">Important Dates</h2>
                </div>
                <div>
                    <ul>
                        <li><b>Important Dates :-</b></li>
                        <table className="jeead-impdtTable">
                            <thead>
                                <td className="table-heading">Sr.No.</td>
                                <td className="table-heading">Activity</td>
                                <td className="table-heading">Day, Date and Time (IST)</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>JEE (Main) 2024</td>
                                    <td>JEE (Main) website</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Results of JEE (Main) 2024 by NTA</td>
                                    <td>JEE (Main) website</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Online Registration for JEE (Advanced) 2024</td>
                                    <td>Sunday, April 21, 2024 (10:00 IST) to <br /> Tuesday, April 30, 2024 (17:00 IST)</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Last date for fee payment of registered candidates</td>
                                    <td>Monday, May 06, 2024 (17:00 IST)</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>Admit Card available for downloading</td>
                                    <td>May 17, 2024 to May 26, 2024 </td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>Choosing of scribe by PwD candidates</td>
                                    <td>Saturday, May 25, 2024</td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>JEE (Advanced) 2024 Examination</td>
                                    <td>Sunday, May 26, 2024</td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>Paper 1</td>
                                    <td>09:00-12:00 IST</td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>Paper 2</td>
                                    <td>14:30-17:30 IST</td>
                                </tr>
                                <tr>
                                    <td>8</td>
                                    <td>Copy of candidate responses available</td>
                                    <td>Friday, May 31, 2024 (17:00 IST) </td>
                                </tr>
                                <tr>
                                    <td>9</td>
                                    <td>Online display of provisional answer keys</td>
                                    <td>Sunday, June 02, 2024 (10:00 IST)</td>
                                </tr>
                                <tr>
                                    <td>10</td>
                                    <td>Feedback and comments on provisional answer keys</td>
                                    <td>Sunday, June 02, 2024 (10:00 IST) to <br /> Monday, June 03, 2024 (17:00 IST) </td>
                                </tr>
                                <tr>
                                    <td>11</td>
                                    <td>Online declaration of final answer key and results</td>
                                    <td>Sunday, June 09, 2024 (10:00 IST)</td>
                                </tr>
                                <tr>
                                    <td>12</td>
                                    <td>Online registration for Architecture Aptitude Test (AAT) 2024</td>
                                    <td>Sunday, June 09, 2024 (10:00 IST) to <br /> Monday, June 10, 2024 (17:00 IST)</td>
                                </tr>
                                <tr>
                                    <td>13</td>
                                    <td>Tentative Start of Joint Seat Allocation (JoSAA) 2024 Process</td>
                                    <td>Monday, June 10, 2024 (17:00 IST)</td>
                                </tr>
                                <tr>
                                    <td>14</td>
                                    <td>Architecture Aptitude Test (AAT) 2024</td>
                                    <td>Wednesday, June 12, 2024 <br /> (09:00 IST to 12:00 IST)</td>
                                </tr>
                                <tr>
                                    <td>15</td>
                                    <td>Declaration of results of AAT 2024</td>
                                    <td>Saturday, June 15, 2024 (17:00 IST)</td>
                                </tr>
                            </tbody>
                        </table>
                    </ul>
                </div>
            </div>
        </div>
     );
}

export default Importantdate;