import "../BITSAT/BITSAT.css";
import Add_Navbar from "../../Add_Navbar";
import Introduction from "./Introduction";
import Eligibility from "./Eligibility";
import Aplnfee from "./Aplnfee";
import Testcity from "./Testcity";
import RequiredDoc from "./RequiredDoc";
import Campus from "./Campus";
import Syllabus from "./Syllabus";
import Importantdate from "./Importantdate";
import AvailableCourse from "./AvailableCourse";


function JEEAdvanced({ path, setLoc, loc,setSelectedNotify }) {
    const formatLocation = (location) => {
        const parts = location.split("/").filter((part) => part !== "");
        const capitalizedParts = parts.map((part) => {
          if (part.toLowerCase() === "jeeadcance") {
            return "JEE ADVANCE";
          } else {
            return part.charAt(0).toUpperCase() + part.slice(1);
          }
        });
    
        return capitalizedParts.join(" > ");
      };
    return ( 
       <>
         <Add_Navbar
        introduction={<Introduction />}
        eligibility={<Eligibility />}
        campuses={<Campus />}
        application_fees={<Aplnfee />}
        imp_dates={<Importantdate />}
        available_courses={<AvailableCourse />}
        test_centres={<Testcity />}
        syllabus={<Syllabus />}
        required_documents={<RequiredDoc />}
  
        setLoc={setLoc}
        path={path}
        formatLocation={formatLocation}
        loc={window.location.pathname +loc}
        setSelectedNotify={setSelectedNotify}
        name="JEE ADVANCE"
        longform="[Joint Entrance Examination Advance]"
      />
      <br />
       </>
        
     );
}

export default JEEAdvanced;