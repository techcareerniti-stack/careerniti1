import { useEffect } from "react";
import "../JEEAdvanced/Introduction.css";


function Introduction() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="jeead-introSection">
            <div className="jeead-introContent poppins-regular">
                <div>
                    <h2 className="jeead-heading">Introduction</h2>
                </div>
                <div>
                    <ul>
                        <li>
                            <div className="intro-para">
                                The Joint Entrance Examination (Advanced) 2024 [JEE (Advanced) 2024] will
                                be conducted by the seven Zonal Coordinating IITs under the guidance of the
                                Joint Admission Board 2024 (JAB 2024). The performance of a candidate in JEE
                                (Advanced) 2024 will form the basis for admission to the Bachelors, Integrated
                                Masters, and Dual Degree programs (entry at the 10+2 level), mentioned in
                                Clause 2, in all the IITs in the academic year 2024-25. The decisions of JAB
                                2024 will be final in all matters related to JEE (Advanced) 2024 and admission
                                to IITs in the academic year 2024-25.
                            </div>
                        </li>
                    </ul>

                </div>
            </div>
        </div>
    );
}

export default Introduction;