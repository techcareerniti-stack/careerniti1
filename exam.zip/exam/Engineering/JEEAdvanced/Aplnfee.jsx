import { useEffect } from "react";
import "../JEEAdvanced/Aplnfee.css";


function Aplnfee() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="jeead-feeSection">
            <div className="jeead-feeContent">
                <div>
                    <h2 className="jeead-heading">Application Fee</h2>
                </div>
                <div>
                    <ul>
                        <li><b>Fees :-</b></li>
                        <table className="jeead-feeTable">
                            <thead>
                                <td className="table-heading">Category</td>
                                <td className="table-heading">Registration Fee</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td className="table-heading" colSpan={2}>Indian Nationals</td>
                                </tr>
                                <tr>
                                    <td>Female Candidates (all categories)</td>
                                    <td className="numerical-data">₹1600</td>
                                </tr>
                                <tr>
                                    <td>SC, ST, and PwD Candidates</td>
                                    <td className="numerical-data">₹1600</td>
                                </tr>
                                <tr>
                                    <td>All Other Candidates</td>
                                    <td className="numerical-data">₹3200</td>
                                </tr>
                                <tr>
                                    <td className="table-heading" colSpan={2}>OCI/PIO card holders</td>
                                </tr>
                                <tr>
                                    <td>Female Candidates (GEN and GEN-PwD)</td>
                                    <td className="numerical-data">₹1600</td>
                                </tr>
                                <tr>
                                    <td>OPEN (GEN-PwD)</td>
                                    <td className="numerical-data">₹1600</td>
                                </tr>
                                <tr>
                                    <td>OPEN (GEN)</td>
                                    <td className="numerical-data">₹3200</td>
                                </tr>
                                <tr>
                                    <td className="table-heading" colSpan={2}>Foreign Nationals</td>
                                </tr>
                                <tr>
                                    <td>Candidates Residing in SAARC Countries</td>
                                    <td className="numerical-data">USD $100</td>
                                </tr>
                                <tr>
                                    <td>Candidates Residing in Non-SAARC Countries</td>
                                    <td className="numerical-data">USD $200</td>
                                </tr>
                            </tbody>
                        </table>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Aplnfee;