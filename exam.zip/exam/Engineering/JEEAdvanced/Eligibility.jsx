import { useEffect } from "react";
import "../JEEAdvanced/Eligibility.css";


function Eligibility() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="jeead-elgbltySection">
            <div className="jeead-elgbltyContent poppins-regular">
                <div>
                    <h2 className="jeead-heading">Eligibility</h2>
                </div>
                <div>

                    <ul className="elgblty-list">
                        All the candidates must simultaneously fulfil each and every one of the
                        following five criteria to appear for JEE (Advanced) 2024.
                        <li><b>Criterion 1 :- Performance in JEE (Main) 2024</b></li>
                        Candidates should be among the top 2,50,000 successful candidates (including
                        all categories) in B.E./B.Tech. paper of JEE (Main) 2024.
                        The percentages of various categories of candidates to be shortlisted are: 10%
                        for GEN-EWS, 27% for OBC-NCL, 15% for SC, 7.5% for ST, and the remaining
                        40.5% is OPEN for all. Within each of these five categories, 5% horizontal
                        reservation is available for PwD candidates.

                        <table className="jeead-elgbltyTbl">
                            <thead>
                                <tr>
                                    <td className="table-heading" colSpan={2}>Categorywise distribution of top 2,50,000 candidates</td>
                                </tr>
                                <tr>
                                    <td className="table-heading">Category</td>
                                    <td className="table-heading">Candidates</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>OPEN</td>
                                    <td className="numerical-data">96187</td>
                                </tr>
                                <tr>
                                    <td>OPEN-PwD</td>
                                    <td className="numerical-data"> 5063</td>
                                </tr>
                                <tr>
                                    <td>GEN-EWS</td>
                                    <td className="numerical-data"> 23750</td>
                                </tr>
                                <tr>
                                    <td>GEN-EWS-PwD</td>
                                    <td className="numerical-data">1250</td>
                                </tr>
                                <tr>
                                    <td>OBC-NCL </td>
                                    <td className="numerical-data">64125</td>
                                </tr>
                                <tr>
                                    <td>OBC-NCL-PwD</td>
                                    <td className="numerical-data">3375</td>
                                </tr>
                                <tr>
                                    <td>SC</td>
                                    <td className="numerical-data">35625</td>
                                </tr>
                                <tr>
                                    <td>SC-PwD</td>
                                    <td className="numerical-data">1875</td>
                                </tr>
                                <tr>
                                    <td>ST</td>
                                    <td className="numerical-data">17812</td>
                                </tr>
                                <tr>
                                    <td>ST-PwD</td>
                                    <td className="numerical-data">938</td>
                                </tr>
                            </tbody>
                        </table>

                        <br />

                        <li><b>Criterion 2 :- Age limit</b> </li>
                        Candidates should have been born on or after October 1, 1999. Five years age
                        relaxation is given to SC, ST, and PwD candidates, i.e. these candidates should
                        have been born on or after October 1, 1994.

                        <br /><br />

                        <li><b>Criterion 3 :- Number of attempts</b></li>
                        A candidate can attempt JEE (Advanced) a maximum of two times in two consecutive years.

                        <br /><br />

                        <li><b>Criterion 4 :-</b> Appearance in Class XII (or equivalent) examination</li>
                        Appearance in Class XII (or equivalent) examination*:
                        A candidate should have appeared for the Class XII (or equivalent) examination for the first time in either 2023 or 2024 with Physics, Chemistry, and Mathematics as compulsory subjects.<br />
                        Candidates who had appeared in Class XII (or equivalent) examination for the
                        first time in 2022 or earlier, are NOT eligible to appear in JEE (Advanced) 2024,
                        irrespective of the combination or number of subjects attempted/offered.
                        <br /><br />

                        <li><b>Criterion 5 :- Earlier admission at IITs</b> </li>
                        A candidate should NOT have been admitted to an IIT through JoSAA 2023
                        irrespective of whether or not the candidate continued in the program OR
                        accepted an IIT seat by reporting “online” / at a “reporting centre” in the
                        past. Candidates whose admission to IITs was cancelled (for whatever
                        reason) after joining any IIT are also NOT eligible to appear for JEE
                        (Advanced) 2024.
                        <br />
                        Candidates who have been admitted to a preparatory course in any of the
                        IITs for the first time in 2023 can appear in JEE (Advanced) 2024.
                        The candidates who were allocated a seat in an IIT through JoSAA 2023 but
                        (i) did not report “online” / at any “reporting centre” OR, (ii) withdrew before
                        the last round of seat allotment, OR, (iii) had their seat cancelled (for whatever reason) before the last round of seat allotment for IITs, are eligible
                        to appear for JEE (Advanced) 2024. <br />
                        However, in all of the above cases, the candidate is also required to fulfil the
                        conditions mentioned from Criterion 1 to Criterion 4.






                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Eligibility;