import React from "react";
import { useEffect } from "react";
import "./Eligibility.css"

function Eligibility() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ele-section-ibb ">
        <div className="ele-content-iiser poppins-regular">
          <h2 className="ibb-title">Eligibility</h2>
          <ol>
            <li>Candidates who have passed the 10+2 (or equivalent) examination with the Science stream (Physics, Chemistry, Biology) are eligible to apply.</li>
            <li>They should have a minimum of 50% marks (45% for reserved categories) in their qualifying examination.</li>
          </ol>
        </div>
      </div>
    </>
  );
}

export default Eligibility;