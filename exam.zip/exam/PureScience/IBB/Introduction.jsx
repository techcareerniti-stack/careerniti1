import React from "react";
import { useEffect } from "react";
import "./Introduction.css"

function Introduction() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (
        <>
        <div className="intro-section-ibb">
        <div className="intro-content-ibb poppins-regular">
          <h2 className="ibb-title">Introduction</h2>
          <ul>
            <li>
              <div>
              <p>The Institute of Bioinformatics and Biotechnology is an autonomous institute with an affiliation to the University of Pune. It was established in 2002 under the 'University with Potential for Excellence' program funded by the University Grants Commission of India.</p>
            </div>
            </li>
          </ul>

        </div>
      </div>
        </>
    );
}

export default Introduction;