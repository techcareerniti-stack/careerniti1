import React from "react";
import { useEffect } from "react";
import "./AvailableCourse.css"

function AvailableCourse() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return ( 
        <>
        <div className="ibb-avlblCoursesSection">
            <div className="ibb-avlblCoursesContent">
                <div>
                    <h2 className="avlbl-head">Available Courses</h2>
                </div>
                <div className="ibb-avlblInfo">
                    <ul>
                        <li>Master of Science (M.Sc.) Biotechnology</li>
                        <li>Bachelor of Science (B.Sc.) Biotechnology</li>
                        <li>Master of Science (M.Sc.) in Virology</li>
                    </ul>
                    

                </div>
            </div>
        </div>
        </>
     );
}

export default AvailableCourse;