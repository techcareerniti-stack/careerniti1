import { useEffect } from "react";
import "./ExamPattern.css";

function ExamPattern() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ImpDates-section-ibb ">
        <div className="ImpDates-content-ibb poppins-regular">
          <h2 className="ibb-title">Exam Pattern </h2>
          <div className="ibb-info">
            <ul>
              <li>An online objective type entrance examination will be conducted based on 10+2 level Science curriculum.</li>
              <li>Section I 20 marks: English, General Knowledge, Aptitude</li>
              <li>Section II 80 marks: Science subjects Math (10%), Physics (25%), Chemistry (25%) and Biology (40%).</li>
            </ul>
          </div>
        </div>
      </div>

    </>
  );
}

export default ExamPattern;