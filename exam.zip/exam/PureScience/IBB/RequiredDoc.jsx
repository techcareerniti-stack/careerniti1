import React from "react";
import { useEffect } from "react";
import "./RequiredDoc.css"

function RequiredDoc() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Rd-section-ibb ">
        <div className="Rd-content-ibb poppins-regular">
          <h2 className="ibb-title">Required Documents</h2>
          <div className="ibb-list">
          <ol>
            <li>Statement of marks of the qualifying examination (Note: in case of candidates whose results are awaited. Statement of marks would have to be submitted after the declaration of results and their admission to the course is subject to the fulfillment of the eligibility criterion stated in section “f”.)</li>
            <li>Leaving certificate of previously attended educational institute. </li>
            <li>Birth certificate / school leaving certificate </li>
            <li>Reserved Category Certificate from the competent authority (applicable to candidates belonging to reserved category with domicile in Maharashtra only) and cast validity certificate as a supporting document</li>
            <li>For the candidates having physical disability : attested true copy of minimum 40% physical disability certificate from competent authority (district Civil Surgeon) </li>
            <li>Non-creamy layer certificate if candidate belongs to OBC, NTC or NTD Category.</li>
            <li>Self-attested copies will be accepted for entrance exam; however, at the time of admission the documents attested by a competent authority will be accepted.</li>
          </ol>
          </div>
          </div>
          </div>
        </>
     );
}

export default RequiredDoc;