import React from "react";
import { useEffect } from "react";
import "./FAQ.css"

function FAQ() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Fq-section-iiser ">
        <div className="Fq-content-iiser poppins-regular">
          <h2 className="iiser-title"> Frequently Asked Questions (FAQs) </h2>

          <ul className="faq-all">
            
          </ul>
        </div>
      </div>        
        </>
     );
}

export default FAQ;