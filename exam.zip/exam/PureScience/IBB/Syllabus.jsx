import React from "react";
import { useEffect } from "react";
import "./Syllabus.css"

function Syllabus() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Syllabus-section-ibb ">
        <div className="Syllabus-content-ibb poppins-regular">
          <h2 className="ibb-title">Syllabus</h2>
          <div className="ibb-syllabus">
            10+2 level Science curriculum
          </div>
          </div>
          </div>
        </>
     );
}

export default Syllabus;