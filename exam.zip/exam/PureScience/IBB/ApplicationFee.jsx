import React from "react";
import { useEffect } from "react";
import "./ApplicationFee.css"

function ApplicationFee() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (
        <>
        <div className="fee-section-ibb ">
        <div className="fee-content-ibb poppins-regular">
          <h2 className="ibb-title">Application Fees</h2>
          <table className="ibb-fee-Table">
            <thead>
              <td className="tablehead">Category of Candidate</td>
              <td className="tablehead">Fees</td>
            </thead>
            <tbody>         
              <tr>
                <td>Open Category & Outside the state of Maharashtra </td>
                <td className="right-con">1000/-</td>
              </tr>
              <tr>
                <td>Reserved Category </td>
                <td className="right-con">600/-</td>
              </tr>
              </tbody>
              </table>
              </div>
              </div>
        </>
    );
}

export default ApplicationFee;