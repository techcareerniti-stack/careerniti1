import React from "react";
import { useEffect } from "react";
import "./TestCenter.css"

function TestCentre() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Tc-section-ibb ">
        <div className="Tc-content-ibb poppins-regular">
          <h2 className="ibb-title"> Test Centres </h2>

        </div>
      </div>
        </>
     );
}

export default TestCentre;