import React from "react";
import { useEffect } from "react";
import "./ImportantDate.css"

function ImportantDate() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ImpDates-section-ibb ">
        <div className="ImpDates-content-ibb poppins-regular">
          <h2 className="ibb-title">Important Dates </h2>

          <table className=" ibb-ImpDate-Table">
            <thead>
              <td className="tablehead-imp">Title</td>
              <td className="tablehead-imp">Dates</td>
            </thead>
            <tbody>
              <tr>
                <td>Application Start Date</td>
                <td >February 08, 2024</td>
              </tr>
              <tr>
                <td>
                Application From Last Date
                </td>
                <td >March 06, 2024 </td>
              </tr>
              <tr>
                <td>
                Correction in particulars of Application Form 
                </td>
                <td >March 08 2024 to March 09, 2024</td>
              </tr>
              <tr>
                <td>Date of Entrance</td>
                <td >April 20, 2024 (Saturday)</td>
              </tr>
              <tr>
                <td>Result</td>
                <td >
                Third Week of June</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
        </>
     );
}

export default ImportantDate;