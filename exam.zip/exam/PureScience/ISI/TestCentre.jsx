import React from "react";
import { useEffect } from "react";
import "./TestCentre.css"

function TestCentre() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Tc-section-Isi ">
        <div className="Tc-content-Isi poppins-regular">
          <h2 className="Isi-title"> Test Centres </h2>
          
          <ol>
            <li>Ahmedabad (DP)</li>
            <li>Durgapur (PU)</li>
            <li>Pune (BG)</li>
            <li>Bengaluru (GH)</li>
            <li>Guwahati (RP)</li>
            <li>Raipur (BH)</li>
            <li>Bhubaneswar (HY)</li>
            <li>Hyderabad (RN)</li>
            <li>Ranchi (CC)</li>
            <li>Kolkata (ID)</li>
            <li>Indore (SC)</li>
            <li>Silchar (CH)</li>
            <li>Chandigarh (JP)</li>
            <li>Jaipur (SG)</li>
            <li>Siliguri (CN)</li>
            <li>Chennai (JS)</li>
            <li>Jamshedpur (TZ), </li>
            <li>Tezpur (CO), </li>
            <li>Cochin (KN)</li>
            <li>Kanpur (VJ)</li>
            <li>Vijayawada (CM)</li>
            <li>Coimbatore (MB)</li>
            <li>Mumbai (VN)</li>
            <li>Varanasi (DN)</li>
            <li>Dehradun (NG)</li>
            <li>Nagpur (VP)</li>
            <li>Visakhapatnam (DH), </li>
            <li>Delhi (PT)</li>
            
          </ol>
          </div>
        </div>
        </>
     );
}

export default TestCentre;