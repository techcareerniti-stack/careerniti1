import React from "react";
import { useEffect } from "react";
import "./AvailableCourse.css"

function AvailableCourse() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ele-section-Isi ">
        <div className="ele-content-Isi poppins-regular">
          <h2 className="Isi-title">Available Courses</h2>
          <div>
            <ol type="1">
                <li>B.Stat (Hons): Bachelor of Statistics (Honours)</li>
                <li>B.Math (Hons): Bachelor of Mathematics (Honours)</li>
                <li>M.Stat: Master of Statistics</li>
                <li>M.Math: Master of Mathematics</li>
                <li>M.Tech (CS): Master of Technology in Computer Science</li>
                <li>M.Tech (QROR): Master of Technology in Quality, Reliability, and Operations Research</li>
                <li>M.Tech (CRS): Master of Technology in Cryptology and Security</li>
                <li>MS (QE): Master of Science in Quantitative Economics</li>
                <li>MS (QMS): Master of Science in Quality Management Science</li>
                <li>MS (LIS): Master of Science in Library and Information Science</li>
                <li>MS (CS): Master of Science in Computer Science</li>
                <li>MS (CQMS): Master of Science in Quality Management Science</li>
                <li>PG Diplomas: ISI offers various Postgraduate Diplomas in subjects like Statistical Methods and Analytics, Computer Applications, etc.</li>
            </ol>
          </div>
        </div>
      </div>
        </>
     );
}

export default AvailableCourse;