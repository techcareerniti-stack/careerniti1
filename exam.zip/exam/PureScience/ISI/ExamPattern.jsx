import React from "react";
import { useEffect } from "react";
import "./ExamPattern.css"

function ExamPattern() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (
        <>
        <div><div className="ele-section-Isi ">
        <div className="ele-content-Isi poppins-regular">
          <h2 className="Isi-title">Exam Pattern</h2>
          <div>

           <b>Total Marks</b><br />
           Section 1 - 30 marks, <br />Section 2 - 70 marksbr<br />
           <b>Exam Language: </b>English <br />

           <b>Exam Duration:</b><br />
           Section 1 - 2 hours, <br />
           Section 2 - 2 hours <br />

           <b>Question Paper Type:</b> <br />
           Section 1 - Multiple Choice Questions,  <br />
           Section 2 - Descriptive type Questions



  
          </div>
        </div>
      </div></div>
        </>
      );
}

export default ExamPattern;