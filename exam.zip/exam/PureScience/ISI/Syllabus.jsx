import React from "react";
import { useEffect } from "react";
import "./Syllabus.css"

function Syllabus() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Syllabus-section-Isi ">
        <div className="Syllabus-content-Isi poppins-regular">
          <h2 className="Isi-title">Syllabus</h2>
          <p>
            <b>Mathematics:</b><br />
            Algebra: Binomial Theorem, AP, GP, Series, Permutations and Combinations, Polynomial Equations.Linear Algebra: Vector Spaces, Linear Transformations, Matrix Operations, Systems of Linear Equations.Calculus: Limits, Continuity, Differentiation, Integration, Optimization, Implicit Function Theorem.Statistics: Probability Theory, Central Tendency, Dispersion, Correlation, Regression, Probability Distributions (Binomial, Normal). <br /><br />

            <b>Microeconomics:</b><br />
            Consumer Behaviour Theory, Production TheoryMarket Structure: Perfect Competition, Monopoly, Price Discrimination, Duopoly (Cournot and Bertrand Competition)Economic Concepts: Public Goods, Externalities, General Equilibrium, Welfare Economics. <br /><br />

            <b>Macroeconomics:</b><br />
            National income accounting, Simple Keynesian Model of income determination and the multiplier,IS-LM Model, Models of aggregate demand and aggregate supply, Money, banking and inflation,Phillips curve, Elementary open economy macroeconomics, the Harrod-Domar Model, and theSolow Model. <br /><br />

          </p>


        </div>
      </div>
    </>
  );
}

export default Syllabus;