import React from "react";
import { useEffect } from "react";
import "./ApplicationFee.css"

function ApplicationFee() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="fee-section-bitsat ">
        <div className="fee-content-bitsat poppins-regular">
          <h2 className="bitsat-title">Application Fees</h2>
          
            <b>₹1500.00</b> - for <b>male</b>  applicants in the General category <br />
            <b>₹1000.00</b> -for <b>female</b> applicants in the General category <br />
            <b>₹750.00</b> -for <b>reserved category</b>  candidates
        </div>
      </div>
        </>
     );
}

export default ApplicationFee;