import React from "react";
import { useEffect } from "react";
import "./Introduction.css"

function Introduction() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="intro-section-Isi ">
        <div className="intro-content-Isi poppins-regular">
          <h2 className="Isi-title">Introduction</h2>

          <div>
            <p>The Indian Statistical Institute (ISI) conducts the ISI Admission Test every year to offer admissions to eligible candidates into various undergraduate, postgraduate, and doctoral programs in Statistics, Mathematics, Computer Science, and other related fields.</p>
          </div>


        </div>
      </div>
    </>
  );
}

export default Introduction;