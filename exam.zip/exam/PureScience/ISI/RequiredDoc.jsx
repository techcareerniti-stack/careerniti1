import React from "react";
import { useEffect } from "react";
import "./RequiredDoc.css"

function RequiredDoc() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Rd-section-Isi ">
        <div className="Rd-content-Isi poppins-regular">
          <h2 className="Isi-title">Required Documents</h2>
          <p>
            <ul>
              <li>Photo</li>
              <li>Sign</li>
            </ul>
          </p>
        </div>
      </div>
    </>
  );
}

export default RequiredDoc;