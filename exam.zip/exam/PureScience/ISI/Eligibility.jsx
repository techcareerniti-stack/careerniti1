import React from "react";
import { useEffect } from "react";
import "./Eligibility.css"

function Eligibility() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ele-section-Isi ">
        <div className="ele-content-Isi poppins-regular">
          <h2 className="Isi-title">Eligibility</h2>
          <div>
           Indian nationality or relevant documents for foreign nationals.Completion of 10+2 for undergraduate programs and a relevant bachelor's degree for postgraduate programs.Minimum marks as specified for each program.Age limit as applicable (varies for different categories).
          </div>
        </div>
      </div>
        </>
     );
}

export default Eligibility;