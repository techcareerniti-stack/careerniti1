import React from "react";
import { useEffect } from "react";
import "./FAQ.css"

function FAQ() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Fq-section-Isi ">
        <div className="Fq-content-Isi poppins-regular">
          <h2 className="Isi-title">FAQ Section</h2>

          <b >Q: What are the eligibility criteria for the ISI entrance exam?</b><br />
          A: Eligibility criteria include nationality, educational qualifications, minimum marks, and age limits, which may vary based on the program. Please refer to the official website for specific details.<br /><br />

          <b className="Isi-b-padding">Q: What is the syllabus for the ISI entrance exam?</b><br />
          A: The syllabus typically covers topics in mathematics, statistics, physics, computer science, and other related fields, depending on the specific program. <br /><br />

          <b className="Isi-b-padding">Q: How can I apply for the ISI entrance exam?</b><br />
          A: The application process is usually online. Applicants need to visit the official ISI website, fill out the application form, and submit the required documents and application fee. <br /><br />

          <b className="Isi-b-padding">Q: What is the exam pattern for the ISI entrance exam?</b><br />
          A: The exam generally consists of multiple-choice questions (MCQs) and descriptive questions, covering various subjects depending on the program. Please refer to the official website for specific details. <br /><br />

          <b>Q: What are the important dates related to the ISI entrance exam, such as application deadlines and exam dates?</b><br />
          A: The official website provides the important dates for application submission, admit card release, examination dates, and result announcements for the current academic year. <br /><br />

          <b>Q: What is the application fee for the ISI entrance exam, and how can it be paid?</b><br />
          A: The application fee varies for different categories and can usually be paid online through the designated payment portal specified on the ISI website. <br /><br />

          <b>Q: Is there any age limit for appearing in the ISI entrance exam?</b>
          A: Yes, there might be an upper age limit for certain programs. Please check the official website for specific age limit details. <br /><br />

          <b>Q: Are there any reserved seats or quotas for specific categories of candidates?</b><br />
          A: Yes, there are reserved seats and quotas for categories such as OBC-NCL, SC, ST, PwD, and EWS. Candidates belonging to these categories should refer to the official website for specific details. <br /><br />

          <b>Q: What are the different programs offered by ISI and their respective admission procedures?</b><br />
          A: ISI offers various undergraduate and postgraduate programs in statistics, mathematics, and related fields. The admission procedures may vary for each program. Please refer to the official website for detailed information. <br /><br />

          <b>Q: What are the documents required for the ISI entrance exam application and admission process?</b> <br />
          A: Required documents usually include the admit card, photo ID proof, passport-size photographs, and, if applicable, category certificates. Please check the official website for the complete list of required documents and their specifications.
        </div>
      </div>
    </>
  );
}

export default FAQ;