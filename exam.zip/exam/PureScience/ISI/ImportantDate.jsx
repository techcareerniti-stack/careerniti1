import React from "react";
import { useEffect} from "react";
import "./ImportantDate.css"

function ImportantDate() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ImpDates-section-Isi ">
        <div className="ImpDates-content-Isi poppins-regular">
          <h2 className="Isi-title">Important Dates </h2>

          <table className="Niser-ImpDate-Table">
            <thead>
              <td className="tablehead-imp">Activity</td>
              <td className="tablehead-imp">Dates</td>
            </thead>
            <tbody>
              <tr>
                <td>Application Registration Starts</td>
                <td >Second Week of March 2024</td>
              </tr>
              <tr>
                <td>
                Application Ends on
                </td>
                <td >First Week of April 2024</td>
              </tr>
              
            </tbody>
          </table>
        </div>
      </div>
        </>
     );
}

export default ImportantDate;