import React, { useState } from "react";
import Add_Navbar from "../../Add_Navbar";

import Introduction from "./Introduction";
import AvailableCourse from "./AvailableCourse";
import ApplicationFee from "./ApplicationFee";
import Campus from "./Campus";
import Eligibility from "./Eligibility";
import ExamPattern from "./ExamPattern";
import TestCentre from "./TestCentre";
import FAQ from "./FAQ";
import ImportantDate from "./ImportantDate";
import RequiredDoc from "./RequiredDoc";
import Syllabus from "./Syllabus";

function ISI({ path, setLoc, loc, setSelectedNotify }) {
  const formatLocation = (location) => {
    const parts = location.split("/").filter((part) => part !== "");
    const capitalizedParts = parts.map((part) => {
      if (part.toLowerCase() === "isi") {
        return "ISI";
      } else {
        return part.charAt(0).toUpperCase() + part.slice(1);
      }
    });

    return capitalizedParts.join(" > ");
  };

  return (
    <>
      <Add_Navbar
        introduction={<Introduction />}
        eligibility={<Eligibility />}
        available_courses={<AvailableCourse />}
        campuses={<Campus />}
        application_fees={<ApplicationFee />}
        imp_dates={<ImportantDate />}
        exam_pattern={<ExamPattern />}
        syllabus={<Syllabus />}
        test_centres={<TestCentre />}
        required_documents={<RequiredDoc />}
        faq={<FAQ />}
        setLoc={setLoc}
        setPath={path}
        formatLocation={formatLocation}
        loc={window.location.pathname + loc}
        name="ISI"
        longform="[ Indian Statistical Institute]"
        setSelectedNotify={setSelectedNotify}
      />
    </>
  );
}

export default ISI;
