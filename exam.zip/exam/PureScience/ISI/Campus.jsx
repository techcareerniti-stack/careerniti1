import React from "react";
import { useEffect } from "react";
import "./Campus.css"

function Campus() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return ( 
        <>
        <div className="Isi-campusSection">
            <div className="Isi-campusContent">
                <div>
                    <h2 className="campus-hed">Campus</h2>
                </div>
                <div className="Isi-campusInfo">
                        <ol >
                            <li>ISI Kolkata (Headquarter), </li>
                            <li>ISI Chennai,</li>
                            <li>ISI Bengaluru,</li>
                            <li>ISI Delhi, </li>
                            <li>ISI North-East Centre, Tezpur.</li>
                        </ol>
                </div>
            </div>
        </div>
        </>
     );
}

export default Campus;