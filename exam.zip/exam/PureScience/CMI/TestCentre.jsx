import React from "react";
import { useEffect } from "react";
import "./TestCentre.css"

function TestCentre() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (
        <>
           <div className="Tc-section-CMI ">
        <div className="Tc-content-CMI poppins-regular">
          <h2 className="CMI-title"> Test Centres </h2>
          

          <div>
          <table className="CMI-tc-Table">
            <thead>
              <td className="tabledata-imp" colSpan={2}><b>List of CMI entrance exam 2023 centres (Expected)</b></td>
            </thead>
            <tbody>
              <tr>
                <td>Agartala</td>
                <td >Kanpur</td>
              </tr>

              <tr>
                <td>Ahmedabad</td>
                <td >Kharagpur</td>
              </tr>

              <tr>
                <td >Allahabad</td>
                <td >Kolkata</td>
              </tr>

              <tr>
                <td>Bangalore</td>
                <td >Madurai</td>
              </tr>

              <tr>
                <td>Bhubaneswar</td>
                <td >Mumbai</td>
              </tr>

              <tr>
                <td>Calicut</td>
                <td >Nagpur</td>
              </tr>

              <tr>
                <td >Chandigarh</td>
                <td >New Delhi</td>
              </tr>

              <tr>
                <td>Chennai</td>
                <td>Noida</td>
              </tr>

              <tr>
                <td>Cochin</td>
                <td >Patna</td>
              </tr>

              <tr>
                <td>Coimbatore</td>
                <td >Pune</td>
              </tr>

              <tr>
                <td >Durgapur</td>
                <td >Raipur</td>
              </tr>

              <tr>
                <td >Goa</td>
                <td >Ranchi</td>
              </tr>

              <tr>
                <td >Gurugram</td>
                <td >Shillong</td>
              </tr>

              <tr>
                <td >Guwahati</td>
                <td >Silchar</td>
              </tr>

              <tr>
                <td >Hyderabad</td>
                <td >Siliguri</td>
              </tr>

              <tr>
                <td>Imphal</td>
                <td >Srinagar</td>
              </tr>

              <tr>
                <td>Indore</td>
                <td >Tiruchi</td>
              </tr>
              <tr>
                <td>Jaipur</td>
                <td >Trivandrum</td>
              </tr>

              <tr>
                <td className="tabledata-imp" colSpan={2}>Visakhapatnam</td>
              </tr>

            </tbody>
          </table>
          </div>
        </div>
      </div>
        </>
    );
}

export default TestCentre;