import { useEffect } from "react";
import "./Syllabus.css";

function Syllabus() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Syllabus-section-NEET_PG ">
        <div className="Syllabus-content-NEET_PG poppins-regular">
          <h2 className="NEET_PG-title">Syllabus</h2>
          
              <div>
                <p>Problem-solving ability in mathematics with sound reasoning and coherent writing.Knowledge of topics up to 12th standard, including calculus, algebra, geometry, combinatorics, and number theory.Understanding of real-valued functions, number theory principles, and complex numbers, including roots of unity and the fundamental theorem of algebra.</p>
              </div>
           
        </div>
      </div>
        <div className="Syllabus-section-CMI ">
        <div className="Syllabus-content-CMI poppins-regular">
          <h2 className="CMI-title">Syllabus</h2>
          
              <div>
                <p>Problem-solving ability in mathematics with sound reasoning and coherent writing.Knowledge of topics up to 12th standard, including calculus, algebra, geometry, combinatorics, and number theory.Understanding of real-valued functions, number theory principles, and complex numbers, including roots of unity and the fundamental theorem of algebra.</p>
              </div>
           
        </div>
      </div>
        </>
     );
}

export default Syllabus;