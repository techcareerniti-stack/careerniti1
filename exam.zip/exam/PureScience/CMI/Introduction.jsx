import React from "react";
import { useEffect } from "react";
import "./Introduction.css"

function Introduction() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (  
        <>
        <div className="intro-section-CMI ">
        <div className="intro-content-CMI poppins-regular">
          <h2 className="CMI-title">Introduction</h2>

              <div>
             <p>Chennai Mathematical Institute (CMI) is a leading institution for mathematical sciences established in 1989 under the SPIC Science Foundation. Since 1996, it has operated independently with a Governing Council. Notable for its public-private partnership, CMI receives significant private and government funding. It specializes in Mathematics, Computer Science, and Physics research, offering BSc and MSc programs alongside a dynamic PhD program. </p> 
              </div>

        </div>
      </div>
        </>
    );
}

export default Introduction;