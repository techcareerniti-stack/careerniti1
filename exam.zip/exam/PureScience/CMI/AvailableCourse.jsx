import React from "react";
import { useEffect } from "react";

import "./AvailableCourse.css"
function AvailableCourse() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (
        <>
        <div className="ele-section-CMI ">
        <div className="ele-content-CMI poppins-regular">
          <h2 className="CMI-title">Available Courses</h2>
          <div>
            <p>Admission will be made to the following programmes in 2024–25.</p>

            <ul>
                <li>B.Sc. (Hons.) in Mathematics and Computer Science (3 year course).</li>
                <li>B.Sc. (Hons.) in Mathematics and Physics (3 year course).</li>
                <li>M.Sc. in Mathematics.</li>
                <li>M.Sc. in Computer Science.</li>
                <li>M.Sc. in Data Science.</li>
                <li>Ph.D. in Mathematics.</li>
                <li>Ph.D. in Computer Science.</li>
                <li>Ph.D. in Physics.</li>
            </ul>
          </div>
        </div>
      </div>
        </>
    );
}

export default AvailableCourse;