import React from "react";
import { useEffect } from "react";
import "./Introduction.css"

function FAQ() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Fq-section-CMI ">
        <div className="Fq-content-CMI poppins-regular">
          <h2 className="CMI-title"> Frequently Asked Questions (FAQs) </h2>

            <div className="cmi-faq">

                <ol>

                    <li><b>Who is eligible for the CMI entrance exam?<br />Ans.</b>Candidates who have passed or appeared for the Class 12 or an equivalent examination are eligible to apply. There is no age limit for undergraduate courses.</li>

                    <li><b>What are the pass marks for the CMI entrance exam?<br />Ans.</b>The cutoff has been around 40% for the objective section and 40-50% overall. CMI does not publish the cutoff marks but they have responded to individual requests in the past.</li>

                    <li><b>What is the tuition fee for CMI?<br />Ans.</b>The tuition fee is Rs 1,25,000/- per semester (two semesters in a year). About 30–35 scholarships will be available, consisting of a full waiver of the tuition fees for three years. In addition, a limited number of fellowships will be available, with a monthly stipend of Rs. 5,000.</li>

                    <li><b>What is the admission process for CMI?<br />Ans.</b>The admission process consists of a written examination. For some courses, the written examination is followed by an oral examination (interview).</li>


                </ol>

            </div>
                
        </div>
      </div>
        </>
     );
}

export default FAQ;