import React from "react";
import { useEffect } from "react";

import "./ApplicationFee.css"
function ApplicationFee() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (
        <>
            <div className="fee-section-bitsat ">
        <div className="fee-content-bitsat poppins-regular">
          <h2 className="bitsat-title">Application Fees</h2>
          
          <p>Registration Fee for All Candidates: 1,000/-</p>
        </div>
      </div>
        </>
    );
}

export default ApplicationFee;