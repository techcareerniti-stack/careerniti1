import React from "react";
import { useEffect } from "react";
import "./ImportantDate.css"

function ImportantDate() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ImpDates-section-CMI ">
        <div className="ImpDates-content-CMI poppins-regular">
          <h2 className="CMI-title">Important Dates </h2>

          <table className="CMI-ImpDate-Table">
            <thead>
              <td className="tablehead-imp">Activity</td>
              <td className="tablehead-imp-dt">Dates</td>
            </thead>
            <tbody>
              <tr>
                <td>Application Registration Starts</td>
                <td >4 March, 2024</td>
              </tr>
              <tr>
                <td>
                Application Closed on
                </td>
                <td >15 April, 2024,</td>
              </tr>
              <tr>
                <td>
                Admit Cards to be available online
                </td>
                <td >12 May, 2024</td>
              </tr>
              <tr>
                <td>Date of the Entrance Examination</td>
                <td >19 May, 2024</td>
              </tr>
              <tr>
                <td>Date of announcement of results</td>
                <td >Approximately one month from the date of the entrance examination</td>
              </tr>
              
            </tbody>
          </table>
        </div>
      </div>
        </>
     );
}

export default ImportantDate;