import React from "react";
import { useEffect } from "react";
import "./Campus.css"

function Campus() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="cam-section-CMI ">
        <div className="cam-content-CMI poppins-regular">
          <h2 className="CMI-title">Campuses</h2>
          <p>
            CMI moved into its new campus on five acres of land at the <b> SIPCOT Information Technology Park in Siruseri</b> in October, 2005.
          </p>
        </div>
      </div>
    </>
  );
}

export default Campus;