import React, { useState } from "react";
import Add_Navbar from "../../Add_Navbar";

import Introduction from "./Introduction";
import Eligibility from "./Eligibility";
import AvailableCourse from "./AvailableCourse";
import Campus from "./Campus";
import ApplicationFee from "./ApplicationFee";
import ExamPattern from "./ExamPattern";
import FAQ from "./FAQ";
import ImportantDate from "./ImportantDate";
import RequiredDoc from "./RequiredDoc"
import Syllabus from "./Syllabus";
import TestCentre from "./TestCentre";


function CMI({ path, setLoc, loc, setSelectedNotify }) {
    const formatLocation = (location) => {
        const parts = location.split("/").filter((part) => part !== "");
        const capitalizedParts = parts.map((part) => {
            if (part.toLowerCase() === "cmi") {
                return "CMI";
            } else {
                return part.charAt(0).toUpperCase() + part.slice(1);
            }
        });

        return capitalizedParts.join(" > ");
    };

    return (
        <>
            <Add_Navbar

                introduction={<Introduction />}
                eligibility={<Eligibility />}
                available_courses={<AvailableCourse />}
                campuses={<Campus />}
                application_fees={<ApplicationFee />}
                imp_dates={<ImportantDate />}
                exam_pattern={<ExamPattern />}
                syllabus={<Syllabus />}
                test_centres={<TestCentre />}
                required_documents={<RequiredDoc />}
                faq={<FAQ />}

                setLoc={setLoc}
                setPath={path}
                formatLocation={formatLocation}
                loc={window.location.pathname +loc}
                name="CMI"
                longform="[Chennai Mathematical Institute]"
                setSelectedNotify={setSelectedNotify}

            />
        </>
    );
}

export default CMI;