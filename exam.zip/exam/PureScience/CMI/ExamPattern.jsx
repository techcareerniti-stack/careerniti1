import React from "react";
import { useEffect } from "react";
import "./ExamPattern.css"

function ExamPattern() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ExamP-section-CMI ">
        <div className="ExamP-content-CMI poppins-regular">
          <h2 className="CMI-title">Exam Pattern -</h2>

          <p>The key features of both undergraduate and postgraduate courses will be as under:</p>

          <table className="CMI-fee-Table">
            <thead>
              <td className="tablehead">Features </td>
              <td className="tablehead">Description</td>
            </thead>
            <tbody>         
              <tr>
                <td><b>Exam mode</b></td>
                <td className="left-con">Pen-paper based test mode</td>
              </tr>
              <tr>
                <td><b>Test duration </b></td>
                <td className="left-con">Three hours </td>
              </tr>
              <tr>
                <td><b>Exam medium </b></td>
                <td className="left-con">English only</td>
              </tr>
              <tr>
                <td>
                  <b>Type of questions </b>
                </td>
                <td className="left-con">Objective as well as subjective questions</td>
              </tr>
              <tr>
                <td><b>Total questions</b></td>
                <td className="left-con">16 questions for UG <br /> 17 questions for MSc/ PhD Computer Scienc <br /> 20 questions for MSc/ PhD Mathematics <br />36 questions for MSc Data Science </td>       
              </tr>
              <tr>
                <td><b>Total marks </b></td>
                <td className="left-con">For UG total marks is 100 <br /> marksFor PG it ranges from 90 to 100 marks </td>       
              </tr>
            </tbody>
          </table>
          
        </div>
      </div>
        </>
     );
}

export default ExamPattern;