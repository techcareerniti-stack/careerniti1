import React from "react";
import { useEffect } from "react";
import "./RequiredDoc.css";

function RequiredDoc() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Rd-section-CMI ">
        <div className="Rd-content-CMI poppins-regular">
          <h2 className="CMI-title">Required Documents</h2>
          <ul>
            <li>Photo</li>
            <li>Sign</li>
            <li>Identity Proof</li>
          </ul>
        </div>
      </div>
        </>
     );
}

export default RequiredDoc;