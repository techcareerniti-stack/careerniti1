import React from "react";
import { useEffect } from "react";
import "./Eligibility.css"

function Eligibility() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ele-section-CMI ">
        <div className="ele-content-CMI poppins-regular">
          <h2 className="CMI-title">Eligibility</h2>
          <div>
           <ol>

            <li><b>B.Sc. (Hons.) Mathematics and Computer Science:</b>12th standard or equivalent.</li>

            <li><b>B.Sc. (Hons.) Mathematics and Physics:</b>12th standard or equivalent.</li>

            <li><b>M.Sc. in Mathematics:</b>Undergraduate degree (BA, BSc, BE, BTech, …) with a strong background in mathematics.</li>

            <li><b>M.Sc. in Computer Science:</b>Undergraduate degree (BA, BSc, BE, BTech, …) with a strong background in computer science.</li>

            <li><b>M.Sc. in Data Science:</b>Undergraduate degree (BA, BSc, BE, BTech, …) with a background in mathematics/statistics/computer science.</li>

            <li><b>Ph.D. in Mathematics:</b>B.E./B.Tech/B.Sc.(Math)/M.Sc.(Math).</li>

            <li><b>Ph.D. in Computer Science:</b>B.E/B.Tech/M.Sc.(C.S.)/M.C.A.</li>

            <li><b>Ph.D. in Physics:</b>M.Sc.(Physics).</li>

           </ol>
          </div>
        </div>
      </div>
        </>
     );
}

export default Eligibility;