import { useEffect } from "react";
import React from "react";
import "./TestCentre.css"

function TestCentre() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Tc-section-Niser ">
        <div className="Tc-content-Niser poppins-regular">
          <h2 className="Niser-title"> Test Centres </h2>
          

        
           
          <table className="Niser-tc-Table">
            <thead>
              <td className="tablehead-imp"><b>Name of State/UT</b></td>
              <td className="tablehead-imp"><b>IISER Exam Centres</b></td>
            </thead>
            <tbody>
              <tr>
                <td className="tabledata-imp">Andaman & Nicobar Islands</td>
                <td >
                  <ul>
                    <li>Port Blair</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                West Bengal
                </td>
                <td >
                    <ul>
                        <li>Siliguri</li>
                        <li>Kolkata</li>
                        <li>Kharagpur</li>
                        <li>Kalyani</li>
                        <li>Hooghly</li>
                        <li>Durgapur</li>
                        <li>Asansol</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Uttar Pradesh
                </td>
                <td >
                    <ul>
                        <li>Varanasi</li>
                        <li>Noida</li>
                        <li>Lucknow</li>
                        <li>Kanpur</li>
                        <li>Jhansi</li>
                        <li>Gorakhpur</li>
                        <li>Faizabad</li>
                        <li>Bareilly</li>
                        <li>Allahabad</li>
                        <li>Agra</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Uttarakhand
                </td>
                <td >
                    <ul>
                        <li>Roorkee</li>
                        <li>Haridwar</li>
                        <li>Haldwani</li>
                        <li>Dehradun</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Tripura
                </td>
                <td >
                    <ul>
                        <li>Agartala</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Telangana
                </td>
                <td >
                    <ul>
                        <li>Warangal</li>
                        <li>Nizamabad</li>
                        <li>Mahbubnagar</li>
                        <li>Khammam</li>
                        <li>Karimnagar</li>
                        <li>Hyderabad</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Tamil Nadu
                </td>
                <td >
                    <ul>
                        <li>Virudhnagar</li>
                        <li>Tiruppur</li>
                        <li>Thoothukudi</li>
                        <li>Tiruchirapalli</li>
                        <li>Tirunelveli</li>
                        <li>Salem</li>
                        <li>Nagercoil</li>
                        <li>Madurai</li>
                        <li>Kanyakumari</li>
                        <li>Coimbatore</li>
                        <li>Chennai</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Sikkim
                </td>
                <td >
                    <ul>
                        <li>Sikkim</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Rajasthan
                </td>
                <td >
                    <ul>
                        <li>Udaipur</li>
                        <li>Jodhpur</li>
                        <li>Jaipur</li>
                        <li>Bikaner</li>
                        <li>Alwar</li>
                        <li>Ajmer</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Puducherry
                </td>
                <td >
                    <ul>
                        <li>Puducherry</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Punjab
                </td>
                <td >
                    <ul>
                        <li>Patiala</li>
                        <li>Mohali</li>
                        <li>Ludhiana</li>
                        <li>Jalandhar</li>
                        <li>Bathinda</li>
                        <li>Amritsar</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Odisha
                </td>
                <td >
                    <ul>
                        <li>Rourkela</li>
                        <li>Cuttack</li>
                        <li>Bhubaneswar</li>
                        <li>Berhampur</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Nagaland
                </td>
                <td >
                    <ul>
                        <li>Kohima</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Mizoram
                </td>
                <td >
                    <ul>
                    <li>Aizwal</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Meghalaya
                </td>
                <td >
                    <ul>
                    <li>Shillong</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Manipur
                </td>
                <td >
                    <ul>
                    <li>Imphal</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Maharashtra
                </td>
                <td >
                    <ul>
                    <li>Pune</li>
                    <li>Navi Mumbai</li>
                    <li>Nashik</li>
                    <li>Nagpur</li>
                    <li>Mumbai</li>
                    <li>Kolhapur</li>
                    <li>Aurangabad</li>
                    <li>Amravati</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Madhya Pradesh
                </td>
                <td >
                    <ul>
                    <li>Satna</li>
                    <li>Gwalior</li>
                    <li>Jabalpur</li>
                    <li>Indore</li>
                    <li>Bhopal</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Kerala
                </td>
                <td >
                    <ul>
                    <li>Wayanad</li>
                    <li>Trivandrum</li>
                    <li>Thrissur</li>
                    <li>Pathanamthitta</li>
                    <li>Palakkad</li>
                    <li>Mallapuram</li>
                    <li>Kozhikode</li>
                    <li>Kottayam</li>
                    <li>Kollam</li>
                    <li>Kochi (Ernakulam)</li>
                    <li>Kasargod</li>
                    <li>Kannur</li>
                    <li>Idukki</li>
                    <li>Alappuzha</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Karnataka
                </td>
                <td >
                    <ul>
                    <li>Shivamogga</li>
                    <li>Mysuru</li>
                    <li>Mangalam</li>
                    <li>Hubballi</li>
                    <li>Gulbarga</li>
                    <li>Dharwad</li>
                    <li>Bengaluru</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Jharkhand
                </td>
                <td >
                    <ul>
                    <li>Ranchi</li>
                    <li>Jamshedpur</li>
                    <li>Dhanbad</li>
                    <li>Bokaro</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Jammu & Kashmir
                </td>
                <td >
                    <ul>
                    <li>Jammu</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Himachal Pradesh
                </td>
                <td >
                    <ul>
                    <li>Shimla</li>
                    <li>Kangra</li>
                    <li>Hamirpur</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Haryana
                </td>
                <td >
                    <ul>
                    <li>Panipat</li>
                    <li>Kurukshetra</li>
                    <li>Karnal</li>
                    <li>Hisar</li>
                    <li>Gurugram</li>
                    <li>Bahadurgarh</li>
                    <li>Ambala</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Gujarat
                </td>
                <td >
                    <ul>
                    <li>Vadodara</li>
                    <li>Surat</li>
                    <li>Rajkot</li>
                    <li>Gandhinagar</li>
                    <li>Bhavnagar</li>
                    <li>Ahmedabad</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Goa
                </td>
                <td >
                    <ul>
                    <li>Panaji</li>
                    <li>Madgaon</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Delhi
                </td>
                <td >
                    <ul>
                    <li>New Delhi</li>
                    <li>Delhi</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Chattisgarh
                </td>
                <td >
                    <ul>
                    <li>Raipur</li>
                    <li>Bilaspur</li>
                    <li>Bhilai</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Chandigarh
                </td>
                <td >
                    <ul>
                    <li>Chandigarh</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Bihar
                </td>
                <td >
                    <ul>
                    <li>Samastipur</li>
                    <li>Patna</li>
                    <li>Muzaffarpur</li>
                    <li>Gaya</li>
                    <li>Darbhanga</li>
                    <li>Bhagalpur</li>
                    <li>Aurangabad</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Assam
                </td>
                <td >
                    <ul>
                    <li>Tezpur</li>
                    <li>Silchar</li>
                    <li>Jorhat</li>
                    <li>Guwahati</li>
                    <li>Dibrugarh</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Arunachal Pradesh
                </td>
                <td >
                    <ul>
                    <li>Naharlagun</li>
                    </ul>
                </td>
              </tr>
              <tr>
                <td className="tabledata-imp">
                Andhra Pradesh
                </td>
                <td >
                    <ul>
                    <li>Vizianagaram</li>
                    <li>Visakhapatnam</li>
                    <li>Vijayawada</li>
                    <li>Tirupati</li>
                    <li>Rajahmundry</li>
                    <li>Nellore</li>
                    <li>Kurnool</li>
                    <li>Kakinada</li>
                    <li>Guntur</li>
                    <li>Eluru</li>
                    <li>Anantapur</li>
                    </ul>
                </td>
              </tr>
            </tbody>
          </table>
          </div>
        </div>
     
        </>
     );
}

export default TestCentre;