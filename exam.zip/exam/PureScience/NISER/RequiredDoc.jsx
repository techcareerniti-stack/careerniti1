import React from "react";
import { useEffect } from "react";
import "./RequiredDoc.css"

function RequiredDoc() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <><div className="Rd-section-Niser ">
        <div className="Rd-content-Niser poppins-regular">
          <h2 className="Niser-title">Required Documents</h2>
          <p>
            
          </p>
        </div>
      </div></>
     );
}

export default RequiredDoc;