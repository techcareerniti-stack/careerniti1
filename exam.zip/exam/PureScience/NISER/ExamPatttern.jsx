import React from "react";
import { useEffect } from "react";
import "./ExamPattern.css"

function ExamPattern() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div><div className="ele-section-Niser ">
        <div className="ele-content-Niser poppins-regular">
          <h2 className="Niser-title">Exam Pattern</h2>
          <div>
           <ol>
            <li>The question paper of the NISER Admission Test has Multiple Choice Questions (MCQ).</li>

            <li>The medium of language in the entrance exam is English.</li>

            <li>There are a total of 60 questions asked in the entrance exam.</li>

            <li>The total time duration of the NISER Aptitude Test is 180 minutes.</li>

            <li>NISER Aptitude Test paper is divided into four sections –- Biology, Chemistry, Mathematics, and Physics with equal weightage.</li>

            <li>In the exam, 3 marks are awarded for every correct answer and -1 is deducted for every incorrect answer.</li>
           </ol>
          </div>
        </div>
      </div></div>
        </>
     );
}

export default ExamPattern;