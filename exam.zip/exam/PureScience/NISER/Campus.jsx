import React from "react";
import { useEffect } from "react";
import "./Campus.css"

function Campus() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (  
        <>
        <div className="cam-section-Niser ">
        <div className="cam-content-Niser poppins-regular">
          <h2 className="Niser-title">Campuses</h2>
          <p>
            
          </p>
        </div>
      </div>
        </>
    );
}

export default Campus;