import React from "react";
import { useEffect } from "react";
import "./Syllabus.css"

function Syllabus() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="Syllabus-section-Niser ">
        <div className="Syllabus-content-Niser poppins-regular">
          <h2 className="Niser-title">Syllabus</h2>
          <ul>
            <li>
              <div>
                IISER syllabus 2023 generally follows the <b>NCERT syllabus</b>  for classes <b>11th and 12th</b> . The IISER syllabus 2023 will help the candidates in becoming familiar with the topics and sub-topics of all four subjects, which have to be prepared for taking the entrance exam. <b>bus</b>

              </div>
            </li>
          </ul>

        </div>
      </div>
    </>
  );
}

export default Syllabus;