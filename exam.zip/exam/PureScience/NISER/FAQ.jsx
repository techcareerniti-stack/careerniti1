import React from "react";
import { useEffect } from "react";
import "./Syllabus.css"

function FAQ() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Fq-section-Niser ">
        <div className="Fq-content-Niser poppins-regular">
          <h2 className="Niser-title">FAQ Section</h2>
        </div>
        </div>
        </>
     );
}

export default FAQ;