import React, { useState } from "react";
import Add_Navbar from "../../Add_Navbar";

import Introduction from "../NISER/Introduction";
import Eligibility from "../NISER/Eligibility";
import AvailableCourse from "../NISER/AvailableCourse";
import ApplicationFee from "../NISER/ApplicationFee";
import ExamPattern from "../NISER/ExamPatttern";
import Campus from "../NISER/Campus";
import Syllbus from "../NISER/Syllabus";
import FAQ from "../NISER/FAQ";
import RequiredDoc from "../NISER/RequiredDoc";
import ImportantDate from "../NISER/ImportantDate";
import TestCentre from "../NISER/TestCentre";

function NISER({ path, setLoc, loc, setSelectedNotify }) {
  const formatLocation = (location) => {
    const parts = location.split("/").filter((part) => part !== "");
    const capitalizedParts = parts.map((part) => {
      if (part.toLowerCase() === "niser") {
        return "NISER";
      } else {
        return part.charAt(0).toUpperCase() + part.slice(1);
      }
    });

    return capitalizedParts.join(" > ");
  };

  return (
    <>
      <Add_Navbar
        introduction={<Introduction />}
        eligibility={<Eligibility />}
        available_courses={<AvailableCourse />}
        campuses={<Campus />}
        application_fees={<ApplicationFee />}
        imp_dates={<ImportantDate />}
        exam_pattern={<ExamPattern />}
        syllabus={<Syllbus />}
        test_centres={<TestCentre />}
        required_documents={<RequiredDoc />}
        faq={<FAQ />}
        setLoc={setLoc}
        setPath={path}
        formatLocation={formatLocation}
        loc={window.location.pathname + loc}
        name="NISER"
        longform="[National Institute of Science Education and Research]"
        setSelectedNotify={setSelectedNotify}
      />
    </>
  );
}

export default NISER;
