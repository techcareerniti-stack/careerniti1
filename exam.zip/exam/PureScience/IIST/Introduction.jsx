import React from "react";
import { useEffect } from "react";
import "./Introduction.css"

function Introduction() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="intro-section-iist">
        <div className="intro-content-iist poppins-regular">
          <h2 className="iist-title">Introduction</h2>
          <ul>
            <li>
              <div>
                <p>Indian Institute of Space Science and Technology (IIST), Asia's first Space University, was established at Thiruvananthapuram in 2007 with the objective of offering high quality education in space science and technology to meet the demands of Indian Space Programme</p>
              </div>
            </li>
          </ul>

        </div>
      </div>
    </>
  );
}

export default Introduction;