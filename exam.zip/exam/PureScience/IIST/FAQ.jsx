import React from "react";
import { useEffect } from "react";
import "./FAQ.css"

function FAQ() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Fq-section-iist ">
        <div className="Fq-content-iist poppins-regular">
          <h2 className="iist-title"> Frequently Asked Questions (FAQs) </h2>

          <ul className="faq-all">
            <li>
              <b>Que 1 :-  How does one clarify doubts regarding the admission procedure?</b>
              <div>
                <b>Ans:-</b>Candidates are requested to read the Information Brochure for IIST UG Admission carefully and send their queries via email to ugadmission@iist.ac.in. Our Admission Team will respond at the earliest.
              </div>
            </li>

            <li>
              <b>Que 2 :- Is admission to IIST through JOSAA?</b>
              <div>
                <b>Ans:-</b>No, admission to IIST is through the IIST Online Admission Portal (http://admission.iist.ac.in) ONLY. Candidates have to register online if they are desirous for admission to IIST.
              </div>
            </li>

            <li>
              <b>Que 3 :- Are there seats reserved under Management Quota? </b>
              <div>
                <b>Ans:-</b>Answer: No, there is no Management Quota in IIST.
              </div>
            </li>

            <li>
              <b>Que 4 :- Can the candidate appear in more than one category in the Rank List? </b>
              <div>
                <b>Ans:-</b>Yes, depending on the candidate’s category, his/her name can appear under one or more categories in the Rank List. 
                </div>
            </li>

            <li>
              <b>Que 5 :- What is the IIST Rank List?</b>
              <div>
                <b>Ans:-</b> IIST will publish category-wise Admission Rank List of eligible candidates who have successfully registered and paid the Registration Fee. Registered candidates will be required to login to the online admission portal to access their respective ranks.
              </div>
            </li>

            <li>
              <b>Que 6 :- Is it mandatory for a parent to be present during the time of joining IIST?</b>
              <div>
                <b>Ans:-</b> Yes, it is mandatory for at least one parent to be present at the time of joining IIST (online through video or in person).
              </div>
            </li>

          </ul>
        </div>
      </div>
        </>
     );
}

export default FAQ;