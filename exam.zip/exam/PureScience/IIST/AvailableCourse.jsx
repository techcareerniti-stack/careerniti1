import React from "react";
import { useEffect } from "react";
import "./AvailableCourse.css"

function AvailableCourse() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return (
        <>
             <div className="iist-avlblCoursesSection">
            <div className="iist-avlblCoursesContent">
                <div>
                    <h2 className="avlbl-head">Available Courses</h2>
                </div>
                <div className="iist-avlblInfo">

                    <ul className="avlbl-list">
                    
                    <li>B.Tech Aerospace Engineering. Offered by: IIST Thiruvananthapuram. </li>
                    <li>B.Tech Avionics. Offered by: IIST Thiruvananthapuram. ...</li>
                    <li>B.Tech Engineering Physics Dual Degree. ...</li>
                    <li>M.Tech Power Electronics. ...</li>
                    <li>M.Tech RF and Microwave Engineering. ...</li>
                    <li>M.Tech Machine Learning and Computing. ...</li>
                    <li>M.Tech Thermal and Propulsion. ...</li>
                    <li>M.Tech Control Systems.</li>
                    <li>M.Tech Material Science and Technology</li>
                    <li>M.Tech VLSI and Microsystems</li>
                    <li>M.Tech Structures and Design</li>
                    <li>M.Tech Digital Signal Processing</li>
                        
                    </ul>
                </div>
            </div>
        </div>
        </>
    );
}

export default AvailableCourse;