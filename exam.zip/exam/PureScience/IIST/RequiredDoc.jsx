import React from "react";
import { useEffect } from "react";
import "./RequiredDoc.css"

function RequiredDoc() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (
        <>
            <div className="Rd-section-iist ">
        <div className="Rd-content-iist poppins-regular">
          <h2 className="iist-title">Required Documents</h2>
          <ol>
            <li>Passport size photograph.</li>
            <li>Degree certificate.</li>
            <li>10th marks sheet.</li>
            <li>10th marks sheet.</li>
            <li>Score card of the entrance examination (GATE/NRF/JRF/JEE Advanced)</li>
            <li>Caste certificate.</li>
          </ol>
        </div>
      </div>
        </>
    );
}

export default RequiredDoc;