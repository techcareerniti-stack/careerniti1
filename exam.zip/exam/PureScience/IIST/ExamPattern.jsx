import React from "react";
import { useEffect } from "react";
import "./ExamPattern.css"

function ExamPattern() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ImpDates-section-iist">
        <div className="ImpDates-content-iiser poppins-regular">
          <h2 className="iiser-title">Exam Pattern </h2>
          <div className="iist-pattern">
            <p>The question paper of IIST 2023 will consist of 120 multiple-choice questions and there will be 3 sections in the IIST 2023 question paper on the subjects of physics, chemistry and mathematics. The exam for IIST 2023 will be conducted in offline mode. The duration of the exam is 2 hours.</p>
          </div>
        </div>
      </div>
    </>
  );
}

export default ExamPattern;