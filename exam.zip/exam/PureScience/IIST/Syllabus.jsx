import React from "react";
import { useEffect } from "react";
import "./Syllabus.css"

function Syllabus() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Syllabus-section-iist ">
        <div className="Syllabus-content-iist poppins-regular">
          <h2 className="iist-title">Syllabus</h2>
          <div className="iist-syllabus">
          <b><p>1.IIST Mathematics Syllabus–</p></b>
          <ol>
            <li>Sets, Relations, and Functions.</li>
            <li>Complex Numbers and Quadratic Equations.</li>
            <li>Matrices and Determinants.</li>
            <li>Permutations and Combinations.</li>
            <li>Mathematical Induction.</li>
            <li>Binomial Theorem.</li>
            <li>Sequences and Series.</li>
            <li>Limit, Continuity, and Differentiability.</li>
            <li>Integral Calculus.</li>
            <li>Differential Equations.</li>
            <li>Coordinate Geometry.</li>
            <li>Three Dimensional Geometry.</li>
            <li>Vector Algebra.</li>
            <li>Statistics and Probability.</li>
            <li>Mathematical Reasoning.</li>
            <li>Physics and Measurement</li>
          </ol>

<b><p>2.IIST Physics Syllabus-</p></b>
<ol>
    <li>Laws of Motion.</li>
    <li>Work, Energy, and Power.</li>
    <li>Rotational Motion.</li>
    <li>Properties of Solids and Liquids.</li>
    <li>Kinetic Theory of Gases.</li>
    <li>Oscillations and Waves.</li>
    <li>Current Electricity.</li>
    <li>Magnetic Effects of Current and Magnetism.</li>
    <li>Electromagnetic Induction and Alternating Currents.</li>
    <li>Electromagnetic Waves.</li>
    <li>Dual Nature of Matter and Radiation.</li>
    <li>Atoms and Nuclei.</li>
    <li>Electronic Devices.</li>
    <li>Communication Systems.</li>
    <li>SECTION-B – Experimental Skills.</li>
</ol>
<b><p>3.IIST Chemistry Syllabus-</p></b>
<ol>
    <li>Some Basic Concepts in Chemistry.</li>
    <li>The States of Matter.</li>
    <li>Atomic Structure.</li>
    <li>Chemical Bonding and Molecular Structure.</li>
    <li>Chemical Thermodynamics.</li>
    <li>Redox Reactions and Electrochemistry.</li>
    <li>Chemical Kinetics.</li>
    <li>Surface Chemistry.</li>
</ol>
<b><p>4.IIST Inorganic Chemistry Syllabus-</p></b>
<ol>
    <li>Classification of Elements and Periodicity in Properties.</li>
    <li>General Principles and Process of Isolation of Metals.</li>
    <li>S – Block Elements (Alkali and Alkaline Earth Metals).</li>
    <li>P – Block Elements (Group 13 to Group 18 Elements).</li>
    <li>d – and f – Block Elements.</li>
    <li>Coordination Compounds.</li>
    <li>Environmental Chemistry.</li>
</ol>

<b><p>5.IIST Organic Chemistry Syllabus -</p></b>
<ol>
    <li>Purification and Characterisation of Organic Compounds.</li>
    <li>Some Basic Principles of Organic Chemistry.</li>
    <li>Organic Compounds Containing Halogens.</li>
    <li>Organic Compounds Containing Oxygen.</li>
    <li>Organic Compounds Containing Nitrogen.</li>
    <li>Bio-Molecules</li>
    <li>Chemistry in Everyday Life.</li>
    <li>Principles Related to Practical Chemistry.</li>
</ol>
</div>
        </div>
      </div>
        </>
     );
}

export default Syllabus;