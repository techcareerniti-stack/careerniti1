import React from "react";
import { useEffect } from "react";
import "./Campus.css"

function Campus() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return ( 
        <>
        <div className="iist-campusSection">
            <div className="iist-campusContent">
                <div>
                    <h2 className="campus-head">Campus</h2>
                </div>
                <div className="iist-campusInfo">
                    
                </div>
            </div>
        </div>
        </>
     );
}

export default Campus;