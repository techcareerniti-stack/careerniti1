import React from "react";
import { useEffect } from "react";
import "./Eligibility.css"

function Eligibility() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="ele-section-iist ">
        <div className="ele-content-iist poppins-regular">
          <h2 className="iist-title">Eligibility</h2>
          <ol>
            <li>Citizenship: Only Indian citizens are eligible to apply for admission in IIST. </li>
            <li>Date of Birth: Candidates belonging to General, EWS and OBC-NCL categories must have been born on or after October 1, 1995. </li>
            <li>Candidates belonging to SC/ ST and PD categories must have born on or after October 1, 1990.</li>
          </ol>
        </div>
      </div>
    </>
  );
}

export default Eligibility;