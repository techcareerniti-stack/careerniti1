import React from "react";
import { useEffect} from "react";
import "./TestCenter.css"

function TestCentre() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return ( 
        <>
        <div className="Tc-section-iist ">
        <div className="Tc-content-iist poppins-regular">
          <h2 className="iist-title"> Test Centres </h2>
          <table className="iist-tbl">
            <tr>
                <td>Ahmedabad</td>
                <td>Dehradun</td>
                <td>Mumbai</td>
            </tr>
            <tr>
                <td>Bangalore</td>
                <td>Delhi</td>
                <td>Nagpur</td>
            </tr>
            <tr>
                <td>Bhubaneswar</td>
                <td>Dispur</td>
                <td>Patna</td>
            </tr>
            <tr>
                <td>Bhopal</td>
                <td>Hydrabad</td>
                <td>Port Blair</td>
            </tr>
            <tr>
                <td>Calicut</td>
                <td>Jaipur</td>
                <td>Ranchi</td>
            </tr>
            <tr>
                <td>Chandigarh</td>
                <td>Kolkata</td>
                <td>Thiruvanthapuram</td>
            </tr>
            <tr>
                <td>Chennai</td>
                <td>Lucknow</td>
                <td>Varanasi</td>
            </tr>
            <tr>
                <td>Vishakapatnam</td>
                <td></td>
                <td></td>
            </tr>
          </table>
        </div>
      </div>
        </>
     );
}

export default TestCentre;