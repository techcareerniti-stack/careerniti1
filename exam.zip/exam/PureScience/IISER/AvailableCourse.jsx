import React from "react";
import { useEffect } from "react";
import "./AvailableCourse.css"

function available_Courses() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return (
        <>
        <div className="iiser-avlblCoursesSection">
            <div className="iiser-avlblCoursesContent">
                <div>
                    <h2 className="avlbl-head">Available Courses</h2>
                </div>
                <div className="iiser-avlblInfo">
                    <b><p>BS</p></b>
                    <b><p>BS-MS(Dual Degree)</p></b>

                    <p>About the BS and BS-MS (Dual Degree) Programs  5-Year (Dual Degree) program for science students and 4-Year BS Degree program for Engineering Sciences and Economic Sciences (offered only at IISER Bhopal).  Classroom learning integrated with research, providing ample scope for interdisciplinary activities.  Curriculum with a focus on both breadth and depth in the natural sciences, engineering sciences and economic sciences.  Opportunity to pursue impactful research.  Fully residential campuses with well-equipped hostels.  Access to on-campus medical facilities along with sports and other recreational facilities.</p>
                    
                    <ul className="avlbl-list">
                    
                    <p>Programs Offered</p>
                    
                    <li>Biological Sciences</li>
                    <li>Chemical Sciences</li>
                    <li>Earth & Climate Sciences/Earth & Environmental Sciences</li>
                    <li>Economic Sciences</li>
                    <li>Engineering Sciences (Chemical Engineering, Data Science & Engineering, Electrical Engineering & Computer Science)</li>
                    <li>Geological Sciences</li>
                    <li>Integrated & Interdisciplinary Sciences (Biological Sciences, Chemical Sciences, Data Sciences, Mathematical Sciences, Physical Sciences)</li>
                    <li>Mathematical Sciences</li>
                    <li>Physical Sciences</li>
                        
                    </ul>
                    <p>Note: Four-year BS program in Engineering Sciences and Economics Sciences is offered only by IISER Bhopal</p>
                </div>
            </div>
        </div>
        </>
      );
}

export default available_Courses;