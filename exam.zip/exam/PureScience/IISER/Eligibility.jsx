import React from "react";
import { useEffect } from "react";
import "./Eligibility.css"

function Eligibility() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ele-section-iiser ">
        <div className="ele-content-iiser poppins-regular">
          <h2 className="iiser-title">Eligibility</h2>
          <ol>
            <li>Applicants must be Indian nationals or PIO or OCI in order to apply through KVPY or JEE Advanced) or IAT channels. Candidates who are NOT Indian nationals or PIO or OCI can apply for admission only through the JEE (Advanced) channel.</li>
            <li>Candidates must have passed Class XII (or equivalent) exam with science stream in 2023 or 2024 from any board recognized by Council of Boards of School Education in India</li>
            <li>Candidates must have taken at least three subjects among Biology, Chemistry, Mathematics and Physics during their Class XII (or equivalent) exam.</li>
            <li>Candidates belonging to SC/ST/PwD should have scored a minimum of 55% marks in aggregate or equivalent grade in their Class XII (or equivalent) exam. Candidates belonging to other categories should have scored a minimum of 60% marks in aggregate or equivalent grade in their Class XII (or equivalent) exam.</li>
          </ol>
        </div>
      </div>
        </>
     );
}

export default Eligibility;