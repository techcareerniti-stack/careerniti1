import React from "react";
import { useEffect } from "react";
import "./Campus.css"

function Campus() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return ( 
        <>
        <div className="iiser-campusSection">
            <div className="iiser-campusContent">
                <div>
                    <h2 className="campus-head">Campus</h2>
                </div>
                <div className="iiser-campusInfo">
                        <b>The Government of India has established the IISERs at :-</b>
                        <ol>
                            <li>Berhampur</li>
                            <li>Bhopal</li>
                            <li>Kolkata</li>
                            <li>Mohali</li>
                            <li>Pune</li>
                            <li> Thiruvananthapuram</li>
                            <li> Tirupat</li>
                        </ol>
                </div>
            </div>
        </div>
        </>
     );
}

export default Campus;