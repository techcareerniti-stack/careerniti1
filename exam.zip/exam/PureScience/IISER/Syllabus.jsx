import React from "react";
import { useEffect } from "react";
import "./Syllabus.css"

function Syllabus() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Syllabus-section-iiser ">
        <div className="Syllabus-content-iiser poppins-regular">
          <h2 className="iiser-title">Syllabus</h2>
          <b><p>1.Biology –</p></b>
          <ul>
            <li>Diversity in the living world.</li>
            <li>Structural organisation in animals and plants.</li>
            <li>Cell structure and function. </li>
            <li>Plant and Animal physiology.</li>
            <li>Human physiology.</li>
            <li>Reproduction</li>
            <li>Genetics and Evolution</li>
            <li>Biology and human welfare </li>
            <li>Biotechnology and its applications </li>
            <li>Ecology and environment</li>
          </ul>
<b><p>2.Chemistry-</p></b>
<ul>
  <li>Structure of the Atom </li>
  <li>Classification of Elements and Periodicity in Properties </li>
  <li>Chemical Bonding and Molecular Structure</li>
  <li>States of Matter</li>
  <li> Thermodynamics </li>
  <li> Equilibrium </li>
  <li> Redox Reactions </li>
  <li>Hydrogen </li>
  <li>The s-block Elements</li>
  <li>The p-block Elements</li>
  <li>Organic Chemistry – Some Basic Principles and Techniques </li>
  <li>Hydrocarbons </li>
  <li>Environmental Chemistry </li>
  <li>The solid state</li>
  <li>Solutions </li>
  <li>Electrochemistry </li>
  <li> Chemical Kinetics </li>
  <li> Surface chemistry</li>
  <li> General principles and processes of isolation of elements </li>
  <li> The d- & f- block elements</li>
  <li>  Coordination Compounds </li>
  <li>Haloalkanes and haloarenes </li>
  <li>Alcohols, phenols and ethers</li>
  <li>Aldehydes, ketones and carboxylic acids </li>
  <li>Organic compounds containing nitrogens </li>
  <li>Biomolecules</li>
  <li>Polymers </li>
  <li>Chemistry in everyday life</li>
</ul>

<b><p>3.Mathematics -</p></b>
<ul>
  <li>Sets</li>
  <li>Relations and Functions </li>
  <li>Trigonometric Functions</li>
  <li>Inverse Trigonometric Functions </li>
  <li>Principles of Mathematical Induction </li>
  <li>Complex Numbers and Quadratic Equations</li>
  <li>Linear Inequalities </li>
  <li>Permutations and Combinations</li>
  <li>Binomial Theorem</li>
  <li>Sequences and Series </li>
  <li>Straight lines</li>
  <li>Conic Sections </li>
  <li>Three Dimensional Geometry</li>
  <li>Limits and Derivatives</li>
  <li>Mathematical Reasoning</li>
  <li>Statistics</li>
  <li>Probability</li>
  <li>Matrices</li>
  <li>Determinants</li>
  <li>Continuity and Differentiability </li>
  <li>Application of Derivatives </li>
  <li>Integrals</li>
  <li>Applications of Integrals</li>
  <li>Differential Equations</li>
  <li>Vectors</li>
  <li>Linear Programming</li>
</ul>

<b><p>4.Physics -</p></b>
<ul>
  <li>Physical World and Measurement </li>
  <li>Kinematics</li>
  <li>Laws of Motion</li>
  <li>Work, Energy and Power</li>
  <li>Motion of Systems of Particles and Rigid body</li>
  <li>Gravitation</li>
  <li>Properties of bulk matter</li>
  <li>Thermodynamics</li>
  <li>Behavior of perfect gas and kinetic energy</li>
  <li>Oscillations</li>
  <li>Waves</li>
  <li>Electrostatics</li>
  <li>Current Electricity</li>
  <li>Magnetic effect of current and magnetism</li>
  <li>Electromagnetic Induction </li>
  <li>Alternating current</li>
  <li>Electromagnetic Waves</li>
  <li>Optics</li>
  <li>Dual Nature of Radiation and Matter</li>
  <li>Atoms</li>
  <li>Nuclei</li>
  <li>Electronic devices</li>
  <li>Communication Systems</li>
</ul>
        </div>
      </div>
        </>
     );
}

export default Syllabus;