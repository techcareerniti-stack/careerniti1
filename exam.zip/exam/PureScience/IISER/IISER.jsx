import React, { useState } from "react";
import Add_Navbar from "../../Add_Navbar";
import Introduction from "../IISER/Introduction";
import Eligibility from "../IISER/Eligibility";
import AvailableCourse from "../IISER/AvailableCourse";
import Campus from "./Campus";
import Application_Fee from "../IISER/Application_Fee";
import ExamPattern from "../IISER/ExamPattern";
import FAQ from "../IISER/FAQ";
import ImportantDate from "../IISER/ImportantDate";
import RequiredDoc from "../IISER/RequiredDoc";
import Syllabus from "../IISER/Syllabus";
import TestCentre from "../IISER/TestCentre"





function IISER({ path, setLoc, loc, setSelectedNotify }) {
  const formatLocation = (location) => {
    const parts = location.split("/").filter((part) => part !== "");
    const capitalizedParts = parts.map((part) => {
      if (part.toLowerCase() === "iiser") {
        return "IISER";
      } else {
        return part.charAt(0).toUpperCase() + part.slice(1);
      }
    });

    return capitalizedParts.join(" > ");
  };


    return (
        <>
            <Add_Navbar

                introduction={<Introduction />}
                eligibility={<Eligibility />}
                available_courses={<AvailableCourse />}
                campuses={<Campus />}
                application_fees={<Application_Fee />}
                imp_dates={<ImportantDate />}
                exam_pattern={<ExamPattern />}
                syllabus={<Syllabus />}
                test_centres={<TestCentre />}
                required_documents={<RequiredDoc />}
                faq={<FAQ />}


                setLoc={setLoc}
                setPath={path}
                formatLocation={formatLocation}
                loc={window.location.pathname +loc}
                name="IISER"
                longform="[Indian Institutes of Science Education and Research]"
                setSelectedNotify={setSelectedNotify}


            />




        </>
    );
}

export default IISER;
