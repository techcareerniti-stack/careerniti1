import React from "react";
import { useEffect } from "react";
import "./ExamPattern.css"

function ExamPattern() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ImpDates-section-iiser ">
        <div className="ImpDates-content-iiser poppins-regular">
          <h2 className="iiser-title">Exam Pattern </h2>

          <table className=" iiser-ImpDate-Table">
            <thead>
              <td className="tablehead-imp">Particulars</td>
              <td className="tablehead-imp">Details</td>
            </thead>
            <tbody>
              <tr>
                <td>Mode of Exam</td>
                <td >Online (Computer-based examination) </td>
              </tr>
              <tr>
                <td>
                Type of Questions
                </td>
                <td >Multiple-choice questions</td>
              </tr>
              <tr>
                <td>
                Time Duration of Exam
                </td>
                <td >3 hours</td>
              </tr>
              <tr>
                <td>Number of Questions</td>
                <td >60 Questions</td>
              </tr>
              <tr>
                <td>Sections</td>
                <td >
                    <ul >
                    There are 4 sections-
                    <li>Physics- 15 Questions</li>
                    <li>Chemistry -15 Questions</li>
                    <li>Mathematics -15 Questions</li>
                    <li>Biology- 15 Questions</li>
                    </ul>
                 </td>
              </tr>
              <tr>
                <td>
                Total Marks 
                </td>
                <td >
                180 Marks 
                </td>
              </tr>
              <tr>
                <td>Marking Scheme</td>
                <td >
                    <ul>
                        <li>Candidates will be allotted 3 marks for each correct answer.</li>
                        <li>There will be a deduction of 0.75 mark for each incorrect answer.</li>
                    </ul>
                </td>
              </tr>
              
            
            </tbody>
          </table>
        </div>
      </div>
        </>
     );
}

export default ExamPattern;