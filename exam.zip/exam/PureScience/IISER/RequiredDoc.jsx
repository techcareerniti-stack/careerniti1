import React from "react";
import { useEffect } from "react";
import "./RequiredDocument.css"

function RequiredDoc() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (
        <>
        <div className="Rd-section-iiser ">
        <div className="Rd-content-iiser poppins-regular">
          <h2 className="iiser-title">Required Documents</h2>
          <ol>
            <li>Class X certificate</li>
            <li>Class XII (or equivalent examination).</li>
          </ol>
          <div className="doc">
          <table className="iiser-ImpDate-Table">
            <thead>
              <td className="tablehead-imp">Type of Document</td>
              <td className="tablehead-imp">File Size</td>
            </thead>
            <tbody>
              <tr>
                <td>Photograph</td>
                <td >Upto 200 KB</td>
              </tr>
              <tr>
                <td>
                Signature
                </td>
                <td >Upto 200 KB</td>
              </tr>
              <tr>
                <td>
                Photo ID
                </td>
                <td >200KB- Upto 1 MB</td>
              </tr>
              <tr>
                <td>Caste Certificate</td>
                <td >200KB- Upto 1 MB</td>
              </tr>
              <tr>
                <td>10th Marksheet</td>
                <td >
                200KB- Upto 1 MB</td>
              </tr>
              <tr>
                <td>
                12th Marksheet
                </td>
                <td >
                200KB- Upto 1 MB
                </td>
              </tr>
              <tr>
                <td>PwD Certificate</td>
                <td >200KB- Upto 1 MB</td>
              </tr>
              <tr>
                <td>
                Kashmiri Migrant Certificate
                </td>
                <td >
                200KB- Upto 1 MB
                </td>
              </tr>

              <tr>
                <td>
                OCI/PIO/Foreign National Citizenship supporting document
                </td>
                <td >
                200KB- Upto 1 MB
                </td>
              </tr>
            
            </tbody>
          </table>
          </div>
        </div>
      </div>
        </>
      );
}

export default RequiredDoc;