import React from "react";
import { useEffect } from "react";
import "./Introduction.css"

function Introduction() {
    return ( 
        <>
        <div className="intro-section-iiser">
        <div className="intro-content-iiser poppins-regular">
          <h2 className="iiser-title">Introduction</h2>
          <ul>
            <li>
              <div>
              <p>Indian Institutes of Science Education and Research (IISERs) was established by the Government of India at Berhampur, Bhopal, Kolkata, Mohali, Pune, Thiruvananthapuram, and Tirupati to integrate and promote interdisciplinary science education and research. Over the years, the IISERs have been successfully attracting talented young minds. An overarching goal of the IISERs is to enable students to shape the nation by inventing and implementing sustainable solutions for societal problems through research in science. This is being achieved by our faculty of international repute together with bright students. In a short span of time, the IISERs have generated an incredible amount of intellectual property in the form of publications and patents. Additionally, the graduating students from the different programs have been successfully placed and the alumni of IISERs have carved a niche in the global academic/non-academic platforms.</p>
            </div>
            </li>
          </ul>

        </div>
      </div>
        </>
     );
}
export default Introduction;
