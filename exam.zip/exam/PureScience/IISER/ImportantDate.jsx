import React from "react";
import { useEffect } from "react";
import "./ImportantDate.css"

function ImportantDate() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ImpDates-section-iiser ">
        <div className="ImpDates-content-iiser poppins-regular">
          <h2 className="iiser-title">Important Dates </h2>

          <table className=" iiser-ImpDate-Table">
            <thead>
              <td className="tablehead-imp">Title</td>
              <td className="tablehead-imp">Dates</td>
            </thead>
            <tbody>
              <tr>
                <td>Application Start Date</td>
                <td >April 1, 2024 </td>
              </tr>
              <tr>
                <td>
                Application From Last Date
                </td>
                <td >May 13, 2024 </td>
              </tr>
              <tr>
                <td>
                Corrections in application form
                </td>
                <td >May 16-17, 2024 </td>
              </tr>
              <tr>
                <td>Admit Card Release Date</td>
                <td >June 1, 2024 </td>
              </tr>
              <tr>
                <td>IAT Result Date</td>
                <td >
                June 25, 2024 </td>
              </tr>
              <tr>
                <td>
                Registration for counselling process 
                </td>
                <td >
                June 26-July 1, 2024 
                </td>
              </tr>
              <tr>
                <td>Document verification </td>
                <td >July 2-5, 2024 </td>
              </tr>
              <tr>
                <td>
                First round of admission offers
                </td>
                <td >
                July 7, 2024
                </td>
              </tr>
            
            </tbody>
          </table>
        </div>
      </div>
        </>
     );
}

export default ImportantDate;