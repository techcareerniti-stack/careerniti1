import React from "react";
import { useEffect } from "react";
import "./Application_fee.css"

function Application_Fee() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
       <div className="fee-section-iiser ">
        <div className="fee-content-iiser poppins-regular">
          <h2 className="iiser-title">Application Fees</h2>
          <table className="iiser-fee-Table">
            <thead>
              <td className="tablehead">Category of Candidate</td>
              <td className="tablehead">Fees</td>
            </thead>
            <tbody>         
              <tr>
                <td>General, EWS and OBC-NCL</td>
                <td className="right-con">2000/-</td>
              </tr>
              <tr>
                <td>persons with disabilities, Kashmiri migrants and SC/ST category</td>
                <td className="right-con">1000/-</td>
              </tr>
              <tr>
                <td>foreign nationals</td>
                <td className="right-con">8500/-</td>
              </tr>
            </tbody>
          </table>
          <p>Application fee is non-refundable</p>
        </div>
        
      </div>
      <div className="iiser-seat">
      <b><p>- Seat Acceptance Fee (SAF) - </p></b>
      <p>The Seat Acceptance Fee is to be paid only after an offer of admission has been made to the candidate. The SAF will have to be paid as per the category entered by the candidate in the application</p>
      </div>
      <table className="iiser-fee-Table">
            <thead>
              <td className="tablehead">Category of Candidate</td>
              <td className="tablehead">Fees</td>
            </thead>
            <tbody>         
              <tr>
                <td>General, EWS and OBC-NCL</td>
                <td className="right-con">2000/-</td>
              </tr>
              <tr>
                <td>persons with disabilities, Kashmiri migrants and SC/ST category</td>
                <td className="right-con">1000/-</td>
              </tr>
              <tr>
                <td>foreign nationals</td>
                <td className="right-con">8500/-</td>
              </tr>
            </tbody>
          </table><br />
          <div className="note">
            <b><p>Note-</p></b>
            <ol>
              <li>Failure to deposit the SAF within the stipulated time will result in the cancellation of the offer. Furthermore, you will not be considered in any subsequent rounds of seat allotment during admission 2024.  </li>
              <li>Once you register in your allotted IISER, this amount will be adjusted against your first semester fee.</li>
            </ol>
          </div>
        </>
     );
}

export default Application_Fee;