import React from "react";
import { useEffect } from "react";
import "./TestCenter.css"

function TestCentre() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (  
        <>
        <div className="Tc-section-iiser ">
        <div className="Tc-content-iiser poppins-regular">
          <h2 className="iiser-title"> Test Centres </h2>
        
          <div>
           <p>IISERs Aptitude Test will be conducted at different locations across the country. During the online application process, candidates will have to indicate several cities as choices for appearing in IAT.</p>
          </div>
        </div>
      </div>
        </>
    );
}

export default TestCentre;