import React from "react";
import { useEffect } from "react";
 import "./Eligibility.css"

function Eligibility() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ele-section-iisc ">
        <div className="ele-content-iisc poppins-regular">
          <h2 className="iisc-title">Eligibility</h2>
          <ol>
            <li>Candidates in General and OBC category should be born on or after August 1, 2002. The age limit is relaxed by 5 years for SC/ ST/ Divyangjan candidates.</li>
            <li>Class XII qualifying examination should be passed in either 2020 or 2021. Candidates appearing in 2022 are also eligible. (Where only Letter Grade is given by the Board, a certificate from the Board specifying equivalent percentage marks will be required. In the absence of such a certificate the decision of the respective Admission Committees will be final.)</li>
            <li>At least 60% marks in aggregate (or equivalent grade) in Class XII (or equivalent) examination from any recognized Board in India. For Scheduled Caste (SC), Scheduled Tribes (ST) candidates and for Divyangjan candidates, the minimum requirement is 55%.</li>
          </ol>
        </div>
      </div>
        </>
     );
}

export default Eligibility;