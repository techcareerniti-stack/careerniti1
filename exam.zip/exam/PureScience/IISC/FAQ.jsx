import React from "react";
import { useEffect } from "react";
import "./FAQ.css"

function FAQ() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="Fq-section-iisc ">
        <div className="Fq-content-iisc poppins-regular">
          <h2 className="iisc-title"> Frequently Asked Questions (FAQs) </h2>

          <ul className="faq-all">
            <li>
              <b>Que 1 :- My class XII resulsts are still awaited . Can i apply ?</b>
              <div>
                <b>Ans:-</b>Yes. You will have produce the result of the examination when the portal opens to upload documents and freeze IISER preferences. Failing this, you will not be considered for counselling.
              </div>
            </li>

            <li>
              <b>Que 2 :- I'm a class 12th student of an international board in india. can i apply ?</b>
              <div>
                <b>Ans:-</b>Yes, you can.
              </div>
            </li>

            <li>
              <b>Que 3 :- Do i need to apply separately for a different IISERS ? </b>
              <div>
                <b>Ans:-</b>No. All IISERs admit students through a common application process. One application form is valid for all the IISERs.
              </div>
            </li>

            <li>
              <b>Que 4 :- What are the major courses offered by each IISERS. </b>
              <div>
                <b>Ans:-</b>
                <ul className="Q4">
                    <li>Biological Sciences</li>
                    <li>Chemical Sciences</li>
                    <li>Earth & Climate Sciences/Earth & Environmental Sciences</li>
                    <li>Economic Sciences</li>
                    <li>Engineering Sciences (Chemical Engineering, Data Science & Engineering, Electrical Engineering & Computer Science)</li>
                    <li>Geological Sciences</li>
                    <li>Integrated & Interdisciplinary Sciences (Biological Sciences, Chemical Sciences, Data Sciences, Mathematical Sciences, Physical Sciences)</li>
                    <li>Mathematical Sciences</li>
                    <li>Physical Sciences</li>
                </ul>
                <p><b>Note -</b> Four-year BS program in Engineering Sciences and Economics Sciences is offered only by IISER Bhopal</p>
              </div>
            </li>

            <li>
              <b>Que 5 :- What are the channels available for admission to IISERs ?</b>
              <div>
                <b>Ans:-</b>There are three channels available for admission into IISERs:- (i). KVPY (Kishore Vaigyanik Protsahan Yojana), (ii). JEE (Advanced), and (iii) IAT (IISER Aptitude Test).
              </div>
            </li>

            <li>
              <b>Que 6 :- Can i apply through more than one channels ?</b>
              <div>
                <b>Ans:-</b>Yes.
              </div>
            </li>

            <li>
              <b>Que :- 7 What is the required percentage / cut off marks in 12th or equivalent for getting asdmision to IISERs ? </b>
              <div>
                <b>Ans:-</b>The required percentage is 60% marks in aggregate or equivalent grade for GEN/OBC/OBC-NCL and 55% marks in aggregate or equivalent grade for SC/ST/PWD in class XII or equivalent exam.
              </div>
            </li>

            <li>
              <b>Que :- 8 What is the mode of IISERs aptitude test ? </b>
              <div>
                <b>Ans:-</b>The IISER Aptitude Test 2024 will be conducted in the computer-based test mode. The mock test is available on the website .
              </div>
            </li>

            <li>
              <b>Que 9 :- Can i transfer my admission from one IISERs to another at any time ?</b>
              <div>
                <b>Ans:-</b>No. Inter-lISER transfer of students is NOT permitted.
              </div>
            </li>

            <li>
              <b>Que :- 10 How do i check my SAF payment has been successful ? </b>
              <div>
                <b>Ans:-</b>Once you have paid the SAF, download your updated oﬀer letter again from the counselling portal. Your SAF payment details will appear on the last page of the updated oﬀer letter.
              </div>
            </li>
          </ul>
        </div>
      </div>
        </>
     );
}

export default FAQ;