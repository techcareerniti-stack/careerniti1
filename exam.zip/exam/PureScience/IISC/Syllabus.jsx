import React from "react";
import { useEffect } from "react";
import "./Syllabus.css"

function Syllabus() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <div className="Syllabus-section-iisc ">
        <div className="Syllabus-content-iisc poppins-regular">
          <h2 className="iisc-title">Syllabus</h2>

        </div>
      </div>
     );
}

export default Syllabus;