import React from "react";
import { useEffect } from "react";
import "./ExamPattern.css"

function ExamPattern() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return (  
        <>
        <div className="iisc-exampatternSection">
            <div className="iisc-exampatternContent">
                <div>
                    <h2 className="pattern-head">Exam Pattern</h2>
                </div>
                <div className="iisc-patternInfo">
                    <ul className="pattern-list">
                    
                    <li>The question paper of the IISER Admission Test has Multiple Choice Questions (MCQ).</li>
                    <li>The medium of language in the entrance exam is English.</li>
                    <li>There are a total of 60 questions asked in the entrance exam.</li>
                    <li>The total time duration of the IISER Aptitude Test is 180 minutes.</li>
                    <li>IISER Aptitude Test paper is divided into four sections –- Biology, Chemistry, Mathematics, and Physics with equal weightage.</li>
                    <li>In the exam, 3 marks are awarded for every correct answer and -1 is deducted for every incorrect answer.</li>

                    </ul>
                </div>
            </div>
        </div>
        </>
    );
}

export default ExamPattern;