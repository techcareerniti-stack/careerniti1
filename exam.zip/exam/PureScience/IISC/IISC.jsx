import React, { useState } from "react";
import Add_Navbar from "../../Add_Navbar";

import Introduction from "../IISC/Introduction";
import Eligibility from "../IISC/Eligibility";
import AvailableCourse from "../IISC/AvailableCourse";
import Campus from "../IISC/Campus";
import ApplicationFee from "../IISC/ApplicationFee";
import ImportantDate from "../IISC/ImportantDate";
import ExamPattern from "../IISC/ExamPattern";
import Syllabus from "../IISC/Syllabus";
import TestCentre from "../IISC/TestCentre";
import RequiredDoc from "../IISC/RequiredDoc";
import FAQ from "../IISC/FAQ";

function IISC({ path, setLoc, loc, setSelectedNotify }) {
    const formatLocation = (location) => {
        const parts = location.split("/").filter((part) => part !== "");
        const capitalizedParts = parts.map((part) => {
            if (part.toLowerCase() === "iisc") {
                return "IISC";
            } else {
                return part.charAt(0).toUpperCase() + part.slice(1);
            }
        });

        return capitalizedParts.join(" > ");
    };

    return (
        <>
            <Add_Navbar

                introduction={<Introduction />}
                eligibility={<Eligibility />}
                available_courses={<AvailableCourse />}
                campuses={<Campus />}
                application_fees={<ApplicationFee />}
                imp_dates={<ImportantDate />}
                exam_pattern={<ExamPattern />}
                syllabus={<Syllabus />}
                test_centres={<TestCentre />}
                required_documents={<RequiredDoc />}
                faq={<FAQ />}
                setLoc={setLoc}
                setPath={path}
                formatLocation={formatLocation}
                loc={window.location.pathname +loc}
                name="IISc"
                longform="[Indian Institute of Science]"
                setSelectedNotify={setSelectedNotify}


            />
        </>
    );
}

export default IISC;