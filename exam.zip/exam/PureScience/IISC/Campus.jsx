import React from "react";
import { useEffect } from "react";
import "./Campus.css"

function Campus() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return ( 
        <>
        <div className="iisc-campusSection">
            <div className="iisc-campusContent">
                <div>
                    <h2 className="campus-head">Campus</h2>
                </div>
            </div>
        </div>
        </>
     );
}

export default Campus;