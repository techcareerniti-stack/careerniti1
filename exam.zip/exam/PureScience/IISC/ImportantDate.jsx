import React from "react";
import { useEffect } from "react";
import "./ImportantDate.css"

function ImportantDate() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return ( 
        <>
        <div className="ImpDates-section-iisc ">
        <div className="ImpDates-content-iisc poppins-regular">
          <h2 className="iiser-title">Important Dates </h2>

          <table className=" iisc-ImpDate-Table">
            <thead>
              <td className="tablehead-imp">Title</td>
              <td className="tablehead-imp">Dates</td>
            </thead>
            <tbody>
              <tr>
                <td>Application Start Date</td>
                <td >March 30, 2024</td>
              </tr>
              <tr>
                <td>
                Closing of Online application
                </td>
                <td >May 31, 2024  </td>
              </tr>
              <tr>
                <td>
                Admit Card Release Date
                </td>
                <td >June 15, 2024</td>
              </tr>
              <tr>
                <td>Date of Examination</td>
                <td >June 30, 2024</td>
              </tr>
              <tr>
                <td>Result Date</td>
                <td >July 10, 2024</td>
              </tr>
              
            
            </tbody>
          </table>
        </div>
      </div>
        </>
     );
}

export default ImportantDate;