import React from "react";
import { useEffect } from "react";
import "./introduction.css"

function Introduction() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <div className="intro-section-iisc ">
        <div className="intro-content-iisc poppins-regular">
          <h2 className="iisc-title">Introduction</h2>
          <ul>
            <li>
              <div>

              </div>
            </li>
          </ul>

        </div>
      </div>
    </>
  );
}

export default Introduction;