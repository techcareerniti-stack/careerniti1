import React from "react";
import { useEffect } from "react";
import "./ApplicationFee.css"

function ApplicationFee() {
  useEffect(() => {
    window.scrollTo(0, 0);
}, []);
    return (
        <>
            <div className="fee-section-iisc ">
        <div className="fee-content-iisc poppins-regular">
          <h2 className="iiser-title">Application Fees</h2>
          <table className="iisc-fee-Table">
            <thead>
              <td className="tablehead">Category of Candidate</td>
              <td className="tablehead">Fees</td>
            </thead>
            <tbody>         
              <tr>
                <td>General and OBC categories</td>
                <td className="right-con">1200/-</td>
              </tr>
              <tr>
                <td>SC/ ST/ PWD/ categories</td>
                <td className="right-con">600/-</td>
              </tr>
            </tbody>
          </table>
        </div>
        
      </div>

        </>
    );
}

export default ApplicationFee;