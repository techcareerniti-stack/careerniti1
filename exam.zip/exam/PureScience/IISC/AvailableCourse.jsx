import React from "react";
import { useEffect } from "react";
import "./AvailableCourse.css"

function AvailableCourse() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return (
        <>
            <div className="iisc-avlblCoursesSection">
            <div className="iisc-avlblCoursesContent">
                <div>
                    <h2 className="avlbl-head">Available Courses</h2>
                </div>
                <div className="iisc-avlblInfo">
                    <ul className="avlbl-list">
                    
                    <li>Integrated 5-year M.Sc. Programme.</li>
                    <li>Integrated M.Sc. + Ph. D Programme.</li>
                    <li>Ph. D. Program.</li>

                    </ul>
                </div>
            </div>
        </div>
        </>
    );
}

export default AvailableCourse;