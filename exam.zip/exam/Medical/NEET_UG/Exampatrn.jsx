import { useEffect } from "react";
import "../NEET_UG/Exampatrn.css";

function Exampatrn() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="neet-exampatrnSection">
            <div className="neet-exampatrnContent poppins-regular">
                <div>
                    <h2 className="exam-head">Exam Pattern</h2>
                </div>
                <div className="exampatrn-info">
                    <ul className="exampatrn-list">
                        <li><b>Test pattern of NEET (UG)</b></li>
                        The Test pattern of NEET (UG) - 2024 comprises four Subjects. Each subject will consist of two sections. Section A will consist of 35 Questions and Section B will have 15 Questions, out of these 15 Questions, candidates can choose to attempt any 10 Questions. So, the total number of questions and utilization of time will remain the same. <br />
                        The pattern for the NEET (UG) Examination for admission in the Session is as follows:

                        <table className="neet-examptTbl">
                            <thead>
                                <td className="table-heading">Sr.No.</td>
                                <td className="table-heading">Subject(s)</td>
                                <td className="table-heading"> Section(s)</td>
                                <td className="table-heading">Number Of Questions</td>
                                <td className="table-heading">Marks <br />(Each Question carries 04 (Four) Marks)</td>
                                <td className="table-heading"> Type Of Question(s)</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td rowSpan={2}>1</td>
                                    <td rowSpan={2}>PHYSICS</td>
                                    <td>SECTION A</td>
                                    <td className="numerical-data">35</td>
                                    <td className="numerical-data">140</td>
                                    <td rowSpan={8}> MCQ <br />(Multiple Choice Questions)</td>
                                </tr>
                                <tr>
                                    <td>SECTION B</td>
                                    <td className="numerical-data">15</td>
                                    <td className="numerical-data">140</td>
                                </tr>
                                <tr>
                                    <td rowSpan={2}>2</td>
                                    <td rowSpan={2}>CHEMISTRY</td>
                                    <td>SECTION A</td>
                                    <td className="numerical-data">35</td>
                                    <td className="numerical-data">140</td>
                                </tr>
                                <tr>
                                    <td>SECTION B</td>
                                    <td className="numerical-data">15</td>
                                    <td className="numerical-data">140</td>
                                </tr>
                                <tr>
                                    <td rowSpan={2}>3</td>
                                    <td rowSpan={2}>BOTANY</td>
                                    <td>SECTION A</td>
                                    <td className="numerical-data">35</td>
                                    <td className="numerical-data">140</td>
                                </tr>
                                <tr>
                                    <td>SECTION B</td>
                                    <td className="numerical-data">15</td>
                                    <td className="numerical-data">40</td>
                                </tr>
                                <tr>
                                    <td rowSpan={2}>4</td>
                                    <td rowSpan={2}>ZOOLOGY</td>
                                    <td>SECTION A</td>
                                    <td className="numerical-data">35</td>
                                    <td className="numerical-data">140</td>
                                </tr>
                                <tr>
                                    <td>SECTION B</td>
                                    <td className="numerical-data">15</td>
                                    <td className="numerical-data">40</td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td colSpan={2}>TOTAL MARKS</td>
                                    <td className="numerical-data">720</td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                        <div>
                            Note: Correct option marks will be given (4) marks and Incorrect option marked will be given minus one (-1) mark. Unattempted/Unanswered Questions will begiven no marks.
                        </div>
                        <br />

                        <li><b>Important Points to Note:-</b></li>
                        <ul className="exampatrn-nestedlist">
                            <li><b>For Section A (MCQs):-</b></li>
                            To answer a question, the candidates need to choose one option corresponding to the correct answer or the most appropriate answer. However, if any anomaly or discrepancy is found after the process of challenges of the key verification, it shall be addressed in the following manner:
                            <ol>
                                <li>Correct answer or the most appropriate answer: Four marks (+4)</li>
                                <li> Any incorrect option marked will be given minus one mark (-1).</li>
                                <li> Unanswered: No mark (0).</li>
                                <li>If more than one option is found to be correct then Four marks (+4) will be awarded to only those who have marked any of the correct options. </li>
                                <li> If all options are found to be correct then Four marks (+4) will be awarded to all those who have attempted the question.</li>
                                <li>If none of the options is found correct or a Question is found to be wrong or a Question is dropped then all candidates who have appeared will be given four marks (+4) irrespective of the fact whether the question has been attempted or not attempted by the candidate.</li>
                            </ol>
                            <br />
                            <li><b>For Section B (MCQs):</b></li><b> Candidates need to attempt any 10 Questions out of 15 Questions given.</b>In the event that a candidate has attempted more than 10 questions, <b> only the first 10 attempted questions will be considered for evaluation.</b> There will also be negative marking for Section B. However, if any anomaly or discrepancy is found after the process of challenges of the key verification, it shall be addressed in the following manner:
                            <ol>
                                <li>Correct Answer: Four marks (+4) </li>
                                <li>Incorrect Answer: Minus one mark (-1)</li>
                                <li>Unanswered: No mark (0). </li>
                                <li> If more than one option is found to be correct then Four marks (+4) will be awarded to only those who have marked any of the correct options.
                                </li>
                                <li>If all options are found to be correct then Four marks (+4) will be awarded to all those who have attempted the question.
                                </li>
                                <li>If a question is found to be incorrect or the Question is dropped then Four marks (+4) will be awarded to all those who have attempted the question. The reason could be due to human error or technical error. </li>
                                <li> Candidates are advised to do the calculations with the constants given (if any) in the questions.
                                </li>
                            </ol>
                            <br />
                            <li><b>Mode of Examination:-</b></li>
                            NEET (UG) - 2023 is a Pen & Paper-based Test
                            <br />
                            <br />
                            <li><b>Duration of Test:-</b></li>
                            The duration of the test would be <b>three (03) hours and 20 minutes.</b> Compensatory time of one hour five minutes for examination of three hours twenty minutes (03:20 hrs) duration for PwBD Candidate [having a physical limitation to write] will be given, whether such candidate uses the facility of Scribe or not.


                    

                        </ul>



                    </ul>

                </div>
            </div>
        </div>
    );
}

export default Exampatrn;