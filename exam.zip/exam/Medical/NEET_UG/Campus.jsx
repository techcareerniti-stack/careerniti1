import { useEffect } from "react";
import "./campus.css";
function Campus() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return (
        <div className="neet-campusSection">
            <div className="neet-campusContent ">
                <div>
                    <h2 className="medexam-title">Campuses</h2>
                    <ul className="poppins-regular">
                        <li>
                            <div>  All government , private colleges and deemed universities
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Campus;