import { useEffect } from "react";
import "../NEET_UG/ImportantDate.css";

function ImportantDate() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="neet-impDtSection">
            <div className="neet-impDtContent ">
                <div>
                    <h2 className="medexam-title">Important Dates</h2>
                    <ul className="neet-impDtlist poppins-regular">
                        <li>
                            <b>Application From Last Date :-</b> Saturday, March 16, 2024
                        </li>
                        <li><b>Date of Examination :-</b> Sunday, May 05, 2024
                        </li>
                        <li><b>Neet Result :-</b> Friday, June 14, 2024
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default ImportantDate;