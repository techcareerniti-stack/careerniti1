import { useEffect } from "react";
import "../NEET_UG/Introduction.css";

function Introduction() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="neet-introSection">
            <div className="neet-introContent ">
                <div>
                    <h2 className="medexam-title">Introduction</h2>
                    <ul className="poppins-regular">
                        <li>
                            <p>The National Eligibility cum Entrance Test (Undergraduate) or NEET (UG), formerly the All India Pre-Medical Test (AIPMT), is an all India pre-medical entrance test for students who wish to pursue undergraduate medical (MBBS), dental (BDS) and AYUSH (BAMS, BUMS, BHMS, etc.) courses in government and private institutions.</p>
                            <p>Neet ug exam established year 2013 (except 2014 & 2015, when AIPMT was conducted instead.) Preceded by AIPMT.
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Introduction;