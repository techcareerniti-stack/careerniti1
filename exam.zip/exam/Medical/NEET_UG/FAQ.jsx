import { useEffect } from "react";
import "../NEET_UG/FAQ.css";

function FAQ() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="neet-faqSection">
            <div className="neet-faqContent poppins-regular">
                <div>
                    <h2 className="faq-head">FAQ Section</h2>
                </div>
                <div className="neet-faqInfo poppins-regular">
                    <ul className="faq-list">
                        <li>
                            <b>Que 1:- What is meant by NEET UG?</b>
                            <div>
                                <b>Ans:-</b>NEET UG (National Eligibility Entrance Test - Undergraduate) is the single entrance exam for MBBS/ BDS courses in medical colleges throughout India. NEET UG exam is conducted by NTA in pen-paper mode.
                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 2:-  Which subjects are needed for NEET?</b>
                            <div>
                                <b>Ans:-</b>The subjects required to qualify for NEET are Physics, Chemistry, Biology/ Biotechnology and English in class 12 or other qualifying exams. The candidate must have passed in these subjects and should obtain a minimum of 50% marks taken together in Physics, Chemistry and Biology/ Biotechnology.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 3 What is the difference between NEET UG and NEET PG?</b>
                            <div>
                                <b>Ans:-</b>NEET UG is for admission to undergraduate courses like MBBS and BDS whereas NEET PG is for admission into postgraduate courses like MD and MS in medical colleges.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 4 Is NEET compulsory for MBBS? Can I take admission in MBBS without NEET?</b>
                            <div>
                                <b>Ans:-</b>Yes, NEET is compulsory for pursuing MBBS in any medical college in India. You can't take admission in an MBBS course without giving and clearing the NEET (UG) exam.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 5 Is NEET required for pursuing MBBS outside India?</b>
                            <div>
                                <b>Ans:-</b>Yes, NEET is required for pursuing MBBS outside India. If a candidate wants to take MBBS admission in any foreign university then he/ she needs to give the NEET (UG) exam.

                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 6  How many times can one appear in the NEET ?</b>
                            <div>
                                <b>Ans:-</b>There is no limit on the number of times a candidate can appear in the NEET.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 7:-  Can I appear for NEET multiple times?</b>
                            <div>
                                <b>Ans:-</b>Yes, there is no attempt limit for NEET. You can appear for the exam as many times as you meet the eligibility criteria.
                            </div>
                        </li>
                        <br />

                        <li>
                            <b>Que 8:-  Can I change my choice of exam center after submitting the NEET application form?</b>
                            <div>
                                <b>Ans:-</b>No, after the closure of the NEET application form submission window, candidates cannot change their choice of exam center. It is essential to carefully select the exam center during the application process.
                            </div>
                        </li>
                        <br />
                        <li>
                            <b>Que 9:-  Is there any relaxation in the NEET eligibility criteria for differently abled or physically challenged candidates?</b>
                            <div>
                                <b>Ans:-</b>There are guidelines for written exams to help people with disabilities who have a disability of 40% or more. “Disabilities” can be long-term physical, mental, intellectual, or sensory impairments that make it difficult for them to fully participate in society like others. People with disabilities of 40% or more are called “persons with benchmark disabilities.” They can get admission to medical courses under a 5% reserved quota.
                                If someone has difficulty writing the exam due to a physical limitation, they can have a helper called a “scribe” who will write the answers on their behalf. The scribe should be certified by a government healthcare institution.
                                Also, if an aspiring MBBS graduate has a physical limitation and needs extra time to complete the exam, they will get one hour and five minutes extra, even if they don’t use a scribe. The national testing agency (NTA) can arrange a scribe if requested in the online application form.

                            </div>
                        </li>

                    </ul>

                </div>
            </div>
        </div>
    );
}

export default FAQ;