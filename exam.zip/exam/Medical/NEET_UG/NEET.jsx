import React, { useState } from "react";
import "./NEET.css";
import Add_Navbar from "../../Add_Navbar";

import Introduction from "./Introduction";
import Eligibility from "./Eligibility";
import Exampatrn from "./Exampatrn";
import Syllabus from "./Syllabus";
import FAQ from "./FAQ";
import Aplnfee from "./Aplnfee";
import RequiredDoc from "./RequiredDoc";
import AvailableCourse from "./AvailableCourse";
import Campus from "./Campus";
import ImportantDate from "./ImportantDate";
import TestCentre from "./TestCentre";

function NEET({ path, setLoc, loc, setSelectedNotify }) {
  const formatLocation = (location) => {
    const parts = location.split("/").filter((part) => part !== "");
    const capitalizedParts = parts.map((part) => {
      if (part.toLowerCase() === "neet") {
        return "NEET";
      } else {
        return part.charAt(0).toUpperCase() + part.slice(1);
      }
    });

    return capitalizedParts.join(" > ");
  };  

  return (
    <>
      <Add_Navbar
        introduction={<Introduction />}
        eligibility={<Eligibility />}
        available_courses={<AvailableCourse />}
        campuses={<Campus />}
        application_fees={<Aplnfee />}
        imp_dates={<ImportantDate />}
        exam_pattern={<Exampatrn />}
        syllabus={<Syllabus />}
        test_centres={<TestCentre />}
        required_documents={<RequiredDoc />}
        faq={<FAQ />}
        setLoc={setLoc}
        path={path}
        formatLocation={formatLocation}
        loc={window.location.pathname +loc}
        setSelectedNotify={setSelectedNotify}
        name="NEET"
        longform="[National Eligibility cum Entrance Test]"
      />
      <br />
    </>
  );
}

export default NEET;
