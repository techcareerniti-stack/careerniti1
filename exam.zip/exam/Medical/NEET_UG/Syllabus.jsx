import { useEffect } from "react";
import "../NEET_UG/Syllabus.css";

function Syllabus() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="neet-syllabusSection">
            <div className="neet-syllabusContent poppins-regular">
                <div>
                    <h2 className="syllabus-head">Syllabus</h2>
                </div>
                <div className="neet-syllabusInfo">
                    <ul className="syllabus-list">
                        <li><b>PHYSICS, CHEMISTRY, AND BIOLOGY (HIGHER SECONDARY STAGE)</b></li>
                        For National Eligibility-cum-Entrance Test NEET (UG)-2023, the National Medical Commission of India (NMC) recommends the following syllabus for admission to MBBS/BDS/BAMS/BSMS/BUMS/BHMS courses across the country, after review of various State syllabi as well as those prepared by CBSE, NCERT, and COBSE. This is to establish uniformity across the country, keeping in view the relevance of different areas in medical education.

                        <br />

                        <li><b>Physics</b></li>
                        <table className="neet-syllabusTbl">
                            <thead>
                                <td colSpan={2} className="table-heading">Physics syllabus of class 11th</td>
                                <td colSpan={2} className="table-heading">Physics syllabus of Class 12th</td>
                            </thead>
                            <thead>
                                <td className="table-heading">Sr. No.</td>
                                <td className="table-heading">Topics</td>
                                <td className="table-heading"> Sr. No.</td>
                                <td className="table-heading">Topics</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Physical-world and measurement</td>
                                    <td>1</td>
                                    <td>Electrostatics</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Kinematics</td>
                                    <td>2</td>
                                    <td>Current Electricity</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Laws of Motion</td>
                                    <td>3</td>
                                    <td>Magnetic Effects of Current and Magnetism</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Work, Energy and Power</td>
                                    <td>4</td>
                                    <td>Electromagnetic Induction and Alternating Currents</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>Motion of System of Particles and Rigid Body</td>
                                    <td>5</td>
                                    <td>Electromagnetic Waves</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>Gravitation</td>
                                    <td>6</td>
                                    <td>Optics</td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>Properties of Bulk Matter</td>
                                    <td>7</td>
                                    <td>Dual Nature of Matter and Radiation</td>
                                </tr>
                                <tr>
                                    <td>8</td>
                                    <td>Thermodynamics</td>
                                    <td>8</td>
                                    <td>Atoms and Nuclei</td>
                                </tr>
                                <tr>
                                    <td>9</td>
                                    <td>Behaviour of Perfect Gas and Kinetic Theory</td>
                                    <td>9</td>
                                    <td>Electronic Devices</td>
                                </tr>
                                <tr>
                                    <td>10</td>
                                    <td>Oscillations and Waves</td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>

                        <br />

                        <li><b>Chemistry :-</b></li>
                        <table className="neet-examptTbl">
                            <thead>
                                <td colSpan={2} className="table-heading">Chemistry syllabus of class 11th</td>
                                <td colSpan={2} className="table-heading">Chemistry syllabus of Class 12th</td>
                            </thead>
                            <thead>
                                <td className="table-heading">Sr. No.</td>
                                <td className="table-heading">Topics</td>
                                <td className="table-heading">Sr. No.</td>
                                <td className="table-heading">Topics</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Some Basic Concepts of Chemistry</td>
                                    <td>1</td>
                                    <td>Solid State</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Structure of Atom</td>
                                    <td>2</td>
                                    <td>Solutions</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Classification of Elements and Periodicity in Properties</td>
                                    <td>3</td>
                                    <td>Electrochemistry</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Chemical Bonding and Molecular Structure</td>
                                    <td>4</td>
                                    <td>Chemical Kinetics</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>States of Matter: Gases and Liquids</td>
                                    <td>5</td>
                                    <td>Surface Chemistry</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td> Thermodynamics</td>
                                    <td>6</td>
                                    <td>General Principles and Processes of Isolation of Elements</td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>Equilibrium</td>
                                    <td>7</td>
                                    <td>p- Block Elements</td>
                                </tr>
                                <tr>
                                    <td>8</td>
                                    <td>Redox Reactions</td>
                                    <td>8</td>
                                    <td>d and f Block Elements</td>
                                </tr>
                                <tr>
                                    <td>9</td>
                                    <td>Hydrogen</td>
                                    <td>9</td>
                                    <td>Coordination Compounds</td>
                                </tr>
                                <tr>
                                    <td>10</td>
                                    <td>s-Block Element (Alkali and Alkaline earth metals)</td>
                                    <td>10</td>
                                    <td>Haloalkanes and Haloarenes</td>
                                </tr>
                                <tr>
                                    <td>11</td>
                                    <td>Some p-Block Elements</td>
                                    <td>11</td>
                                    <td>Alcohols, Phenols and Ethers</td>
                                </tr>
                                <tr>
                                    <td>12</td>
                                    <td>Organic Chemistry- Some Basic Principles and Techniques</td>
                                    <td>12</td>
                                    <td>Aldehydes, Ketones and Carboxylic Acids</td>
                                </tr>
                                <tr>
                                    <td>13</td>
                                    <td>Hydrocarbons</td>
                                    <td>13</td>
                                    <td>Organic Compounds Containing Nitrogen</td>
                                </tr>
                                <tr>
                                    <td>14</td>
                                    <td>Environmental Chemistry</td>
                                    <td>14</td>
                                    <td>Biomolecules</td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>15</td>
                                    <td>Polymers</td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>16</td>
                                    <td>Chemistry in Everyday Life</td>
                                </tr>
                            </tbody>
                        </table>
                        <br />

                        <li><b>Biology :-</b></li>
                        <table className="neet-examptTbl">
                            <thead>
                                <td colSpan={2} className="table-heading">Biology syllabus of class 11th</td>
                                <td colSpan={2} className="table-heading">Biology syllabus of Class 12th</td>
                            </thead>
                            <thead>
                                <td className="table-heading">Sr. No.</td>
                                <td className="table-heading">Topics</td>
                                <td className="table-heading">Sr. No.</td>
                                <td className="table-heading">Topics</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Diversity in Living World</td>
                                    <td>1</td>
                                    <td>Reproduction</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Structural Organisation in Animals and Plants</td>
                                    <td>2</td>
                                    <td>Genetics and Evolution</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Cell Structure and Function</td>
                                    <td>3</td>
                                    <td>Biology and Human Welfare</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Plant Physiology</td>
                                    <td>4</td>
                                    <td>Biotechnology and Its Applications</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>Human physiology</td>
                                    <td>5</td>
                                    <td>Ecology and environment</td>
                                </tr>
                            </tbody>
                        </table>

                    </ul>







                </div>

            </div>

        </div>
    );
}

export default Syllabus;