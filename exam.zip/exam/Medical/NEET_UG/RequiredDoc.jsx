import { useEffect } from "react";
import "../NEET_UG/RequiredDoc.css";

function RequiredDoc() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return (
        <div className="neet-requiredSection">
            <div className="neet-requiredContent poppins-regular">
                <div >
                    <h2 className="required-head">Required Documents</h2>
                </div>
                <div className="neet-requiredInfo">
                    <ul className="required-list">
                        <li><b>Documents Required are listed below :-</b></li>
                        <ol className="ordered-list">
                            <li>The recent photograph should be either in colour or black and white with 80% face (without mask) visible including ears against a white background. </li>
                            <li> Scanned photographs, signature, and Left and Right hand Fingers and Thumb impressions should be in JPG format (clearly legible).</li>
                            <li>Scanned Category Certificate (if applicable), Citizenship Certificate (if applicable), and PwBD Certificate (wherever applicable) should be in pdf format (clearly legible).</li>
                            <li> The size of the scanned passport photograph should be between 10 kb to 200 kb (clearly legible).
                            </li>
                            <li>The size of the scanned Postcard photograph (4”x6”) should be between 10 kb - 200 kb (clearly legible).
                            </li>
                            <li> The size of the scanned signature should be between 4 kb to 30 kb (clearly legible)</li>
                            <li> The size of scanned and Left and Right hand Fingers and Thumb impressions as per the Template provided (Appendix-XIX) should be between 10 kb to 200 kb.
                            </li>
                            <li> The size of the scanned copy of the Category certificate (SC/ST/OBC-NCL/EWS etc.) should be in pdf between 50kb to 300kb (clearly legible).</li>
                            <li> The size of the scanned copy of the PwBD certificate should be between 50 kb to 300 kb (clearly legible) 7 </li>
                            <li> The size of the scanned copy of Class 10 pass certificate should be between 50 kb to 300 kb (clearly legible).
                            </li>
                            <li>The size of the scanned copy of the Citizenship certificate/Embassy certificate or any Documentary proof of Citizenship certificate should be between 50 kb to 300 kb (clearly legible). </li>
                            <li>The size of address proof of present address and permanent address should be between 50 kb to 300 kb (clearly legible).</li>
                        </ol>
                    </ul>

                </div>
            </div>
        </div>
    );
}

export default RequiredDoc;