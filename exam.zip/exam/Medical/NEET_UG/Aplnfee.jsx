import { useEffect } from "react";
import "../NEET_UG/Aplnfee.css";

function Aplnfee() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return (
        <div className="neet-feeSection">
            <div className="neet-feeContent poppins-regular">
                <div>
                    <h2 className="medexam-title">Aplication Fees</h2>
                </div>
                <div className="neet-feeInfo">
                    <ul className="neet-feelist">
                        <li><b>Fee Structure</b></li>
                        <table className="fee-table">
                            <thead>
                                <td>Category</td>
                                <td>In India (Fee in ₹)</td>
                                <td>Outside India (Fee in ₹)</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>General</td>
                                    <td className="numerical-data">₹ 1700/-</td>
                                    <td className="numerical-data"></td>
                                </tr>
                                <tr>
                                    <td>General-EWS/ OBC-NCL*</td>
                                    <td className="numerical-data">₹ 1600/- </td>
                                    <td className="numerical-data">9500/-</td>
                                </tr>
                                <tr>
                                    <td>SC/ST/PwBD/Third Gender</td>
                                    <td className="numerical-data">₹ 1000/-</td>
                                    <td className="numerical-data"></td>
                                </tr>
                            </tbody>
                        </table>
                    </ul>

                </div>
            </div>
        </div>
    );
}

export default Aplnfee;