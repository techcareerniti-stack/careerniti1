import { useEffect } from "react";
import "../NEET_UG/AvailableCourse.css";

function AvailableCourse() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="neet-avalCourseSection">
            <div className="neet-avalCourseContent ">
                <div>
                    <h2 className="medexam-title">Available Courses</h2>
                    <ul className="poppins-regular">
                        <li>
                            <div>There are several courses available to choose from once students successfully pass the NEET exam.
                                MBBS and BDS are the most common courses pursued after NEET, whereas some other courses are - BAMS, BHMS, BNYS, BPT, BSMS, BUM, B.Sc Nursing and BVSc & AH.
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default AvailableCourse;