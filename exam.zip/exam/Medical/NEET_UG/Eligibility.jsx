import { useEffect } from "react";
import "../NEET_UG/Eligibility.css";

function Eligibility() {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    return (
        <div className="neet-elgbltySection">
            <div className="neet-elgbltyContent poppins-regular">
                <div>
                    <h2 className="medexam-title">Eligibility</h2>
                </div>
                <div className="neet-elgbltyInfo ">
                    <ul className="neet-elgbltyList">
                        <li>
                            <b>Eligibility for appearing in NEET (UG), as per related Regulations of NMC and DCI </b>
                            <ol>
                                <li>He/she has completed 17 years of age at the time of admission or will complete that age on or before 31 December of the year of his/her admission to the first year of the Undergraduate Medical Course.
                                    <br />
                                    Accordingly, the lower age limit shall be as under :-
                                    <br />
                                    <table className="neet-elgbltyTable">
                                        <tr>
                                            <td>For Candidates of General (UR)/General-EWS</td>
                                            <td rowspan="2">born on or before <br />31.12.2006</td>
                                        </tr>
                                        <tr>
                                            <td>For Candidates of SC/ST/OBC-NCL/PwBD Category</td>
                                        </tr>
                                    </table>
                                </li>
                                <li>Upper age limit :- there is no upper age limit.</li>
                            </ol>
                        </li>
                    </ul>

                </div>
            </div>
        </div>
    );
}

export default Eligibility;