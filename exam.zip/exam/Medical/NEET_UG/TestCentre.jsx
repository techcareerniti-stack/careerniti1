import { useEffect } from "react";
import "../NEET_UG/TestCentre.css";

function TestCentre() {
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
    return (
        <div className="neet-testcentreSection">
            <div className="neet-testcentreContent ">
                <div>
                    <h2 className="medexam-title">Test Centres</h2>
                    <ul className="neet-testcemtrelist poppins-regular">
                        <li>NEET exam is conducted at various  Test Centres across all over india</li>
                        <br />
                        Visit following link for test centres  <br />
                        <a href="" target="_blank" rel="noopener noreferrer">NEET Test Centres</a>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default TestCentre;