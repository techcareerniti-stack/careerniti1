import './RequiredDoc.css'
function RequiredDoc() {
    return ( 
        <>
        <div className="Rd-section-NEET_PG ">
        <div className="Rd-content-NEET_PG poppins-regular">
          <h2 className="NEET_PG-title">Required Documents</h2>
          <ul>
            <li>NEET PG 2023 Admit Card.</li>
            <li>A valid ID proof of the candidate (PAN Card, passport, driving license, Aadhar card, Voter ID).</li>
            <li>A photocopy of the provisional/permanent MCI/SMC registration certificate.</li>
          </ul>
        </div>
      </div>
        </>
     );
}

export default RequiredDoc;