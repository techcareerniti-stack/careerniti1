import './ImportantDate.css'
function ImportantDate() {
    return ( 
        <>
        <div className="intro-section-NEET_PG ">
        <div className="ImpDates-content-NEET_PG-poppins-regular">
          <h2 className="NEET_PG-title">Important Dates </h2>
          
          <div>
          <ol className='list-NEET_PG'>
            <li>
                Application From- 16th April 2024 to 6th May 2024
            </li>

            <li>
                Admit Card- 18th June 2024
            </li>

            <li>
                Exam-23rd June 2024
            </li>

            <li>
                Result-15th July 2024
            </li>
          </ol>
          </div>
        </div>
      </div>
        </>
     );
}

export default ImportantDate;