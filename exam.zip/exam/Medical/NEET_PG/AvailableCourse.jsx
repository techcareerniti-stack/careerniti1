import './AvailableCourse.css'
function AvailableCourse() {
    return ( 
        <>
        <div className="ele-section-NEET_PG ">
        <div className="ele-content-NEET_PG poppins-regular">
          <h2 className="NEET_PG-title">Available Courses</h2>
          <div>
          <p>students who wish to study various postgraduate</p> 
          <p>Doctor of Medicine (MD),</p> 
          <p>Master of Surgery (MS), </p>
          <p>Diplomate of National Board (DNB), </p>
          <p>Doctorate of National Board (direct 6 years course in the field.)</p>

          </div>
        </div>
      </div>
        </>
     );
}

export default AvailableCourse;