import React from "react";

import Add_Navbar from "../../Add_Navbar";
import Introduction from "./Introduction";
import Eligibility from "./Eligibility";
import AvailableCourse from "./AvailableCourse";
import Campus from "./Campus";
import Aplnfee from "./Aplnfee";
import ImportantDate from "./ImportantDate";
import Exampatrn from "./Exampatrn";
import Syllabus from "./Syllabus";
import TestCentre from "./TestCentre";
import RequiredDoc from "./RequiredDoc";
import FAQ from "./FAQ";






function NEET_PG({ path, setLoc, loc, setSelectedNotify }) {

    const formatLocation = (location) => {
        const parts = location.split("/").filter((part) => part !== "");
        const capitalizedParts = parts.map((part) => {
            if (part.toLowerCase() === "neetpg") {
                return "NEET_PG";
            } else {
                return part.charAt(0).toUpperCase() + part.slice(1);
            }
        });
        return capitalizedParts.join(" > ");
    }
    return (
        <>
            <Add_Navbar

                introduction={<Introduction />}
                eligibility={<Eligibility />}
                available_courses={<AvailableCourse />}
                campuses={<Campus />}
                application_fees={<Aplnfee />}
                imp_dates={<ImportantDate />}
                exam_pattern={<Exampatrn />}
                syllabus={<Syllabus />}
                test_centres={<TestCentre />}
                required_documents={<RequiredDoc />}
                faq={<FAQ />}

                setLoc={setLoc}
                path={path}
                formatLocation={formatLocation}
                loc={window.location.pathname + loc}
                setSelectedNotify={setSelectedNotify}
                name="NEET PG"
                longform="[National Eligibility cum Entrance Test]"
            />



        </>
    );
}
export default NEET_PG;