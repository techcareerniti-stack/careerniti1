import './Introduction.css'
function Introduction () {
    return ( 
        <>
        <div className="intro-section-NEET_PG ">
        <div className="intro-content-NEET_PG poppins-regular">
          <h2 className="NEET_PG-title">Introduction</h2>

              <div>
             <p>NEET-PG is an eligibility-cum-ranking examination prescribed as the single entrance examination for admission to various MD/MS and PG Diploma Courses as per Section 61(2) of the National Medical Commission Act, 2019 read with Chapter IV of Post Graduate Medical Education Regulations, 2023. </p> 

             <p>No other entrance examination, either at the state or the Institution level, shall be valid for entry to MD/MS/PG Diploma courses. Qualifying NEET-PG is mandatory for entry to MD/MS/PG Diploma courses under various Universities/ Institutions in the country. NEET-PG is mandatory even for foreign nationals seeking admission in medical courses in India. </p>
              </div>

        </div>
      </div>
      </>
     );
}

export default Introduction ;