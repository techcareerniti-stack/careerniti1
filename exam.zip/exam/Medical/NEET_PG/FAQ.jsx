import './FAQ.css'
function FAQ() {
    return ( 
        <>
        <div className="Fq-section-NEET_PG ">
        <div className="Fq-content-NEET_PG-poppins-regular">
          <h2 className="NEET_PG-title"> Frequently Asked Questions (FAQs) </h2>

              <div className="NEET_PG-data">
                <b>Question-What is the testing format for NEET-PG ?</b><br />
                <b>Ans-National Eligibility-cum-Entrance Test for Post graduates (NEET-PG) </b>
                shall be conducted on computer-based test (CBT) platform. This is not an Internet-based test, i.e. a candidate does not take the test over the Internet. Instead of reading the questions from a paper booklet and darkening the ovals in an answer sheet, a candidate will now read the questions on a computer screen and choose an answer by using a mouse to click on the appropriate option.
              </div>
            
              <div className="NEET_PG-data">
                <b>Question- How is the computer-based format different from the paper and pencil format?</b><br />
                <b>Ans:-</b>The only difference is in the way the questions are presented, and how responsesare recorded.
              </div>
            
              
              <div className="NEET_PG-data">
              <b>Question- What is the duration of the exam?</b><br />
              <b>Ans:-</b>The exam duration is 3 hours and 30 Minutes and will be conducted in a single section. There will also be an additional 15-minute tutorial prior to the start of the test. Candidates will also need to accept a Non-Disclosure Agreement (NDA) before beginning the exam.
              </div>

              <div className="NEET_PG-data">
                <b>Question- How many questions will there be?</b><br />
                <b>Ans -</b>There will be a total of 300 questions.
              </div>

              <div className="NEET_PG-data">
                <b>Question- Can I move back and forth between the questions?</b><br />
                <b>Ans -</b>Yes, candidates will have the option to navigate between the questions via the Review Screen. Candidates are advised to make use of the Demo exam on the NEET-PG website<a href='https://www.nbe.edu.in/'>www.nbe.edu.in</a> to familiarize themselves with the navigation and functionality of the actual exam. A 15-minute tutorial will also be available prior to the start of the actual exam.
              </div>

              <div className="NEET_PG-data">
                <b>Question- What type of questions will there be?</b><br />
                <b>Ans -</b>The exam will only contain multiple choice questions, each with four (4) options and only one (1) correct response.
              </div>

              <div className="NEET_PG-data">
                <b>Question- What is the reporting time for the exam?</b><br />
                <b>Ans -</b>Candidates must arrive at their assigned test centre one (1) hour before their scheduled test start time. If the test begins at 10 AM, you must reach the reporting counter at test centre no later than 9 AM. If the test begins at 3:45 PM, you must reach the reporting counter at test centre no later than 2:45 PM. This will allow for security checks, identity verification and check-in. The reporting counter will close 30 minutes prior to the exam start time. Candidates who arrive late will not be allowed to take the exam.              
              </div>

              <div className="NEET_PG-data">
                <b>Question- What do I need to bring to the test centre?</b><br />
                <b>Ans -</b>
                Candidates MUST bring to the test centre the following documents:

                <ol>
                    <li>Printed copy of the Admit Card with photo pasted on it AND</li>
                    <li>Photocopy of the Permanent or Provisional SMC/MCI registration*, to be retained by the test centre AND</li>
                    <li>Any one of the following authorized photo IDs** (must be valid/original and non expired):</li>
                </ol>
                <ul className='NEET_PG-list'>
                    <li>PAN Card</li>
                    <li>Driving License</li>
                    <li>Voter ID</li>
                    <li>Passport</li>
                    <li>Aadhaar Card (with photograph)</li>
                </ul>
              </div>
              
        </div>
      </div>
        </>
     );
}

export default FAQ;