import './Syllabus.css'
function Syllabus() {
    return ( 
        <>
                <div className="Syllabus-section-CMI ">
        <div className="Syllabus-content-CMI poppins-regular">
          <h2 className="CMI-title">Syllabus</h2>
          <h3>NEET PG Pre-clinical Syllabus</h3>
            <div>
              <table className='Neet_PG-table'>
                <tr>
                  <th>Subject</th>
                  <th>Sub Topics</th>
                </tr>
                <tr>
                  <td >Anatomy</td>
                  <td>Gross Anatomy, Osteology, Muscular System, Arthrology, Cardio Vascular System, Respiratory System, Digestive System, Genito-Urinary System, Endocrine System and Individual Endocrine Glands, Nervous System and its components, Special Sensory Organs, Lymphatic System, Surface Anatomy, Cross Sectional Anatomy Cross sections of thorax, abdomen and pelvis to understand the interrelationship of organs and structures, Microanatomy.</td>
                </tr>
                <tr>
                <td >Physiology</td>
                <td>General Physiology, Nerve–Muscle, Blood, Respiratory System, Cardiovascular System, Gastrointestinal System, Nutrition, Environmental Physiology, Reproduction, Kidney, Neurophysiology, Sensory system, Motor system, Visceral and motivational system, EEG, sleep and higher nervous functions, Special Senses, Yoga</td>
                </tr>
                <tr>
                  <td >Biochemistry</td>
                  <td>Biological cell, Biomolecules, Enzymes, Metabolic pathways, their regulation and metabolic interrelationships, Carbohydrate metabolism, metabolism of Amino acid, Lipid, TCA cycle and biological oxidation, proteinoids. Regulation of the metabolic pathways, Food assimilation and nutrition, Hormones, Molecular Biology, pH, Buffer, physiological buffer systems, Immunology, Environmental biochemistry, cancer and cancer makers</td>
                </tr>
              </table>

              <h4>Para-Clinical Syllabus</h4>
              <h3>NEET PG Para-Clinical Syllabus</h3>
              <table className='Neet_PG-table'>
                <tr>
                  <th>Subject</th>
                  <th>Sub Topics</th>
                </tr>
                <tr>
                  <td >Pathology</td>
                  <td>Introduction to Pathology, Cell Injury, Amyloidosis and Calcification, Inflammation and Repair, Circulatory Disturbances, Growth Disturbances and Neoplasia, Immunopathology, Infectious Diseases, Miscellaneous Disorders, Cardiovascular Pathology, Respiratory Pathology, Urinary Tract Pathology, Pathology of the Gastro-Intestinal Tract, Hematopathology, Liver and Biliary Tract Pathology, Lymphoreticular System, Reproductive System, Osteopathology, Endocrine Pathology, Neuropathology</td>
                </tr>
                <tr>
                <td >Pharmacology</td>
                <td>General Pharmacology, Autonomic nervous system & Peripheral nervous system, Central nervous system, Autacoids, Cardiovascular, Gastrointestinal and respiratory system, Hormones, Chemotherapy, Immunomodulators, Drug therapy of glaucoma and cataract, Treatment of poisoning</td>
                </tr>
                <tr>
                  <td >Microbiology</td>
                  <td>Introduction to Microbiology, Bacteriology, parasitology, Virology and Mycology, Bacterial Staining and Cultivation, Common Tests for Bacterial identification, Laboratory Diagnosis of Viral Infection, Common Laboratory Methods for Diagnosis of Fungal Infections, Collection of Transport of Samples, Host-Parasite relationship. Bacterial AND Viral Genetics, Immunity to infection, Immunodiagnostic, Vaccines, Sterilization and disinfection, Bacteriology of water and air, Microorganisms associated with gastrointestinal infections (Bacteria, parasites, viruses and fungi), . Gastrointestinal infections caused by parasites.</td>
                </tr>
                <tr>
                  <td>Forensic Medicine</td>
                  <td>Forensic Pathology, Clinical forensic medicine, Medical Jurisprudence, Forensic Psychiatry, Forensic Sciences, General, clinical, environmental and analytical toxicology.</td>
                </tr>
                <tr>
                  <td>Social And Preventive Medicine</td>
                  <td>History of Public Health, Concepts in Public Health, Epidemiology and Research Methodology, Epidemiology of Specific Diseases, Entomology ,Biostatistics , Health planning and Public Health Administration , Nutrition, Environmental Health, Demography, Mental Health and Education Technology , Environmental Sanitation , Demography and Family Planning , Mental Health, Recent Advancements in Public Health and Miscellaneous topics , Sociology ,School, Occupational, Urban Health</td>
                </tr>
              </table>

              <h4>Clinical Syllabus</h4>
              <h3>NEET PG Clinical Syllabus</h3>
              <table className='Neet_PG-table'>
                <tr>
                  <th>Subject</th>
                  <th>Sub Topics</th>
                </tr>
                <tr>
                  <td >Psychiatry</td>
                  <td>Behavioral Sciences, Cognitive process and memory, Thinking and problem solving, Intelligence: General concepts and techniques for assessment, Personality (Principles of Personality development) and objective testing of Personality, Introduction and classification of Psychiatric disorder, Aetiology of Psychiatric disorders, Drug and Alcohol dependence, Personality disorders, Counselling and psychological therapies, Psychological testing</td>
                </tr>
                <tr>
                <td >Obstetrics and Gynecology</td>
                <td>Basic Sciences-Normal & abnormal development, structure and function of female & male urogenital systems, endocrinology of reproductive system, Gametogenesis, fertilization, Role of hormones in Obstetrics & Gynecology, Humoral and cellular immunology in Obstetrics & Gynecology, Physiology of normal pregnancy, diagnosis of pregnancy, Anemia in Pregnancy, Carcinoma Cervix, epidemiology, staging diagnostic procedure, treatment of Menopause and related problems, Contraception, Neonatology and Recent Advances.</td>
                </tr>
                <tr>
                  <td >Pediatrics</td>
                  <td>Contraception, Neonatology and Recent Advances, Growth and development, Nutrition, Immunization, Infectious diseases, Hematology, Respiratory system, Gastro Intestinal Tract, Central Nervous System. Cardiovascular system, Genito-Urinary system, Neonatology, Pediatrics Emergencies, Fluid-Electrolyte, Genetics, Behavioral Problems, Pediatrics Surgical Problems, Therapeutics.</td>
                </tr>
                <tr>
                  <td>Ophthalmology</td>
                  <td>Anatomy and development of eye, Clinical methods in ophthalmology, Optics and refraction, Disease of conjunctiva, Disease of the cornea, Disease of the sclera, Disease of the Uveal tract, lens, Glaucoma, vitreous, Retina, Vision and neuro-ophthalmology, Strabismus and Nystagmus, Disease of the lids. Disease of the lacrimal apparatus, Disease of the orbit, Ocular injuries, Basic principles of ocular therapy, Systemic ophthalmology, Community Ophthalmology, Miscellaneous Topics</td>
                </tr>
                <tr>
                  <td>Radiodiagnosis and Radiotherapy</td>
                  <td>Identify and diagnose all aspects of Emergency Room Radiology, Basic hazards and precautions in Radio-diagnostic practices, basic need of various radio-diagnostic tools in medical practice, learn about various imaging techniques, including isotopes C.T., Ultrasound, M.R.I. and D.S.A.,know about radio-active isotopes and their physical properties , identify symptoms and signs of various cancers and their steps of investigations and management</td>
                </tr>
                <tr>
                  <td>Surgery, ENT, Orthopedics, Anesthesia</td>
                  <td>Diagnose with reasonable accuracy all surgical illnesses including emergencies, Surgical knowledge of head, spine, chest abdominal and pelvic injury, know about various surgical techniques such as venesection, tracheostomy and endotracheal intubation, circumcision, biopsy of surface tumors. Comprehensive diagnosis of common Ear, Nose and Throat (ENT) diseases including the emergencies and malignant neoplasm of the head and neck, use of head mirror, otoscope and indirect laryngoscopy, possess knowledge of various ENT rehabilitative programmes. Therapeutic Orthopedics, knowledge on Splinting, Manual reduction of common fractures and dislocations, recognize metabolic bone diseases. Acquire knowledge on pre-anesthetic checkup and pre-anesthetic medications; simple general anesthetic procedures, anesthetic records, cardio-pulmonary brain resuscitation (C.P.B.R.) methods.</td>
                </tr>
                <tr>
                  <td>Medicine Dermatology And Venereology</td>
                  <td>Common clinical disorders, drug therapeutics, diagnostic and investigative procedures. Disorders of Pigmentation, Allergic disorders, Papulosquamous disorders, Papule vesicular disorders. Leprosy, Fungal infections, Scabies, Pediculosis, STD, Malignant Skin disease</td>
                </tr>
              </table>
            </div>
        </div>
      </div>
        </>
     );
}

export default Syllabus;