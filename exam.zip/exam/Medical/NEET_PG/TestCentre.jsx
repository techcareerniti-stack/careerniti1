import './TestCentre.css'
function TestCentre() {
    return ( 
        <>
        <div className="Tc-section-NEET_PG ">
        <div className="Tc-content-NEET_PG poppins-regular">
          <h2 className="NEET_PG-title"> Test Centres </h2>
        
          <div>
           
          </div>
        </div>
      </div>
        </>
     );
}

export default TestCentre;