import  './Aplnfee.css'
function Aplnfee() {
    return ( 
        <>
        <div className="ele-section-NEET_PG ">
        <div className="ele-content-NEET_PG poppins-regular">
          <h2 className="NEET_PG-title">Application Fees</h2>
          <div>
          <table className="NEET_PG-ImpDate-Table">
            <thead>
              <td className="tablehead-imp">Category of Candidate </td>
              <td className="tablehead-imp">Examination of Fees</td>
            </thead>
            <tbody>
              <tr>
                <td>
                General, OBC and EWS
                </td>
                <td >Rs. 3500/-</td>
              </tr>
              <tr>
                <td>
                SC, ST, PWD
                </td>
                <td >Rs. 2500/-</td>
              </tr>
            </tbody>
          </table>
           
          </div>
        </div>
      </div>
        </>
     );
}

export default Aplnfee;