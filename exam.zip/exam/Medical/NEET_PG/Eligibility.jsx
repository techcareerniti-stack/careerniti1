import './Eligibility.css'
function Eligibility() {
    return ( 
        <>
        <div className="intro-section-NEET_PG">
        <div className="ele-content-NEET_PG-poppins-regular">
          <h2 className="NEET_PG-title">Eligibilty</h2>
          <div >
            
            < ol className='NEET_PG-list'>
                <li>
                    Candidates in possession of MBBS degree or Provisional MBBS Pass Certificate recognized as per the provisions of the NMC Act, 2019 and the Post Graduate Medical Education Regulations, 2023 and possessing permanent or provisional registration certificate of MBBS qualification issued by the NMC/ the erstwhile Medical Council of India or State Medical Council and have completed one year of internship or are likely to complete the internship on or before 15th August 2024, may apply for NEET-PG 2024 through online application system at website https://natboard.edu.in
                </li>

                <li>
                    Candidates found to be ineligible at any stage of NEET-PG 2024 will not be permitted to appear in the examination and/or counseling. In an unlikely event of any ineligible candidate appearing and/or being successful in the NEET-PG 2024, the results/ candidature of such candidate shall be cancelled and/or are deemed to be cancelled.
                </li>

                <li>
                    Requests for appearing in NEET-PG 2024 from candidates completing internship after 15th August 2024 or having qualifications that are not recognized as per the NMC Act, 2019 and the repealed IMC Act, 1956 shall be summarily rejected. Candidates are further advised not to canvass for the same.
                </li>

                <li>
                    The dates indicated by candidates with regard to 12 months Compulsory Rotating Resident Internship in the application form (i.e. internship starting and completion date) shall be treated as final and candidates will be required to submit the original Compulsory Rotating Resident Internship completion certificate at the time of counseling/admission in allotted Medical College/ Institute.
                </li>

                <li>
                    The cut off dates for the recognition of the Medical Colleges, from where the candidates have passed their MBBS Degree Course and completed compulsory rotatory Internship for the year 2024 will be as prescribed by the NMC. The Colleges recognized after the cut- off date prescribed by the NMC will not be considered.
                </li>

                <li>
                    Registration with the NMC/ the erstwhile Medical Council of India or State Medical Council is necessary and its documentary proof should be furnished by the candidates on the day of examination and at the time of counseling/admission.
                </li>

                <li>
                    Some of the Universities/Institutions are having regulations that candidates who are already pursuing the PG Course in their University or in another University are not eligible for admission till they complete the course. The candidates who are already pursuing PG Courses either through All India Quota or State Quota and are applying for a seat under All India Quota/State quota seats may confirm the eligibility conditions of that University in this regard. NBEMS/ MoHFW/Designated Counseling Authority shall not be responsible if such candidates are refused for admission. Such candidates may opt for the subject and the college at their own risk and cost.
                </li>
            </ol>
            

            <h4><b>ELIGIBILITY CRITERIA FOR FOREIGN NATIONALS:</b></h4>
            <ol className='NEET_PG-list'>
              <li>
                Their basic Medical Qualification equivalent to MBBS should be recognized by the National Medical Commission.
              </li>

              <li>
                Foreign Nationals desirous of appearing in NEET-PG and those, who are required to have security clearance as per the Ministry of Home Affairs (MHA) requirements, shall obtain the security clearance from Ministry of Home Affairs, Govt. of India before applying for NEET-PG examination. The security clearance shall be required to be submitted while applying for NEET-PG examination.
              </li>

              <li>
                The National Medical Commission may, on payment of the prescribed fee for registration, grant temporary registration for the duration of the Post Graduate course limited to the medical college/institution to which he/she is admitted for the time being exclusively for pursuing postgraduate studies. Provided further that temporary registration to such foreign national shall be subject to the condition that such person is duly registered with appropriate registering authority in his own country where from he has obtained his Basic Medical qualification, and is duly recognized by the corresponding Medical Council or concerned authority and Permission/No Objection Certificate from the medical council of that country to allow undertaking Post Graduation in India has also been obtained.
              </li>
            </ol>
          </div>
        </div>
      </div>
        </>
     );
}

export default Eligibility;