import './Campus.css'
function Campus() {
    return ( 
        <>
        <div className="cam-section-NEET_PG ">
        <div className="cam-content-NEET_PG poppins-regular">
          <h2 className="NEET_PG-title">Campuses</h2>
          <p>
            
          </p>
        </div>
      </div>
        </>
     );
}

export default Campus;