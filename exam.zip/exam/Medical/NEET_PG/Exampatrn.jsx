import './Exampatrn.css'
function Exampatrn() {
    return ( 
        <>
        <div><div className="ele-section-NEET_PG ">
        <div className="ele-content-NEET_PG-poppins-regular">
          <h2 className="NEET_PG-title">Exam Pattern</h2>
          <div>

            <ol className='NEET_PG-list li'>
              <li>The Exam Shall Be a multiple choice questions Delivered Using Computer network (CBT) as per scheme prescribed. The exam comprises of 200 Multiple Choices, single correct response question in English language only.  Time allotted is hrs 30 min.</li>

              <li>There shall be 25% negative Marking for incorrect answers. No Marks will be deducted for unattempted question.</li>
            </ol>
         
          </div>
        </div>
      </div></div>
        </>
     );
}

export default Exampatrn;